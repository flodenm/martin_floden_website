Code to replicate CKM:s "A Critique of Structural VAR:s ..."
Martin Floden, October 2004

The main script is rbc_ql.m. This code solves CKM:s rbc model using the QL approach, and generates IR:s and histograms as in their paper.

Set CKMsign = 0 to use standard sign convention rather than CKM:s short-run convention.