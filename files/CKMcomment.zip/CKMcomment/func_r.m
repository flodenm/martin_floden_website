function r = func_r(x)

global alpha delta gamma psi L tauX g

dZ      = exp(x(1));
tauH    = x(2);
K       = exp(x(3))/dZ;
k       = exp(x(4))/dZ;
K_next  = exp(x(5));
H       = exp(x(6));
k_next  = exp(x(7));
h       = exp(x(8));


Y       = K^alpha*H^(1-alpha);
w       = (1-alpha)*Y/H;
r       = alpha*Y/K;
T       = tauH*w*H + tauX*((1+gamma)*K_next-(1-delta)*K) - g;

c       = (1-tauH)*w*h + r*k + T - (1+tauX)*((1+gamma)*k_next-(1-delta)*k);

r       = log(c) + psi*log(L-h);
