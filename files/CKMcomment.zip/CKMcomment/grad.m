function g = grad(FUNC,x)
% Calculate gradient of FUNC
%
% Format: g = grad(FUNC,x)
% FUNC is scalar valued
% x is a vector
% g is a row vector

n           = length(x);
g           = zeros(1,n);

for i = 1:n
    
    dx      = eps^(1/3)*max(abs(x(i)),1);

    xx      = x;
    xx(i)   = xx(i) + dx;   
    f1      = feval(FUNC,xx);
    xx(i)   = xx(i) - 2*dx;   
    f0      = feval(FUNC,xx);

    g(i)    = (f1 - f0) / (2*dx);

end
