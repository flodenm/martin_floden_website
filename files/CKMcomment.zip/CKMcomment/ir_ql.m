function [dZ,Z,TauH,EPSZ,EPST,K,Knext,H] = ir(nPeriods,R,kss,shock);

global alpha delta gamma psi L tauX g muZ rho sigmaZ sigmaT tauH

S    = 2;
T    = S + nPeriods;
dZ   = zeros(1,T);
TauH = zeros(1,T);
K    = zeros(1,T);
H    = zeros(1,T);
Z    = zeros(1,T);

dZ(1)   = 0;
TauH(1) = tauH;
K(1)    = kss*exp(muZ);   % decision in period 1 for k2 / z1

EPSZ      = zeros(1,T);
EPST      = zeros(1,T);

if shock == 'Z'
    EPSZ(S+2) = sigmaZ;
else
    EPST(S+2) = sigmaT;
end

for i = 2:T
    dZ(i)   = muZ + EPSZ(i);
    TauH(i) = (1-rho)*tauH + rho*TauH(i-1) + EPST(i);
    Z(i)    = Z(i-1) + dZ(i);

    decision = exp(R*[1 dZ(i) TauH(i) log(K(i-1)) log(K(i-1))]');
  
    K(i)     = decision(1);
    H(i)     = decision(2);
end

% Adjust normalization of K so that K = Kt/expectedZ
Knext =  K.*exp(Z);
K     =  K(1:end-1).*exp(Z(1:end-1));
K     = [kss K];
Knext = Knext./(exp(muZ).^(1:T));
K     = K./(exp(muZ).^(0:T-1));

% Remove first 500 observations from simulation
dZ    = dZ(S+1:end)';
TauH  = TauH(S+1:end)';
Z     = Z(S+1:end)';
EPSZ  = EPSZ(S+1:end)';
EPST  = EPST(S+1:end)';
Knext = Knext(S+1:end)';
K     = K(S+1:end)';
H     = H(S+1:end)';


