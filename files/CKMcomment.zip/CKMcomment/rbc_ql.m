% Program to solve rbc model in CKM:
% "A Critique of Structural VARs Using Real Business Cycle Theory"
% QL approach
%
% Martin Floden
% Stockholm School of Economics
% October 2004

clear all

CKMsign  = 1;                % Use CKM:s short-run sign convention?
IR.ON    = 0;                % Show IR or simulate and estimate VAR?
IR.T     = 40;
IR.TFP   = 1;
IR.shock = 'Z';
SIM.T    = 180;              % length of simulated series
SIM.N    = 1000;             % # of simulated series
SIM.nIR  = 50;
SIM.TFP  = 1;                % TFP or lab prod?
LSVAR    = 1;          
PROCESS  = 1;
nLags    = 4;

global alpha delta gamma psi L tauX muZ g rho sigmaZ sigmaT tauH

ns      = 5;                                          % # of state variables including constant
na      = 2;                                          % # of aggregate decision variables
nd      = 2;                                          % # of decision variables
n       = ns+na+nd;
nsa     = ns+na;

% Parameter values
alpha   = 0.35;
delta   = 1-(1-0.046)^(1/4);
gamma   = 1.015^(1/4)-1;

beta    = 0.970^(1/4);
psi     = 2.24;
L       = 5000/4;
tauX    = 0.273;    
gy      = 0.1877;   

if PROCESS==1
muZ     = 0.00302;                                    % Prescott and Ueberfeldt
tauH    = 0.287;
sigmaZ  = 0.00582;                                    % std dev of productivity shocks 
sigmaT  = 0.00750;                                    % std dev of tax shocks
rho     = 0.938;
elseif PROCESS==2
muZ     = 0.00293;                                    % Francis and Ramey
tauH    = 0.301;
sigmaZ  = 0.00556;                                    % std dev of productivity shocks 
sigmaT  = 0.00760;                                    % std dev of tax shocks
rho     = 0.937;
elseif PROCESS==3
muZ     = 0.00397;                                    % Christiano et al.
tauH    = 0.210;
sigmaZ  = 0.00633;                                    % std dev of productivity shocks 
sigmaT  = 0.01011;                                    % std dev of tax shocks
rho     = 0.955;
elseif PROCESS==4
muZ     = 0.00369;                                    % Gali and Rabanal
tauH    = 0.237;
sigmaZ  = 0.00888;                                    % std dev of productivity shocks 
sigmaT  = 0.00983;                                    % std dev of tax shocks
rho     = 0.969;
end    
    

% Solve for steady state (variables relative to Z)
r     = (1+tauX) * (exp(muZ)/beta - (1-delta));
kh    = (alpha/r)^(1/(1-alpha));
w     = (1-alpha)*kh^alpha;
wt    = (1-tauH)*w;
h     = (wt*L/psi) / ((1-gy)*w + wt/psi + ((1-gy)*r + (1-delta) - (1+gamma)*exp(muZ))*kh);
k     = kh*h;
y     = k^alpha*h^(1-alpha);
c     = wt*(L-h)/psi;
g     = gy*y;
K     = k;
H     = h;

logkss = log(k)+muZ;
logKss = log(k)+muZ;

% Build matrix Q
x               = [muZ tauH logKss logkss logKss log(H) logkss log(h)]';  % states (tauH,K,k), aggregates (K',H), decisions (k',h)
rx              = grad(@func_r,x)';
rxx             = hessian(@func_r,x);
Q               = zeros(n,n);
Q(1,1)          = func_r(x) - x'*rx + .5*x'*rxx*x;
Q(1,2:end)      = .5*(rx' - x'*rxx);
Q(2:end,1)      = .5*(rx - rxx*x);
Q(2:end,2:end)  = .5*rxx;
Qss = Q(1:ns,1:ns);
Qsa = Q(1:ns,ns+1:nsa);
Qsd = Q(1:ns,nsa+1:n);
Qas = Q(ns+1:nsa,1:ns);
Qaa = Q(ns+1:nsa,ns+1:nsa);
Qad = Q(ns+1:nsa,nsa+1:n);
Qds = Q(nsa+1:n,1:ns);
Qda = Q(nsa+1:n,ns+1:nsa);
Qdd = Q(nsa+1:n,nsa+1:n);



% Build matrices S, A, and D
S       = zeros(ns,ns);
A       = zeros(ns,na);
D       = zeros(ns,nd);
S(1,1)  = 1;
S(2,1)  = muZ;
S(3,1)  = (1-rho)*tauH;
S(3,3)  = rho;
A(4,1)  = 1;
D(5,1)  = 1;


% Initial guess for value matrix
V       = -diag(zeros(1,ns));
R       = zeros(nd,ns); RR=R;

% Iterate
for i = 1:1000
    
    oldR  = R;
    oldRR = RR;
    
    % Build matrix R (nd*ns)
    F  = -(Qds + beta*(1+gamma)*D'*V*S);
    Z  = Qda + beta*(1+gamma)*D'*V*A;
    W  = Qdd + beta*(1+gamma)*D'*V*D;
    R(:,5) = inv(W)*F(:,5);
    R(:,4) = inv(Z+W)*(F(:,4)-Z*R(:,5));
    R(:,3) = inv(Z+W)*F(:,3);
    R(:,2) = inv(Z+W)*F(:,2);
    R(:,1) = inv(Z+W)*F(:,1);
    
    RR = R;
    RR(:,4) = RR(:,4) + RR(:,5);
    RR(:,5) = 0;
 
    % Build matrix Qtilde
    Qtilde  = Qss + RR'*Qas + R'*Qds + Qsa*RR + RR'*Qaa*RR + R'*Qda*RR + Qsd*R + RR'*Qad*R + R'*Qdd*R;
   
    oldV    = V;
    V       = Qtilde + beta*(1+gamma)*((S+A*RR+D*R)'*V*(S+A*RR+D*R));
    V(1,1)=1;
    
    diffV   = max(abs((V(:)-oldV(:))./V(:)));
    diffR   = max(abs((R(:)-oldR(:))./R(:)));
    diffRR  = max(abs((RR(1:end-2)-oldRR(1:end-2))./RR(1:end-2)));
    if rem(i,100) == 0, fprintf('i = %6d, diffRR = %12.8f\n',i,diffRR); end
    if diffV  < 1e-10, break, end      % Stop if aggregate decision rule has converged
end
if diffRR > 1e-6
    display('Warning: Decision rule did not converge');
else
    fprintf(1,'Found solution after %6d iterations\n',i)
end

% Solution found. R is decision rule for [k' h]

% Check implications of R in steady state
ss = exp(R * [1 muZ tauH logKss logkss]');
fprintf(1,'Checking decision rules in steady state:\n')
fprintf(1,'k_next - k_ss = %12.8f\n',(ss(1)/exp(muZ)-k)/k);
fprintf(1,'h      - h_ss = %12.8f\n',(ss(2)-h)/h);


if IR.ON
% Impulse response

T = IR.T;
[dZ,Z,TauH,EPSZ,EPST,K,Knext,H] = ir_ql(T,R,k,IR.shock);

normZ = exp(Z)./(exp(muZ).^(0:T-1)');
Y = K.^alpha.*(normZ.*H).^(1-alpha);
C = Y + (1-delta)*K - (1+gamma)*Knext - g;
I = Knext - (1-delta)*K;
P = Y./H;

% Adjustment factor. X = 100 --> 1 std z shock, X = 100*0.01/sigma --> 1 % tfp shock
if IR.TFP && IR.shock == 'Z'
    X = 100*0.01/sigmaZ/(1-alpha);                  
else
    X = 100;
end

subplot(3,2,1);
plot(X*(Y./Y(1)-1));
title('output')
subplot(3,2,2);
plot(X*(H./H(1)-1));
title('hours')
subplot(3,2,3);
plot(X*(P./P(1)-1));
title('lab. productivity')
subplot(3,2,4);
plot(X*(C./C(1)-1));
title('consumption')
subplot(3,2,5);
plot(X*(K./K(1)-1));
title('capital')
subplot(3,2,6);
plot(X*(I./I(1)-1));
title('investment')

else
    
N   = SIM.N;
T   = SIM.T;
nIR = SIM.nIR;
SD = 0; C0 = 0; C5m = 0; C5p = 0;
SAVE_IR = cell(6,1);

fprintf(1,'Simulating...\n')

for i = 1:N
    
    % Simulate the economy
    [dZ,Z,TauH,EPSZ,EPST,K,Knext,H] = simulate_ql(T,R,k);
    Y = K.^alpha.*(exp(Z).*H).^(1-alpha);
    C = Y + (1-delta)*K - (1+gamma)*Knext - g;
    I = Knext - (1-delta)*K;
    P = Y./H;

     
    dp = log(P(2:end)./P(1:end-1));
    n  = log(H(2:end)/h);
    dn = log(H(2:end)./H(1:end-1));

    if LSVAR        
       X        = [dp n];
       imp      = svar(X,nLags,nIR,CKMsign);      
       imp(:,1) = cumsum(imp(:,1));        
    else
        imp = svar([dp dn],nLags,nIR-1,CKMsign);
        imp = cumsum(imp);
    end

    % save ir
    SAVE_IR{1} = [SAVE_IR{1} imp(:,1)];
    SAVE_IR{2} = [SAVE_IR{2} imp(:,2)];
    SAVE_IR{3} = [SAVE_IR{3} imp(:,1)+imp(:,2)];
    
end


imp   = zeros(nIR,3);
imp5  = zeros(nIR,3);
imp95 = zeros(nIR,3);
for i = 1:3
    imp0 = SAVE_IR{i};
    n    = size(imp0,2);
    imp1 = sort(imp0')';
    i025 = round(0.025*n);
    i975 = round(0.975*n);
    imp(:,i)   = mean(imp0')';
    imp025(:,i)  = imp1(:,i025);
    imp975(:,i) = imp1(:,i975);
end


figure
titles = {'productivity to tech','h to tech','gdp to tech'};

% Adjustment factor. X = 100 --> 1 std z shock, X = 100*0.01/sigma --> 1 % tfp shock
if SIM.TFP
    X = 100*0.01/sigmaZ/(1-alpha);                  
else
    X = 100;
end

  
n = min(SIM.nIR,nIR);
for i = 1:3
subplot(3,1,i)
plot(1:n,X*imp(1:n,i),'b-',...
     1:n,X*imp025(1:n,i),'k:',...
     1:n,X*imp975(1:n,i),'k:')
title(titles{i})
end

figure
impact  = SAVE_IR{2};
impact  = X*impact(1,:);
mini    = floor(10*min(impact))/10;
maxi    = ceil(10*max(impact))/10;
[N,BIN] = hist(impact,[mini:0.1:maxi]);
bar(BIN,N/sum(N),1)

% Look at impulse response for labor productivity
ir_labprod = SAVE_IR{1};
ir_hours   = SAVE_IR{2};
i_neg      = find(ir_labprod(end,:) < 0);
if length(i_neg) > 0
    fprintf(1,'Ooops. Some permanent positive technology shocks have a negative effect on labor productivity in the long run!\n')
    fprintf(1,'... for example impulse response function #%6d.\n',i_neg(1));
    figure
    plot(X*[ir_labprod(:,i_neg(1)) ir_hours(:,i_neg(1))])
    legend('labor productivity','hours')
    title('Impulse response to positive techn. shock. Example with incorrect sign identification?')
end
all_neg = (ir_labprod < 0);
i_all_neg = sum(all_neg);
[sumneg,i_max] = max(i_all_neg);
if  sumneg == size(ir_labprod,1)
    fprintf(1,'Ooops. Some permanent positive technology shocks have a negative effect on labor productivity in every period!\n')
    fprintf(1,'... for example impulse response function #%6d.\n',i_max);
    figure
    plot(X*[ir_labprod(:,i_max) ir_hours(:,i_max)])
    legend('labor productivity','hours')
    title('Impulse response to positive techn. shock. Example with incorrect sign identification')
end

end
