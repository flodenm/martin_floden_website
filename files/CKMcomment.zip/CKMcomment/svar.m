function [IR,A0,Psi] = svar(Y,nLags,nIR,CKMsign)
% Estimate structural var: Y(t) = A + B(L)*Y(t-1) + E(t)
%
% Y is n * nvar
% nLags    = # lags
% nIR      = # periods to return in IR
% CKMsign  = use CKM:s short-run sign convention?
%
% Returns IR: nLags * nvar, col1 = response of Y(1) to E(1), col2 = response of Y(2) to E(1)
% I.e. IR is the impulse response for each variable in response to the first shock (permanent
% productivity).
% 
% Identifying assumption: Only the first shock can have long-run effect on the first column of Y 
% 

[nobs,nvar] = size(Y);
T = nobs-nLags;

% Run VAR
X = zeros(T,nLags*nvar+1);
j = 1;
for i = nLags:-1:1
    X(:,j:j+nvar-1) = Y(i:(i+T-1),:);
    j = j + nvar;
end
X(:,end) = 1;
beta     = inv(X'*X)*X'*Y(nLags+1:end,:);  
Fi       = beta(1:end-1,:)';

% Invert Fi to get Psi
Psi = zeros(nvar,nvar*nIR);
FI  = [Fi; [eye(nvar*(nLags-1)) zeros(nvar*(nLags-1),nvar)]];
tmp = FI^0;
for i = 0:nIR-1
    Psi(:,nvar*i+1:nvar*(i+1)) = tmp(1:nvar,1:nvar);
    tmp = tmp*FI;
end


% Impose the restriction

n = size(beta,1)-1;
Q = eye(nvar);
for i = 1:nvar:n
    Q = Q - beta(i:(i+nvar-1),:)';
end
C = Q \ eye(nvar);

eps = Y(nLags+1:end,:) - X*beta;
S   = cov(eps);

D = chol(C * S * C')';
R = inv(C) * D;

% Impulse - Response, only for productivity shock
ir1 = zeros(nIR,nvar);
for i = 0:nIR-1
  ir = Psi(:,(nvar*i+1):(nvar*(i+1))) * R;
  ir1(i+1,:) = ir(:,1)';
end

% Use CKM:s sign convention?
if CKMsign
    if ir1(1,1) < 0
        ir1 = -ir1;
    end
end

IR = ir1;
A0 = R;