function [C_cert1, C_cert2] = ...
  Ccert(V,Hdec,Q,Zprob,H,Y0,params);
% Calculate certainty equivalent consumption

beta = params(2);
gmma = params(3);
mu   = params(4);
zeta = params(5);
g    = params(6);


% Calculate certainty equivalent consumption, fixing H at the initial choice level
const = (1 - beta * (1+g)^(1-mu)) * (1-mu);
C_cert1 = (1/Y0) .* ((const .* V) ./ exp(-(1-mu)*zeta*Hdec.^(1+gmma))).^(1/(1-mu));

% Calculate certainty equivalent consumption, fixing H at the average level
C_cert2 = (1/Y0) .* ((const .* V) ./ exp(-(1-mu)*zeta*H^(1+gmma))).^(1/(1-mu));
