function u = Utility(c,h,params)

gmma = params(3);
Mu = 1-params(4); 
zeta = params(5);

u = c.^Mu .* exp(-Mu*zeta*h.^(1+gmma)) / Mu;

u = u - (h>.8).*((h-.8).^2)*1e5;