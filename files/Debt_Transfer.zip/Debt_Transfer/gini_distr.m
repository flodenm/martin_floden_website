function g = gini_distr(X,DD);
% Calculate gini-coefficient for matrix X with 'density' DD

n = size(DD,1);

X = X(:);
DD = DD(:);
[X, indX] = sort(X);
DD = DD(indX);

X = DD .* X;
csX = cumsum(X);
lorenz = csX / sum(X);
csD = cumsum(DD);
n = size(csD,1);
g = sum(lorenz(2:n-1).*(csD(3:n)-csD(1:n-2)))/2;
g = g + lorenz(1)*(csD(2)-csD(1))/2 + lorenz(n)*(csD(n)-csD(n-1))/2;
g = (1/2 - g)/.5;