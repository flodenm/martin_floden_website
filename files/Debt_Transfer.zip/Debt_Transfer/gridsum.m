function [S] = gridsum(DD,H);
% Calculate sum of H over distribution DD

S = sum(sum(DD.*H));
