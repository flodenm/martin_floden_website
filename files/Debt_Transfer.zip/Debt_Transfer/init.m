% Proc INIT.m
% Set up grid for capital and productivity,
% calculate transition probs,
% Initialize parameters common to all experiments

% SIZE OF GRID
ggz         = 7;
m           = 3;                  % Spread in Z grid (+- std. devs.)


% PARAMETER VALUES
ww          = 1.5;
Cbar        = 0.75;
alfa 	    = 0.27;               % Target for labor share of total time
gmma        = 2;                  % Inverse of labor-supply elasticity
zeta        = (ww / (Cbar*(1+gmma))) * (alfa.^(-gmma));
clear ww Cbar alfa

sigma       = 0.21;               % SD of productivity shocks 
rho         = 0.90;               % Persistence of productivity shocks
sigma_perm  = 0.34;               % SD of permanent wage differences

alfa        = 0.3;                % Target for labor share of total time
theta       = 0.3;                % Capital share in production
g           = 0.0185;             % Growth rate in economy
delta       = 0.075;              % Depreciation rate of physical capital
beta        = 0.9884;             % Discount factor
mu          = 1.5;                % Risk aversion
G           = 0.217;              % Government consumption as a fraction of GDP


% SET UP STATE SPACE

kmax        = ((alfa^(1-theta)) / delta)^(1/(1-theta));
kmax        = 6*kmax;

% Assets
minA        = 0;
maxA        = kmax;
A           = [0:0.005:1 1.01:.01:kmax];
A           = [0:.0075:1 1.015:0.015:2 2.02:.02:kmax];
%A          = [0:.0075:1 1.02:0.02:2 2.025:.025:10 10.035:.035:kmax];
%A          = [0:.0075:1 1.02:0.02:2 2.04:.04:10 10.05:.05:kmax];
%Acoarse    = [0:.01:1 1.02:0.025:2 2.05:.05:10 10.05:.05:kmax];
Acoarse     = [0:.0075:1 1.02:0.02:2 2.04:.04:10 10.05:.05:kmax];
Acoarse(end)= A(end);
gga         = length(A);

% Productivity endowment
[Z, Zprob]  = Tauchen(ggz,0,rho,sigma,m);
distr       = (ones(1,ggz)/ggz) * Zprob^1000;
Ql          = exp(Z - sigma_perm);
Qh          = exp(Z + sigma_perm);
EQ          = distr * (Ql' + Qh') / 2;
Ql          = Ql / EQ; Qh = Qh / EQ;

Q           = [Ql Qh];
bigZprob    = [Zprob zeros(size(Zprob)); zeros(size(Zprob)) Zprob];
ggz         = size(Q,2)/2;

params      = [alfa beta gmma mu zeta g theta delta G];

