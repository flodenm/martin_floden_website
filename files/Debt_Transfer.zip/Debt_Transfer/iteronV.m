function V = iteronV(V,Adec,Cdec,Hdec,Pr,nIters,params)
% iterate on value function without updating decisions


beta = params(2);
gmma = params(3);
mu   = params(4);
zeta = params(5);
g    = params(6);

nZ = size(V,2);

for i = 1:nIters

  for iZ = 1:nZ

    EVnxt = beta * (1+g)^(1-mu) * V * Pr(iZ,:)';

    newV(:,iZ) = Utility(Cdec(:,iZ),Hdec(:,iZ),params) + EVnxt(Adec(:,iZ));
   
  end

  V = newV;

end
