% First version 981112
%
% Use script.m (or similar) to call this routine


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                        SETUP                                      %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

repfile = 'report.out';
outfile = 'log.out';			% File for log

init

if precision == 'hgh'
  
  maxRIter    = 20;				% Max r guesses / tax rate	
  maxKDiff    = 0.0004;			% Conv. crit. for capital
  maxHDiff    = 0.000008;		% Conv. crit. for aggr. hours
  maxTrDiff   = 0.0001;
else
  maxRIter    = 16;				% Max r guesses / tax rate	
  maxKDiff    = 0.002;			% Conv. crit. for capital
  maxHDiff    = 0.00001;		% Conv. crit. for aggr. hours
  maxTrDiff   = 0.0005;
end;  

repinter   = 25;  				% Interval for showing foc progress

pi		 = 1e12;				% Penalty for forbidden choices
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

tic;
diary(outfile);
rand('seed',124508977743109711);


if gmma/mu < 1.8
  maxHIter = 10;
elseif gmma/mu < 2.5
  maxHIter = 2;
else
  maxHIter = 1;                    % Max Hbar guesses / r guess
end;


% Lump sum and means tested transfers
B = (1-meanstest)*totB;            % Lump sum


% Initial R
R0         = (Rmin + Rmax)/2;
TopDiff    = 999;
BottomDiff = 999;
TopH       = 999;
BottomH    = 999;
Rdirect    = 0;
saveR      = [];
saveKD     = [];
saveA      = [];


% Load saved solution?
if isempty(infile)
  w0     = (1-theta) * ((R0+delta)/theta)^(-theta/(1-theta));
  R      = 1+R0;
  A_decl = zeros(gga,ggz);  	
  H_decl = alfa * ones(gga,ggz);
  C_decl = A' * ones(1,ggz) + w0 * (1-H_decl) .* (ones(gga,1) * Ql);
  A_decl = ones(ggz,1) * A;
  A_dech = A_decl; H_dech = H_decl; 
  C_dech = C_decl + w0 * (1-H_dech) .* (ones(gga,1) * (Qh-Ql));
  Dl     = []; Dh = Dl;
else
  load(infile)
end

if isempty(infile2)
  R    = 1+R0;
else
  load(infile2)
  rrr  = Rmax-Rmin;
  Rmin = result_vec(13) - rrr/2;
  Rmax = result_vec(13) + rrr/2;
  HQ0  = result_vec(22);
  clear resultvec rrr
end;


if (exist('Vl') == 0) | (exist('Vh') == 0)
    initiateV = 1;
elseif (size(Vl,1) ~= gga) | (size(Vl,2) ~= ggz)
    initiateV = 1;
else
    initiateV = 0;
end


% =================================================
% Loop on Transf until Gvt spending eq. Tax revenue
% =================================================
Rmin0      = Rmin;
Rmax0      = Rmax;
TransfIter = 1;
TransfDiff = 1;

while (TransfIter <= 30) & (TransfDiff > maxTrDiff)

  Rmin   = Rmin0;
  Rmax   = Rmax0;
  Transf = (Trmin+Trmax)/2;          % Means tested

  % Iterate until asset demand eq. asset supply

  Hbar   = HQ0;
  oldA   = -1;
  Next_r = (Rmin + Rmax) / 2; 
   
  prints('===========================================================================',0);
  prints(date); cl = clock; prints('   ');
  prints(cl(4),2,0); prints(':'); prints(cl(5),2,0,0);
  prints(' ',0);
  prints('B: ');  prints(B); prints('   D: '); prints(D);  prints('   Initial r: ');
  prints(Next_r,0);
  prints('Transf, B = ',[Transf B],12,6,0);
  prints('',0);

  KDiff = 1;  
  rIter = 1; 
  HDiff = 1;

  while ((KDiff > maxKDiff) | (HDiff > maxHDiff)) & (rIter <= maxRIter);
  
    r        = Next_r;
    Kbar     = theta / (r + delta);         % Firms' asset demand
    
    HIter    = 1;
    HDiff    = 1;
    oldHDiff = 1;
    nextH    = Hbar;
    minH     = -99;
    maxH     = 99;
    Abar     = Kbar + D;                    % To start looping
      
    while (HDiff > maxHDiff) & (HIter <= maxHIter) & ...
        ((HIter == 1) | abs(Abar-Kbar-D) < .4 | (HDiff > .001)) & ...
        (Abar > .5*(Kbar+D)) & (Abar < 2*(Kbar+D))
      
      Hbar = nextH;
      prints('',0); prints('>>> NEW GUESS: ');
      prints('r = '); prints(r,10,6); 
      prints('   Rmin = '); prints(Rmin,10,6);
      prints('   Rmax = '); prints(Rmax,10,6);
      prints('   Hbar = '); prints(Hbar,10,6,0);
      prints('>>> rIter = '); prints(rIter,6,0);
      prints('   HIter = '); prints(HIter,6,0,0);
      oldHbar = Hbar;
      
      w    = (1-theta) / Hbar;
      tau  = (totB + (r-g)*D + G) / (1 + r*D - delta*Kbar);	    % Tax rate implied by gvt budget
      rr   = (1-tau) * r;                                       % After-tax return on capital
      ww   = (1-tau) * w;                                       % After-tax wage per eff. unit of labor
      
      Cbar = 1 - (g+delta) * Kbar;
      

      % Solve value function and decision rules

      if initiateV == 1
        for iZ=1:ggz
          [C0, H0]  = solve_CH(Acoarse,Ql(iZ),Acoarse,rr,ww,B,params);
          Vl0(:,iZ) = Utility(C0,H0,params) / (1-beta*(1+g)^(1-mu));
        end 
        A_decl0 = (1:length(Acoarse))'*ones(1,ggz);
 
        prints('Solving low, coarse',0)
        [Vl0, A_decl0, dummy, dummy2] = ...
          solve_foc(Acoarse,Ql,Zprob,Vl0,A_decl0,ww,rr,B,Transf,75,12,params);
        Vl     = griddata(Ql,Acoarse,Vl0,Ql,A');
        A_decl = (1:gga)'*ones(1,ggz);

        for iZ=1:ggz
          [C0, H0]  = solve_CH(Acoarse,Qh(iZ),Acoarse,rr,ww,B,params);
          Vh0(:,iZ) = Utility(C0,H0,params) / (1-beta*(1+g)^(1-mu));
        end 
        A_dech0 = (1:length(Acoarse))'*ones(1,ggz);
        prints('Solving high, coarse',0)
        [Vh0, A_dech0, dummy, dummy] = ...
          solve_foc(Acoarse,Qh,Zprob,Vh0,A_dech0,ww,rr,B,Transf,75,12,params);
        Vh     = griddata(Qh,Acoarse,Vh0,Qh,A');
        A_dech = (1:gga)'*ones(1,ggz);

        initiateV = 0;
      end



      % (i) solve for low Q
      prints('Solving low, fine',0)
      [Vl, A_decl, C_decl, H_decl] = ...
          solve_foc(A,Ql,Zprob,Vl,A_decl,ww,rr,B,Transf,25,15,params);


      % (ii) solve for high Q
      prints('Solving high, fine',0)
      [Vh, A_dech, C_dech, H_dech] = ...
          solve_foc(A,Qh,Zprob,Vh,A_dech,ww,rr,B,Transf,25,15,params);
      

      % Calculate ss distribution over state space
      prints('Solving distributions',0)
      [Dl, Abarl, Hbarl] = ssdistrib(Dl,A_decl,H_decl,Ql,Zprob,A);
      [Dh, Abarh, Hbarh] = ssdistrib(Dh,A_dech,H_dech,Qh,Zprob,A);
      Dsavl = Dl; Dsavh = Dh;
      
      Hbar  = (Hbarl + Hbarh)/2; 
      Abar  = (Abarl + Abarh) / 2;
      HDiff = abs(Hbar-oldHbar); 

      if Hbar > oldHbar
        minH = max(oldHbar,minH);
      else
        maxH = min(oldHbar,maxH);
      end

      if (minH > -99) & (maxH < 99) & ((HDiff > oldHDiff/5) | ...
         (Hbar < minH) | (Hbar > maxH))
        nextH = (minH + maxH) / 2;
      else
        nextH = Hbar;
      end
      
      onTransfl   = (C_decl <= Transf) & (A(A_decl) <= 1e-6);
      onTransfh   = (C_dech <= Transf) & (A(A_dech) <= 1e-6);
      TransfCostl = Transf * sum(sum(onTransfl .* Dl/2));
      TransfCosth = Transf * sum(sum(onTransfh .* Dh/2));
      TransfCost  = (TransfCostl+TransfCosth);

      prints('Cost of transfers ',TransfCost,10,6,0);

      oldHDiff = HDiff;
      prints('K+D = '); prints(Kbar+D,10,6); prints('   A = '); prints(Abar,10,6,0);
      prints('HDiff = '); prints(HDiff,10,6); prints('   H = '); prints(Hbar,10,6,0);
      HIter = HIter + 1;
    end;
    
    saveR  = [saveR r];
    saveKD = [saveKD (Kbar+D)];
    saveA  = [saveA Abar];
    
    oldA = Abar;
    
    if Abar > (Kbar+D)
      if ((Rdirect == 1)  & (Abar < oldA)) | ...
          ((Rdirect == -1) & (Abar > oldA)) 
        ;
      else
        Rmax = r;
      end;
      TopDiff = Abar - Kbar - D;
      TopH = Hbar;
    else
      if ((Rdirect == 1)  & (Abar < oldA)) | ...
          ((Rdirect == -1) & (Abar > oldA)) 
        ;
      else
        Rmin = r;
      end;
      BottomDiff = Kbar + D - Abar;
      BottomH = Hbar;
    end
    
    if (TopDiff == 999) | (BottomDiff == 999)
      Next_r = (Rmin + Rmax) / 2;
    else
      
      % Use secant method if several iters done, else bisect
      if rIter > 5
        Next_r = Rmin + BottomDiff * (Rmax - Rmin) / (BottomDiff + TopDiff);
      else
        Next_r = (Rmin + Rmax) / 2;
      end
      Hfrac = (Next_r - Rmin) / (Rmax+1e-8-Rmin);
      Hfrac = min(max(Hfrac,.25),.75);
      Hbar  = Hfrac * TopH + (1-Hfrac) * BottomH;      
    end
    
    % If no convergence in x (x>5) steps, guess R from spline on K+D and A
    if rIter > 13
      nR              = size(saveR,2);
      [sortR indR]    = sort(saveR(nR-4:nR));
      sortA           = saveA(nR-5+indR);
      stepR           = mean(sortR(2:5)-sortR(1:4));
      fineR           = (sortR(1)-.0015):max(stepR/50,1e-5):(sortR(5)+.0015);
      nFR             = size(fineR,2);
      iR              = sum((ones(5,1)*fineR) > (sortR'*ones(1,nFR)));
      iR              = max(min(iR,4),1);
      fracR           = (fineR - sortR(iR)) ./ (sortR(iR+1) - sortR(iR) + 1e-8);
      guessKD         = theta ./ (fineR + delta) + D;	
      guessA          = fracR .* sortA(iR+1) + (1-fracR) .* sortA(iR);
      [tmp, guessIND] = min(abs(guessKD-guessA));
      Next_r          = fineR(guessIND);
      prints('R updated by fitting piecewise linear function to historical K+D and A',0);
    end;
      
    
    if Next_r > r, Rdirect = 1; else, Rdirect = -1; end;
    
    KDiff = abs(Abar - Kbar - D);
    prints('KDiff = '); prints(KDiff,10,6); prints('   K = '); prints(Kbar,10,6);
    prints('   K+D = '); prints(Kbar+D,10,6); prints('   A = '); prints(Abar,10,6,0);
    prints('',0);
    
    rIter = rIter + 1;
    
  end;
  

  totTrCost  = TransfCost + B;
  TransfDiff = abs(totB-totTrCost);
  if totTrCost > totB
    Trmax = Transf;
  else
    Trmin = Transf;
  end
  prints('End of TrIter ',TransfIter,6,0,3);
  prints('totTrCost = ',totTrCost,10,6,0);
  TransfIter = TransfIter + 1;
end;
  
  % ************************************************ %
  % SOLUTION FOUND! CALCULATE STATISTICS FOR ECONOMY %
  % ************************************************ %
  
  % Calculate exact r,K for A and H in solution
  Ksolv = Abar - D;
  rsolv = theta/Ksolv - delta;
  

  
  % Stack low- and high decision rules and measure in big matrices
  % Down: size(A), right: [Qlow Qhigh]
  Q     = [Ql Qh];
  Zprob = [Zprob zeros(ggz,ggz); zeros(ggz,ggz) Zprob];
  ggz   = 2 * ggz;
  DD    = [Dsavl Dsavh] / 2;
  Adec  = [A_decl A_dech];
  Cdec  = [C_decl C_dech];
  Hdec  = [H_decl H_dech];
  V     = [Vl Vh];
   
  
  % Calculate average utility etc.
  nD     = size(DD,1);
  HQ     = gridsum(DD,Hdec.*(ones(nD,1)*Q));
  Y0     = Kbar^(theta/(1-theta)) * HQ;
  V      = V * Y0^(1-mu);
  bigU   = Y0^(1-mu) .* Cdec.^(1-mu) .* exp(-(1-mu)*zeta*Hdec.^(1+gmma)) ./ (1-mu);
  H      = gridsum(DD,Hdec);
  C      = gridsum(DD,Cdec);
  nHighA = sum((.8*A(nD))>A);
  nHighA = sum(DD(nD,:)-DD(nHighA,:));
  U      = gridsum(DD,bigU);
  
  % Find value function over fine grid and calculate more welfare measures
  prints('Calculating certainty equivalents...',0);
  [C_cert1, C_cert2] = Ccert(V,Hdec,Q,Zprob,H,Y0,params);

  Vbar       = gridsum(DD,V) * (1-beta*(1+g)^(1-mu));
  totC_cert1 = gridsum(DD,C_cert1);
  insU1      = Y0^(1-mu) * totC_cert1^(1-mu) * exp(-(1-mu)*zeta*H^(1+gmma)) / (1-mu);
  totC_cert2 = gridsum(DD,C_cert2);
  insU2      = Y0^(1-mu) * totC_cert2^(1-mu) * exp(-(1-mu)*zeta*H^(1+gmma)) / (1-mu);
  



  % Calculate average V conditional on productivity
  sepV    = zeros(1,ggz+2);
  sepV(1) = gridsum(DD(:,1:(ggz/2)),V(:,1:(ggz/2))) * (1-beta*(1+g)^(1-mu)) / .5;
  sepV(2) = gridsum(DD(:,(ggz/2+1):ggz),V(:,(ggz/2+1):ggz)) * (1-beta*(1+g)^(1-mu)) / .5;
  for i = 1:ggz
    sepV(i+2) = gridsum(DD(:,i),V(:,i)) * (1-beta*(1+g)^(1-mu)) / sum(DD(:,i));
  end;
  

  % Calculate welfare loss/gain (in terms of consumption) compared to benchmark economy
  % wl is the welfare loss in percent of annual consumption
  % More precisely, if consumption is multiplied by (1+wl), then utility is the same as
  % in the benchmark economy
  prints('Calculating welfare loss of (B,D) compared to benchmark',0);
  [pUNC1, pUNC2, pINE1, pINE2, wlU, wlINS1, wlINS2] = ...
    welfmeas(DD,Cdec,Hdec,C_cert1,C_cert2,totC_cert1,totC_cert2,C,H,Y0,...
            TargetU,TargetINS1,TargetINS2,params);
  
  % Calculate std dev.s, correlations etc
  std_c = sqrt(gridsum(DD,(Cdec-C).^2))/C;
  std_h = sqrt(gridsum(DD,(Hdec-H).^2))/H;
  std_a = sqrt(gridsum(DD,(A(Adec)-Abar).^2))/Abar;
  ern   = w * Hdec .* (ones(nD,1) * Q);			% Earnings
  inc   = ern + r * (A' * ones(1,ggz)) + B;		% Net factor income before tax 
  Eern  = gridsum(DD,ern);
  Einc  = gridsum(DD,inc);
  std_e = sqrt(gridsum(DD,(ern-Eern).^2))/Eern;
  std_i = sqrt(gridsum(DD,(inc-Einc).^2))/Einc;
  std_Q = sqrt(gridsum(DD,(w*(ones(nD,1)*Q-1)).^2));
  ccHW  = gridsum(DD,(Hdec-H).*(w * (ones(nD,1)*Q - 1))) / (std_h * H * (w*std_Q));
  ccHA  = gridsum(DD,(Hdec-H).*(A(Adec)-Abar)) / (std_h * std_a * H * Abar);
  ccWA  = gridsum(DD,(w * (ones(nD,1)*Q - 1)).*(A(Adec)-Abar)) / ((w*std_Q) * std_a * Abar);
  ccEA  = gridsum(DD,(ern-Eern).*(A(Adec)-Abar)) / (std_e * std_a * Eern * Abar);
  ccIA  = gridsum(DD,(inc-Einc).*(A(Adec)-Abar)) / (std_i * std_a * Einc * Abar);

  gC    = gini_distr(Cdec,DD);
  gA    = gini_distr(A(Adec),DD);
  gE    = gini_distr(ern,DD);
  gI    = gini_distr(inc,DD);

  % REPORT RESULTS
  diary off;
  diary(repfile);
  prints(' ',0);
  prints('===========================================================================',0);  
  prints(header); prints('   ');
  prints(date); cl = clock; prints('   ');
  prints(cl(4),2,0); prints(':'); prints(cl(5),2,0,0);
  if (KDiff > maxKDiff) | (HDiff > maxHDiff)
    prints('',0); prints('***** WARNING: DID NOT CONVERGE *****',0);
  end;
  prints(' ',0);
  prints('SET UP:',0);
  prints('B       = '); prints(B,10,6);
  prints('   D       = '); prints(D,10,6,0); 
  prints('totB    = '); prints(totB,10,6); 
  prints('   mntest  = '); prints(meanstest,10,6,0);
  prints('mu      = '); prints(mu,10,6);
  prints('   gmma    = '); prints(gmma,10,6);
  prints('   alfa    = '); prints(alfa,10,6,0);
  prints('rho     = '); prints(rho,10,6);
  prints('   sigma   = '); prints(sigma,10,6);
  prints('   sigma_p = '); prints(sigma_perm,10,6,0);
  prints('g       = '); prints(g,10,6);
  prints('   beta    = '); prints(beta,10,6);
  prints('   zeta    = '); prints(zeta,10,6,0);
  prints('#A      = '); prints(gga,10,0);
  prints('   #Z      = '); prints(ggz,10,0,0);
  prints(' ',0);
  prints('RESULTS:',0);
  prints('r       = '); prints(r,10,6);
  prints('   w       = '); prints(w,10,6);
  prints('   r(A-D)  = '); prints(rsolv,10,6,0);
  prints('rr      = '); prints(rr,10,6);
  prints('   ww      = '); prints(ww,10,6,0);
  prints('K/Y     = '); prints(Kbar,10,6);
  prints('   A/Y     = '); prints(Abar,10,6);
  prints('   K+D     = '); prints(Kbar+D,10,6,0);
  prints('H       = '); prints(H,10,6);
  prints('   HQ      = '); prints(HQ,10,6,0);
  prints('Transf  = '); prints(Transf,10,6);
  prints('   totTr   = '); prints(totTrCost,10,6,0);
  prints('tau     = '); prints(tau,10,6);
  prints('   V->U    = '); prints(Vbar,10,6,0);
  prints('U       = '); prints(U,10,6);
  prints('   InsU1   = '); prints(insU1,10,6);  
  prints('   InsU2   = '); prints(insU2,10,6,0);  
  prints('Wls U   = '); prints(wlU,10,6);
  prints('   WlsINS1 = '); prints(wlINS1,10,6); 
  prints('   WlsINS2 = '); prints(wlINS2,10,6,0); 
  prints('pUNC1   = '); prints(pUNC1,10,6);
  prints('   pUNC2   = '); prints(pUNC2,10,6,0); 
  prints('pINE1   = '); prints(pINE1,10,6);
  prints('   pINE2   = '); prints(pINE2,10,6,0); 
  prints('C/Y     = '); prints(C,10,6);
  prints('   Y0      = '); prints(Y0,10,6,0);
  prints('Ccert1  = '); prints(totC_cert1,10,6);
  prints('   Ccert2  = '); prints(totC_cert2,10,6,0);
  prints('sd%(C)  = '); prints(std_c,10,6);
  prints('   sd%(A)  = '); prints(std_a,10,6);
  prints('   sd%(H)  = '); prints(std_h,10,6,0);
  prints('sd%(E)  = '); prints(std_e,10,6);
  prints('   sd%(I)  = '); prints(std_i,10,6,0);
  prints('cr(h,w) = '); prints(ccHW,10,6);
  prints('   cr(h,a) = '); prints(ccHA,10,6);
  prints('   cr(w,a) = '); prints(ccWA,10,6,0);
  prints('gini(C) = '); prints(gC,10,6);
  prints('   gini(A) = '); prints(gA,10,6,0);
  prints('gini(E) = '); prints(gE,10,6);
  prints('   gini(I) = '); prints(gI,10,6,0);
  

  prints(' ',0); prints('Value function for different productivity levels ',0);
  prints('Low permanent productivity:  '); prints(sepV(1),10,6,0);
  prints('High permanent productivity: '); prints(sepV(2),10,6,0);
  prints('Low perm.:  '); prints(sepV(3:(ggz/2+2)),9,5,0);
  prints('High perm.: '); prints(sepV((ggz/2+3):(ggz+2)),9,5,0);
  prints('===========================================================================',0);  
  diary off;
  
  % Save result in result_vec:
  % B=1, alfa=5, zeta=10, rsolv=15, (Kbar+D)=20, U=25, wlINS2=30, std_h=35, ccWA=40,
  % totC_cert1=45 meanstest=50
  result_vec = [B D mu gmma alfa rho sigma g beta zeta gga ggz r w rsolv rr ww Kbar Abar ...
      (Kbar+D) H HQ tau Vbar U insU1 insU2 wlU wlINS1 wlINS2 C Y0 ...
      std_c std_a std_h std_e std_i ccHW ccHA ccWA gC gA gE gI totC_cert1 totC_cert2 ...
      totB Transf totTrCost meanstest pUNC1 pUNC2 pINE1 pINE2];

