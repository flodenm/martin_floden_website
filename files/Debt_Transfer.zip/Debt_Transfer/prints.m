function prints(p,a2,a3,a4,a5)
% PRINTS
% Formated printing to screen
% 
% Print p as string or float
% If args = 1: Print p
% If args = 2: If a2 = 0 end with new line, otherwise insert a2 spaces
% If args = 3: a2 is field width, a3 is decimal points
% If args = 4: a2 and a3 is as above, and a2 = 0 end with new line, otherwise insert a2 spaces
% In args = 5: p is string to print, a2 is number to print, a3 field width, a4 decimal points, a5 alignment of a2:
%				a5<0 = no action, a5=0 = line break, a5>0 = insert spaces

if nargin == 5
  fs = int2str(a3);
  ds = int2str(a4);
  f_str = ['%' fs '.' ds 'f'];
elseif nargin > 2
  fs = int2str(a2);
  ds = int2str(a3);
  f_str = ['%' fs '.' ds 'f'];
else
  f_str = '%f';
end;

if isstr(p)
  fprintf(1,'%c',p);
else
  fprintf(1,f_str,p);
end;

if nargin == 5
  fprintf(1,f_str,a2);
  if a5 == 0
    fprintf(1,'\n%c','');
  elseif a5 > 0
    fprintf(1,blanks(a5));
  end;

elseif (nargin == 2) & (a2 <= 0)
  fprintf(1,'\n%c','');
elseif  (nargin == 4) & (a4 <= 0)
  fprintf(1,'\n%c','');
elseif (nargin == 2)
  fprintf(1,blanks(a2));
elseif (nargin == 4)
  fprintf(1,blanks(a4));
end;