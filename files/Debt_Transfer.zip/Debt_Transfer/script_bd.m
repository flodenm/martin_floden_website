clear all;

header = 'Change B and D';
precision = 'low';

TargetU = -4.813796; TargetINS1 = -4.548658; TargetINS2 = -4.629108;

% Benchmark economy
Rmin      = 0.0451118-0.00005;
Rmax      = 0.0451118+0.00005;
HQ0       = 0.315281;
totB      = 0.082;                       % Transfers as fraction of gdp
meanstest = 0;                           % Fraction of transfers that are means tested
Trmax     = 0.0;      
Trmin     = 0.0;

D = 2/3;
infile  = 'v.mat';
infile2  = '';

% Solve for benchmark policy
main

break
% The code below solves for other combinations of transfer and debt
% Benchmark parameterization


TargetU           = U;
TargetINS1        = insU1;
TargetINS2        = insU2;
result_vec(28:30) = 0;
results           = result_vec;
save results results
save tmp


loopD = [-1:.25:2.5];
loopB = [0.0:0.05:0.30];
nDD = length(loopD);
nBB = length(loopB);

load guess_bd

for iBB = 1:nBB
  for iDD = 1:nDD
    
    D    = loopD(iDD);
    totB = loopB(iBB);
     
    i_   = find(res_bd(:,1)==loopB(iBB) & res_bd(:,2)==loopD(iDD));
    
    if isempty(i_)
      Rmin = 0.00;
      Rmax = 0.12;
      HQ0  = 0.25;
    else
      Rmin = res_bd(i_,13) + 0.0003 - .0005;
      Rmax = res_bd(i_,13) + 0.0003 + .0005;
      HQ0  = res_bd(i_,22) - 0.00003;
    end
   
    main

    results = [results; result_vec];
    save results results
    save tmp
    save v Vl Vh Dl Dh A_decl A_dech
  end
end