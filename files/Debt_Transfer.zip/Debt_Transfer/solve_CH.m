function [C, H] = solve_CH(a,q,anxt,r,w,b,params)

gmma = params(3);
mu   = params(4); 
zeta = params(5);
g    = params(6);


C = (1+r)*a' + .04*w*q + b - (1+g)*anxt';
C = max(C,1e-4);

df = 1;
it = 1;
while (df > 1e-8) & (it < 35)
  oldC   = C;
  dummy  = (zeta*(1+gmma))^(-1/gmma) * (w*q).^(1+1/gmma) .* C.^(-1/gmma);
  f      = C - b - dummy - (1+r) * a' + (1+g) * anxt';
  fprime = 1 + (1/gmma) * dummy ./ C;
  C      = C - f ./ fprime;
  C      = max(C,1e-4);

  df     = sum(abs(C - oldC)) + (min(C)<2e-3);
  it     = it + 1;
end

H     = ((w*q) ./ (zeta*(1+gmma)*C)).^(1/gmma);
highH = H > 1;
oldH  = H;
H     = min(H,1);
 
test1 = (b + (1+r) * a' + w*q.*H - C) / (1+g);

diff1 = norm(anxt'-test1);
if diff1 > 1e-8
%  prints('Diff, iter, C: ',[diff1 it-1 min(C) max(C)],12,6,0);
end


test2 = w*q - zeta*(1+gmma)*H.^gmma .* C;
diff2 = norm(test2);

if diff2 > 1e-10
%  prints('diff2, H>1?',[diff2 max(oldH)],10,6,0);
end
 

