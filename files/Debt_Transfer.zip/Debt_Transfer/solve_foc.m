function [V, Adec, Cdec, Hdec] = ...
   solve_foc(A,Q,Pr,V,Adec,w,r,b,ylow,maxViters,span,params)
% ---------------------------------------------------------------------------
% SOLVE_FOC
% 
% 991109
% Solve first order condition for debt-tr problem.
% Iterate on value function
%
% Pr = transition matrix
% V = guessed value function
% Adec = index to guess for solution for a'
% w = after tax wage per efficiency unit
% r = after tax interest rate
% b = lump sum transfer
% ylow = guaranteed after tax income (means tested)
% ---------------------------------------------------------------------------

beta = params(2);
gmma = params(3);
mu   = params(4);
zeta = params(5);
g    = params(6);

R    = 1 + r;
Cmin = max(ylow / 4,1e-2);

nA   = length(A);
nZ   = length(Q);

Amax    = b + R * A' * ones(1,nZ) + ones(nA,1) * w * Q - Cmin;
Amax    = min(Amax,A(end)-1e-12);
Uben    = Utility(max(ylow,1e-8),0,params);
tmpAdec = Adec;


Vdiff    = 1;
Adiff    = 1;
maxVdiff = 1e-5;
maxAdiff = 1e-4;
Vit      = 1;
while (Vit <= maxViters) & ((Vdiff > maxVdiff) | (Adiff > maxAdiff))


oldAdec = Adec;

% ---------------------------------------------------------------------------
% Loop over all productivity states
% Solve for optimal a' for all a at this productivity state
% ---------------------------------------------------------------------------
for iZ = 1:nZ

  % -------------------------------------------------------------------------
  % Calculate expected V next period as function of (index to) a'
  % -------------------------------------------------------------------------
  EVnxt = beta * (1+g)^(1-mu) * V * Pr(iZ,:)';


  % -------------------------------------------------------------------------
  % First calculate value of going on benefits (implying a'=0)
  % -------------------------------------------------------------------------
  BenPossible = R*A' < ylow;
  Vben        = BenPossible .* (Uben + EVnxt(1)) - (1-BenPossible) * 1e20;

  % -------------------------------------------------------------------------
  % Then look for best a' if benefits not choosen/possible
  % -------------------------------------------------------------------------
 % guessCmax = max(3*ylow,5*(b + R * A' + w * Q(iZ) - A(tmpAdec(:,iZ))'));
 % guessAlow = b + R * A' + w * Q(iZ) - guessCmax;
 % Alow0 = max(1,floor(interp1q(A',(1:nA)',guessAlow)));
  Alow0   = ones(nA,1);
  Alow   = Alow0;
  Ahigh0 = floor(interp1q(A',(1:nA)',Amax(:,iZ)));
  Ahigh  = Ahigh0;
  Aguess = min(tmpAdec(:,iZ),Ahigh);
  resA   = Aguess; resC = zeros(nA,1); resH = resC;
  resV   = V(:,iZ);

  iactive = (1:nA)';
  maxit   = 35;
  it      = 0; 
  while (length(iactive) > 0) & (it<maxit)

    % -----------------------------------------------------------------------
    % Calculate V(Aguess), V(Aguess-span) and V(Aguess+span)
    % -----------------------------------------------------------------------
    actA = A(iactive);
    [Cguess1, Hguess1] = solve_CH(actA,Q(iZ),A(max(Aguess-span,1)),...
                                  r,w,b,params);
    Vguess1 = Utility(Cguess1,Hguess1,params) + EVnxt(max(Aguess-span,Alow));
    [Cguess2, Hguess2] = solve_CH(actA,Q(iZ),A(Aguess),r,w,b,params);
    Vguess2 = Utility(Cguess2,Hguess2,params) + EVnxt(Aguess);
    [Cguess3, Hguess3] = solve_CH(actA,Q(iZ),A(min(Aguess+span,nA)),...
                                  r,w,b,params);
    Vguess3 = Utility(Cguess3,Hguess3,params) + EVnxt(min(Aguess+span,Ahigh));

    comp21 = Vguess2 >= Vguess1;
    comp23 = Vguess2 >= Vguess3;
      

    solution_mid = (comp21 & comp23) | ...
                   (comp23 & (Aguess == Alow)) | (comp21 & (Aguess == Ahigh));
  
    solution_mid             = solution_mid + (1-(comp21 | comp23));      % strange solution
    isolution                = find(solution_mid);
    resA(iactive(isolution)) = Aguess(isolution);
    resC(iactive(isolution)) = Cguess2(isolution);
    resH(iactive(isolution)) = Hguess2(isolution);
    resV(iactive(isolution)) = Vguess2(isolution);
    nosolution               = 1-solution_mid;
    iiactive                 = find(nosolution);
    iactive                  = iactive(iiactive);

    comp21 = comp21(iiactive);
    comp23 = comp23(iiactive);
    Aguess = Aguess(iiactive);
    Alow0  = Alow0(iiactive);
    Ahigh0 = Ahigh0(iiactive);
    
    Alow   = (1-comp23) .* min(Aguess+1,Ahigh0) + comp23 .* Alow(iiactive);    
    Ahigh  = (1-comp21) .* max(Aguess-1,Alow0) + comp21 .* Ahigh(iiactive);
   
    Aguess = round(.5*Alow+.5*Ahigh);

    it = it + 1;
  end
  
  if it == maxit, prints('NO SOLUTION!!!',iactive,8,0,0); end

  % -------------------------------------------------------------------------
  % Calculate V(Aguess-span) to V(Aguess+span)
  % -------------------------------------------------------------------------
  bestA = resA;
  bestV = resV;
  for i = (-span+1):(span-1)
    if i ~= 0
      Aguess  = max(min(resA+i,nA),1);
      [Cguess, Hguess] = solve_CH(A,Q(iZ),A(Aguess),r,w,b,params);
      Vguess  = Utility(Cguess,Hguess,params) + EVnxt(Aguess);
      newBest = Vguess > bestV;
      bestV   = (1-newBest) .* bestV + newBest .* Vguess;
      bestA   = (1-newBest) .* bestA + newBest .* Aguess;
    end
  end
  
  resV = bestV;
  resA = bestA;

  Benefits   = Vben > resV;
  newV(:,iZ) = Benefits .* Vben + (1-Benefits) .* resV;

  tmpAdec(:,iZ) = resA;
  newAdec(:,iZ) = Benefits + (1-Benefits) .* resA;
  newCdec(:,iZ) = Benefits .* ylow + (1-Benefits) .* resC;
  newHdec(:,iZ) = (1-Benefits) .* resH;
  BenDec(:,iZ)  = Benefits;
   
end

Adec = newAdec;
Cdec = newCdec;
Hdec = newHdec;


for iZ = 1:nZ
  [Cdec(:,iZ), Hdec(:,iZ)] = solve_CH(A,Q(iZ),A(Adec(:,iZ)),r,w,b,params);
  Cdec(:,iZ) = BenDec(:,iZ) .* ylow + (1-BenDec(:,iZ)) .* Cdec(:,iZ);
  Hdec(:,iZ) = BenDec(:,iZ) .* 0 + (1-BenDec(:,iZ)) .* Hdec(:,iZ);
end


Vdiff = norm(V-newV)/norm(V);
Adiff = sum(sum(abs(Adec-oldAdec)))./(nA*nZ);
if rem(Vit,5) == 0,
  disp_inc = max(ylow,w*Hdec.*(ones(nA,1)*Q)+b);
  subplot(2,2,1); plot(A,newV);  
  subplot(2,2,2); plot(A,A(Adec)./(R*A'*ones(1,nZ)+disp_inc));
  subplot(2,2,3); plot(A,Cdec);
  subplot(2,2,4); plot(A,Hdec); drawnow

end

V   = newV;
Vit = Vit+1;

iterAgain = (Vit <= maxViters) & ((Vdiff > maxVdiff) | (Adiff > maxAdiff));
if iterAgain & ((Vit>10) | (Vdiff/100 < maxVdiff))
  V = iteronV(V,Adec,Cdec,Hdec,Pr,50,params);
end


end

prints('Solved value function on iter, Vdiff, Adiff = ',...
   [(Vit-1) Vdiff Adiff],14,4,0);
