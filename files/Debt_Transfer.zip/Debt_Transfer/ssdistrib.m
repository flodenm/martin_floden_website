function [D, Abar, Hbar] = ssdistrib(D,Adec,Hdec,Q,Pr,A);
% Find ss distribution over state space
% 991110
%
% D is distribution


% ----------------------------------------------------------------------------
% Initialize
% addZ is an nA*nZ matrix that transforms an nA*1 vector of indices to A, to
%   an nA*nZ matrix with indeces to A,Z
% ----------------------------------------------------------------------------

[nA, nZ] = size(Adec);

if size(D,1) ~= nA
  D = ones(nA,nZ) / (nA*nZ);
end

addZ = ones(nA,1) * (nA * (0:(nZ-1)));


% ----------------------------------------------------------------------------
% Find multiple references to same index from grid points with same z
% ----------------------------------------------------------------------------
bigMultPoint = cell(2,nZ);              % row 1 = maxSame, row 2 = cell
for iZ = 1:nZ

  tmpCell = cell(1,nA);
  nPointersToHere = zeros(1,nA);
  [sortIndA, iSortIndA] = sort(Adec(:,iZ));
  sortIndA = [sortIndA; nA+1000];
  nI = 0;
  lastI = 0;
  for iA = 1:nA
    while sortIndA(lastI+nI+1) <= iA
       nI = nI + 1;
    end
    pt = iSortIndA(lastI+1:lastI+nI);
    tmpCell{iA} = pt;
    nPointersToHere(iA) = length(pt);
    lastI = lastI+nI;
    nI = 0;
  end

  if 1>2
    pt = find(Adec(:,iZ) == iA);
    nPt = length(pt);
    tmpCell{iA} = pt;
    nPointersToHere(iA) = nPt;
  end  

  maxSame = max(nPointersToHere);
  pointers = zeros(nA,maxSame);
  for iA = 1:nA
    pointers(iA,1:nPointersToHere(iA)) = tmpCell{iA}';
  end

  multPoint = cell(2,maxSame);
  for i = 1:maxSame;
    indx = find(pointers(:,i) > 0);
    multPoint{1,i} = indx;
    multPoint{2,i} = pointers(indx,i);
  end
  
  bigMultPoint{1,iZ} = maxSame;
  bigMultPoint{2,iZ} = multPoint;
end;
clear pointers nPointersToHere multPoint


maxDdiff = 1e-8;
Ddiff = 1;
Dit = 1;
while (Ddiff > maxDdiff) & (Dit < 700)

  % ----------------------------------------------------------------------------
  % Build new distribution D
  % ----------------------------------------------------------------------------

  newD = zeros(nA,nZ);
  for iZ = 1:nZ
    maxSame = bigMultPoint{1,iZ};
    multPoint = bigMultPoint{2,iZ};
    for i = 1:maxSame
      ptTO = multPoint{1,i};
      ptFROM = multPoint{2,i};
      indAZ = (ptTO*ones(1,nZ)) + addZ(ptTO,:);
      newD(indAZ) = newD(indAZ) + D(ptFROM,iZ)*Pr(iZ,:);
    end
  end

  Ddiff = norm(D-newD);
  Abar = sum(sum(D .* (A'*ones(1,nZ))));
  Hbar = sum(sum(D .* Hdec .* (ones(nA,1)*Q)));
  if rem(Dit,25) == 0
%    prints('Iter, Ddiff, Abar, Hbar = ',[Dit Ddiff Abar Hbar],12,6,0);
  end
  D = newD;  
  Dit = Dit + 1;

end

Abar = sum(sum(D .* (A'*ones(1,nZ))));
Hbar = sum(sum(D .* Hdec .* (ones(nA,1)*Q)));

prints('Solved distribution on iter, Ddiff, Abar, Hbar = ',...
   [(Dit-1) Ddiff Abar Hbar],12,6,0);
