function [pUNC1, pUNC2, pINE1, pINE2, wlU, wlINS1, wlINS2] = ...
  welfmeas(DD,Cdec,Hdec,Ccert1,Ccert2,totCcert1,totCcert2,C,H,Y0,...
           TargetU,TargetINS1,TargetINS2,params);

beta = params(2);
gmma = params(3);
mu   = params(4);
zeta = params(5);
g    = params(6);


% Cost of uncertainty
pUNC1 = 1 - totCcert1 / C;
pUNC2 = 1 - totCcert2 / C;


% Cost of inequality
expH = exp(-(1-mu)*zeta*Hdec.^(1+gmma));
expHbar = exp(-(1-mu)*zeta*H^(1+gmma));
U1 = gridsum(DD,Y0^(1-mu) .* Ccert1.^(1-mu).* expH ./ (1-mu));
U2 = gridsum(DD,Y0^(1-mu) .* Ccert2.^(1-mu).* expHbar ./ (1-mu));
C1 = ((1-mu)*U1/expHbar)^(1/(1-mu)) / Y0;
C2 = ((1-mu)*U2/expHbar)^(1/(1-mu)) / Y0;
pINE1 = 1 - C1 / totCcert1;
pINE2 = 1 - C2 / totCcert2;


% Welfare loss compared to utilitarian benchmark
bigU = Y0^(1-mu) .* Cdec.^(1-mu).* expH ./ (1-mu);
u = gridsum(DD,bigU);
comp0 = (TargetU/u)^(1/(1-mu)) - 1;
equiv0 = 1-(u/TargetU)^(1/(1-mu));
wlU = equiv0;
  

% Welfare loss compare to insurance benchmark (initial H)
u = Y0^(1-mu) * totCcert1^(1-mu) * expHbar / (1-mu);
comp0 = (TargetINS1/u)^(1/(1-mu)) - 1;
equiv0 = 1-(u/TargetINS1)^(1/(1-mu));
wlINS1 = equiv0;
  

% Welfare loss compare to insurance benchmark (average H)
u = Y0^(1-mu) * totCcert2^(1-mu) * expHbar / (1-mu);
comp0 = (TargetINS2/u)^(1/(1-mu)) - 1;
equiv0 = 1-(u/TargetINS2)^(1/(1-mu));
wlINS2 = equiv0;
