Matlab code for "The Effectiveness of Government Debt and Transfers as Insurance",
Journal of Monetary Economics, 2001, 48(1), 81-108,
Martin Floden, Stockholm School of Economics

script_??.m calls main.m

script_bd.m replicates column (1) in Table 1.