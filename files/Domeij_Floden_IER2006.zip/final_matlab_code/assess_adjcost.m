function [X,XFracK,XFracY] = assess_adjcost(Kss,RESULTS,COUNTRY,PARAMS,iCTY)

beta            = PARAMS.beta;
mu              = PARAMS.mu;
psi             = PARAMS.psi;
gamma           = PARAMS.gamma;
xsi             = PARAMS.xsi;
alpha           = PARAMS.alpha;
delta           = COUNTRY(iCTY).delta;


cty = RESULTS.CTY(iCTY);
T   = length(cty.GDP);

c       = COUNTRY(iCTY);
totpop  = c.totpop;
Y       = totpop .* cty.GDP;
dp      = totpop(2:end)./totpop(1:end-1);
    
k1      = cty.K .* totpop;
k0      = [Kss(iCTY)*totpop(1)/(1+gamma); k1(1:end-1)];
k2      = [k1(2:end); k1(end)*(1+gamma)];
delta1  = (1+delta)^(1/5)-1;
X       = 5 * xsi * (abs((k1./k0).^(1/5) - (1-delta1))).^alpha .* k0;

XFracK  = X ./ k1;
XFracY  = X ./ Y;

fprintf(1,'=============================================================\n')
fprintf(1,'Average adjustment cost relative to capital stock: %2.4e\n',mean(XFracK))
fprintf(1,'Average adjustment cost relative to output:        %2.4e\n',mean(XFracY))
fprintf(1,'=============================================================\n')


