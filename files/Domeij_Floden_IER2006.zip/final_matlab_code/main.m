% Some definitions:
%
% N               = # of adult time periods (with consumption decisions) (i.e. around 80)
% NCHILD          = # of childhood periods
% NLIFE           = N + NCHILD
% CHILDREN_PERIOD = adult period in which children are born

clear all
load data\popdata

% =============================================================================================
% Settings
% *** Make sure to use correct PARAMS.beq below if settings are changed ***
% =============================================================================================
AUERBACH_KOTLIKOFF_LIFECYCLE     = 0;
T                                = 71;
SHIFT_SS                         = 10;                % # of periods to shift ss back from 1950
USECTY                           = [1:14 15:19];      % countries to include
ADJCOST                          = 1;                 % adjustment cost for capital?
INITIALLY_CLOSED                 = 0;                 % closed in initial ss?
SAVE                             = 1;                 % save solution?
PENSION_SYSTEM                   = 2;                 % 0 = no, 1 = DC, 2 = DB
ONLY_SS                          = 0;

% =============================================================================================
% Parameter values etc
% =============================================================================================
PARAMS.mu                 = 2;
PARAMS.gamma              = 1.0105^5-1;
PARAMS.xsi                = ADJCOST*0.5495;           % adj. cost for capital
PARAMS.alpha              = 1.8197;                   % curvature for adj. cost for capital
PARAMS.N                  = 16;
PARAMS.NCHILD             = 4;
PARAMS.NWORK              = 9;
PARAMS.NLIFE              = 20;
PARAMS.NPARENT            = 6;
PARAMS.psi                = 0.5;
PARAMS.beq_age            = 14;                      % bequests given at end of this age
PARAMS.PENSION_SYSTEM     = PENSION_SYSTEM;


% =============================================================================================

PARAMS.beq                = 4.220;                   % mu=2, nparent=6, NC, all, DB
PARAMS.beta               = 0.9516^5;                % mu=2, nparent=6, NC, all, DB
Delta                     = 0.0530*ones(1,19);

PARAMS.beq                = 3.180;                   % mu=2, nparent=6, AC, oecd, DB
PARAMS.beta               = 0.9510^5;                % mu=2, nparent=6, AC, oecd, DB
Delta                     = 0.0515*ones(1,19);

PARAMS.beq                = 4.810;                   % mu=2, nparent=6, AC=2, all, DB
PARAMS.beta               = 0.9600^5;                % mu=2, nparent=6, AC=2, all, DB
Delta                     = 0.0535*ones(1,19);

PARAMS.beq                = 1.616;                   % mu=1, nparent=6, AC, all, DB
PARAMS.beta               = 0.9460^5;                % mu=1, nparent=6, AC, all, DB
Delta                     = 0.0540*ones(1,19);

PARAMS.beq                = 3.550;                   % mu=2, nparent=6, AC, all, NO
PARAMS.beta               = 0.9527^5;                % mu=2, nparent=6, AC, all, NO
Delta                     = 0.0520*ones(1,19);

PARAMS.beq                = 4.540;                   % mu=2, nparent=6, AC, all, DB, shiftss=0
PARAMS.beta               = 0.9562^5;                % mu=2, nparent=6, AC, all, DB, shiftss=0
Delta                     = 0.0530*ones(1,19);

PARAMS.beq                = 7.300;                   % mu=2, nparent=6, AC, all, DB, init closed, shiftss=0
PARAMS.beta               = 0.9485^5;                % mu=2, nparent=6, AC, all, DB, init closed, shiftss=0
Delta                     = 0.0510*ones(1,19);

PARAMS.beq                = 4.480;                   % mu=2, nparent=6, AC, all, DB, deltas
PARAMS.beta               = 0.9562^5;                % mu=2, nparent=6, AC, all, DB, deltas
Delta                     = [0.057 0.057 0.044 0.026 0.043 0.039 0.044 0.032 0.026 ...
                             0.049 0.044 0.058 0.058 0.081 0.025 0.068 0.032 0.029 0.025];

PARAMS.beq                = 4.988;                   % mu=2, nparent=6, AC, all, DB separate
PARAMS.beta               = 0.9562^5;                
Delta                     = 0.0535*ones(1,19);

PARAMS.beq                = 4.530;                   % BASELINE: mu=2, nparent=6, AC, all, DB
PARAMS.beta               = 0.9562^5;                
Delta                     = 0.0535*ones(1,19);





% =============================================================================================
% Initital calculations and specifications
% =============================================================================================

N                    = PARAMS.N;
NCHILD               = PARAMS.NCHILD;
NWORK                = PARAMS.NWORK;
NLIFE                = PARAMS.NLIFE;

NC                   = length(USECTY);                % # of countries
iUS                  = 13;                            % index to US
iROW                 = 14;                            % index to ROW

n                    = size(POP(iUS).pop,1);
if n < T-SHIFT_SS
    for cty = USECTY;
        POP(cty).pop  = [POP(cty).pop; ones(T-n,1)*POP(cty).pop(end,:)];
    end
end 

if AUERBACH_KOTLIKOFF_LIFECYCLE
  life_prod   = [exp(4.47 + 0.033*((20:64)-20) - 0.00067*((20:64)-20).^2) zeros(1,5*N-45)];
  PARAMS.life_prod   = life_prod(3:5:end)/mean(life_prod(1:45));
else
  age_part           = [65.9 84.6 84.7 82.5 59.3];     % Participation rates for ages
                                                       % 16-24, 25-34, 35-44, 45-54, 55-64
                                                       % source = Fullerton H. N., Monthly Labor Review, 1999(112), 3-12
  age_prod           = [0.71 0.99 1.15 1.15 1.11];     % Productivity for ages
                                                       % 20-24, 25-34, 35-44, 45-54, 55-64
                                                       % source = Hansen, G. D., J. of Applied Econometrics, 1993(8), 71-80
  prod               = age_part.*age_prod;
  
  prod               = interp1([5 6.5 8.5 10.5 12.5],prod,5:13,'spline');
  prod               = prod./mean(prod);
  PARAMS.life_prod   = [prod zeros(1,N-length(prod))];
end


% Labor productivity 1998. Source = Maddison, 2002, 'The World Economy', table E7
TFP                  = [33.57 26.04 26.18 25.69 ...
                        33.72 26.56 27.90 30.62 ...
                        21.94 21.94 26.27 27.45 ...
                        34.55  5.00 26.93 27.05 ...
                        22.54 27.07 24.81];        
TFP(iROW)            = 0.10*TFP(iUS);                
TFP                  = TFP/TFP(iUS);
for cty = USECTY; COUNTRY(cty).LABPROD = TFP(cty); end
clear n TFP prod age_part age_prod

% Shift steady state? If not, ss year is 1950
if SHIFT_SS > 0
    for cty = USECTY;
        POP(cty).totpop = [ones(SHIFT_SS,1)*POP(cty).totpop(1,:); POP(cty).totpop];
        POP(cty).pop    = [ones(SHIFT_SS,1)*POP(cty).pop(1,:); POP(cty).pop];
    end
end



% Specify country-specific pension
% Assume pay-as-you-go and dc, so specify contribution rate
if PENSION_SYSTEM == 1
    tauP    = ones(1,19)*0.20;
      tauP=tauP*2;
elseif PENSION_SYSTEM == 2
    tauP    = ones(1,19)*0.04;
%    tauP    = [0.0745 0.0530 0.0600 0.055 0.1165 0.091 0.0997 0.0760 0.0360 0.0605 ...
%               0.0618 0.0863 0.0552 0.014 0.0330 0.054 0.0320 0.1040 0.0895];
else
    tauP    = zeros(1,19);
end
Theta = 0.36*ones(1,19);
for cty = USECTY
    COUNTRY(cty).tauP  = tauP(cty);
    COUNTRY(cty).delta = 1 - (1-Delta(cty))^5;
    COUNTRY(cty).theta = Theta(cty);
end



% =============================================================================================
% Solve for initial ss
% =============================================================================================
if INITIALLY_CLOSED
% =============================================================================================
% Countries are closed in initial ss
% =============================================================================================

options = optimset('Diagnostics','off','Display','off','MaxIter',20,...
          'TolFun',1e-12,'LargeScale','on',...
          'JacobPattern',[],'LevenbergMarquardt','off',...
          'TolX',1e-12);
    
for cty = USECTY
    icty                         = find(cty == USECTY);
    pop_struct                   = POP(cty).pop(1,:); 
    COUNTRY(cty).pop_struct      = pop_struct / sum(pop_struct);
    COUNTRY(cty).totpop          = 1;

    minx = [-COUNTRY(cty).delta 1e-2 0];
    maxx = [0.2 4 1000];
    x    = [0.035183 0.6122 2.561292];

    [x,f]              = lsqnonlin('solve_world_ss',x,minx,maxx,options,COUNTRY(cty),PARAMS);
    [f,country_output] = solve_world_ss(x,COUNTRY(cty),PARAMS);
    if f*f' > 1e-12
        [x,f]          = lsqnonlin('solve_world_ss',x,x*0.95,x*1.05,options,COUNTRY(cty),PARAMS);
        [x,f]          = fsolve('solve_world_ss',x,options,COUNTRY(cty),PARAMS);
    end
    [f,country_output] = solve_world_ss(x,COUNTRY(cty),PARAMS);
    if f*f' > 1e-12, fprintf(1,'Warning: ss-solution bad, country = %2d, f^2 = %12.4e\n',cty,f*f'), end
    output(icty)   = country_output;
    r_ss(icty)     = x(1);
    H_ss(icty)     = x(2);
    B_ss(icty)     = x(3);
    K_ss(icty)     = country_output.K;
    A_ss(icty)     = country_output.A;
    Q_ss(icty)     = country_output.Q;

    fprintf('SS solution: r = %8.6f, (1+r)*beta/(1+g) = %8.6f, cty = %2d\n',...
        r_ss(icty),(1+r_ss(icty))*PARAMS.beta/(1+PARAMS.gamma),cty)

end

else
% =============================================================================================
% Countries are open in initial ss
% =============================================================================================

worldpop = 0;
for cty = USECTY; worldpop = worldpop + POP(cty).totpop(1); end
for cty = USECTY
    pop_struct                   = POP(cty).pop(1,:); 
    COUNTRY(cty).pop_struct      = pop_struct / sum(pop_struct);
    COUNTRY(cty).totpop          = POP(cty).totpop(1)/worldpop;
end

minx = [-min([COUNTRY.delta]) ones(1,NC)*1e-4 zeros(1,NC)];
maxx = [0.9 ones(1,NC)*4 ones(1,NC)*1000];
x    = [0.2 ones(1,NC)*0.5 ones(1,NC)];

JacPat  = diag(ones(1+2*NC,1));
for i=1:0
  JacPat = JacPat + diag(ones(1+2*NC-i,1),-i) + diag(ones(1+2*NC-i,1),i);
end

options = optimset('Diagnostics','off','Display','iter','MaxIter',20,...
          'TolFun',1e-12,'LargeScale','on','Jacobian','off',...
          'JacobPattern',[],'LevenbergMarquardt','off',...
          'TolX',1e-12);

if 3>2
load results_ss
x          = [r_ss H_ss B_ss];
minx       = [-min([COUNTRY.delta])+0.01 H_ss/3 B_ss/100];
maxx       = [r_ss+0.2 H_ss*3 B_ss*100];
end

[x,f]      = lsqnonlin('solve_world_ss',x,minx,maxx,options,COUNTRY(USECTY),PARAMS);
[f,output] = solve_world_ss(x,COUNTRY(USECTY),PARAMS);
r_ss       = x(1);
H_ss       = x(2:1+NC);
B_ss       = x(2+NC:end);
K_ss       = [output.K];
A_ss       = [output.A];
Q_ss       = [output.Q];
save results_ss r_ss H_ss B_ss

fprintf('SS solution: r = %8.6f, (1+r)*beta/((1+g)^mu) = %8.6f\n',r_ss,(1+r_ss)*PARAMS.beta/((1+PARAMS.gamma)^PARAMS.mu))

end

clear x minx maxx worldpop

if ONLY_SS, break, end



% =============================================================================================
% Solve for development after initial ss
% =============================================================================================
rpath                        = r_ss(1) * ones(T,1);
worldpop                     = 0;
Hpath                        = zeros(NC*T,1);                     
Kguess                       = zeros(NC*T,1);                     
for cty = USECTY; worldpop = worldpop + POP(cty).totpop; end
for cty = USECTY
    icty                     = find(cty == USECTY);
    pop_struct               = POP(cty).pop(1:T,:); 
    COUNTRY(cty).pop_struct  = pop_struct ./ (sum(pop_struct')'*ones(1,NLIFE));
    tp                       = POP(cty).totpop / worldpop(1);
    if length(tp) >= T
        tp                   = tp(1:T);
    else
        tp                   = [tp; tp(end)*ones(T-length(tp),1)];
    end
    COUNTRY(cty).totpop      = tp;
    H                        = (COUNTRY(cty).pop_struct(:,NCHILD+1:end) * PARAMS.life_prod');
    H                        = H_ss(icty) * H / H(1);
    Hpath((icty-1)*T+(1:T))  = H;
    Kguess((icty-1)*T+(1:T)) = K_ss(icty);
end

clear tp H worldpop


% Calculate survival probabilities
for cty = USECTY
    totpop        = COUNTRY(cty).totpop;
    pop           = COUNTRY(cty).pop_struct .* (totpop*ones(1,20));
    fi            = pop(2:end,NCHILD+1:end) ./ pop(1:end-1,NCHILD:end-1);
    fi            = [fi(1,:); fi];
    FI            = zeros(T+N-1,N);
    for i = 1:T
        for j = 1:N
            if i+j-1 < T
                FI(i,j) = fi(i+j-1,j);
            else
                FI(i,j) = fi(T,j);
            end
        end
    end
    for i = 1:N-1
        for j = 1:N-i
            FI(T+i,j) = fi(i+j-1,i+j);
        end
    end
    COUNTRY(cty).FI    = FI;
    FI                 = zeros(N-1,N);
    for i = 1:N-1
        FI(i,1:i)      = fi(1,1:i);
        for j = i+1:N
            FI(i,j)    = fi(j-i,j);
        end
    end
    COUNTRY(cty).FI_ss = FI; 
end
clear FI fi totpop pop


GAMMA        = (1+PARAMS.gamma).^(0:N-1);
reverseGAMMA = GAMMA.^(-1);
initial_a    = zeros(NC,N);
for cty = USECTY
    icty              = find(cty == USECTY);
    initial_a(icty,:) = output(icty).a(1:end-1) .* reverseGAMMA;
end

% Assume all households have same portfolio shares in old ss
% Note: "surprise" return on all stocks is identical when leaving ss
% Calculate portfolio shares 
% ... use these to calculate portfolio return when r(1) is known
% Note: This requires that demographics does not change between initial
% ss and first period
tp = [];
for cty = USECTY
    tp = [tp POP(cty).totpop(1)];
end
ssA = tp*A_ss';
ssK = tp*K_ss';
ssQ = tp*Q_ss';
Qshare = (ssQ/(1+PARAMS.gamma))/ssA;

JacPat  = diag(ones(T,1));
for i=1:0
  JacPat = JacPat + diag(ones(T-i,1),-i) + diag(ones(T-i,1),i);
end
    

%figure
options = optimset('Diagnostics','off','Display','iter','MaxIter',5,...
          'TolFun',1e-10,'LargeScale','on','Jacobian','off',...
          'JacobPattern',JacPat,'LevenbergMarquardt','off',...
          'TolX',1e-12);
guess         = [rpath];
RPATH         = guess;




load solution RPATH
for i = 1:1
RPATH = fsolve('solve_world',RPATH,options,K_ss,r_ss,Hpath,Q_ss,Qshare,initial_a,COUNTRY(USECTY),PARAMS,0);
guessmin = min(0.99*RPATH,1.01*RPATH);
guessmax = max(1.01*RPATH,0.99*RPATH);
%RPATH = lsqnonlin('solve_world',RPATH,guessmin,guessmax,options,K_ss,r_ss,Hpath,Q_ss,Qshare,...
%                                initial_a,COUNTRY(USECTY),PARAMS,0);
end
save solution RPATH PARAMS
clear JacPat guess*


RESULTS = solve_world(RPATH,K_ss,r_ss,Hpath,Q_ss,Qshare,initial_a,COUNTRY(USECTY),PARAMS,1);
hhRPATH = [RESULTS.CTY(1).Rp-1; RPATH(2:end)];

% Calculate and store savings rate and investment ratio
delta1 = (1+[COUNTRY.delta]).^(1/5)-1;
tp  = [COUNTRY.totpop];
GDP = [RESULTS.CTY.GDP].*tp;
C   = [RESULTS.CTY.C].*tp;
K1  = [RESULTS.CTY.K].*tp;
A   = [RESULTS.CTY.A].*tp;
DIV = [RESULTS.CTY.DIV].*tp;
K0  = [K_ss.*tp(1,:)/(1+PARAMS.gamma); K1(1:end-1,:)];
K2  = [K1(2:end,:); K1(end,:)*(1+PARAMS.gamma)];
X   = 5 * PARAMS.xsi * (abs((K1./K0).^(1/5) - ones(T,1)*(1-delta1))).^PARAMS.alpha .* K0;
GNP = GDP + hhRPATH*ones(1,NC).*A - (RPATH*ones(1,NC).*K1 + DIV);
i   = (K2 - (1-ones(T,1)*[COUNTRY.delta]).*K1) ./ GDP;
s   = (GNP - C - X) ./ GDP;
ca  = [RESULTS.CTY.ca];
p   = [RESULTS.CTY.p];
fr  = [RESULTS.CTY.retired];
py  = p(1:71,:).*fr./(GDP./tp);                    % total pension benefits over output
RESULTS.ca = ca;
RESULTS.s  = s;
RESULTS.i  = i;
i1960 = 3 + SHIFT_SS;
i1990 = 9 + SHIFT_SS;
i2000 = 11 + SHIFT_SS;
fprintf(1,'Some statistics of the simulated economy:\n')
fprintf(1,'                         1960       1990       2000\n')
fprintf(1,'Average K/Y (annual)   %6.2f     %6.2f     %6.2f\n',5*mean(K1(i1960,:)./GDP(i1960,:)),5*mean(K1(i1990,:)./GDP(i1990,:)),5*mean(K1(i2000,:)./GDP(i2000,:)))
fprintf(1,'Average S/Y            %6.2f     %6.2f     %6.2f\n',mean(s(i1960,:)),mean(s(i1990,:)),mean(s(i2000,:)))
fprintf(1,'Average I/Y            %6.2f     %6.2f     %6.2f\n',mean(i(i1960,:)),mean(i(i1990,:)),mean(i(i2000,:)))
fprintf(1,'Average P/Y            %6.2f     %6.2f     %6.2f\n',mean(py(i1960,:)),mean(py(i1990,:)),mean(py(i2000,:)))
fprintf(1,'Adjustment costs, USA:\n')
[X,XFracK,XFracY]=assess_adjcost(K_ss,RESULTS,COUNTRY,PARAMS,13);
clear delta1 tp GDP C A K0 K1 K2 X GNP i s ca


% Test solution
cty     = 13;
icty    = find(cty == USECTY);
t       = 1;
w       = PARAMS.life_prod'.*RESULTS.CTY(icty).w(t:t+(N-1));
tauP    = RESULTS.CTY(icty).tauP(t:t+(N-1));
p       = RESULTS.CTY(icty).p(t:t+(N-1));
p(1:NWORK) = 0;
totpop  = COUNTRY(cty).totpop;
pop     = COUNTRY(cty).pop_struct .* (totpop*ones(1,20));
fi      = COUNTRY(cty).FI;
test_solution(RESULTS.CTY(icty).c(t,:),[RESULTS.CTY(icty).a(t,:).*fi(t,:) 0],(1-tauP)'.*w',p',...
              1+hhRPATH(t:t+(N-1))',fi(t,:),RESULTS.CTY(icty).b(t),COUNTRY(cty),PARAMS);
clear cty icty t w totpop pop fi nchild i j
 
test_world_solution(K_ss,Q_ss,RESULTS,COUNTRY(USECTY),PARAMS);


% Save solution?
if SAVE
    NAME = 'solution_';

    ca0 = RESULTS.ca;
    s0  = RESULTS.s;
    i0  = RESULTS.i;
    ca  = zeros(T,19);
    s   = zeros(T,19);
    i   = zeros(T,19);
    for cty = USECTY;
        icty = find(cty == USECTY);
        ca(:,cty) = ca0(:,icty);
        s(:,cty)  = s0(:,icty);
        i(:,cty)  = i0(:,icty);
    end
    
    if ADJCOST == 1
        NAME = [NAME 'adjcost_'];
    elseif ADJCOST == 2
        NAME = [NAME 'adjcost2_'];
    else
        NAME = [NAME 'nocost_'];
    end
    
    if NC == 19
        NAME = [NAME 'all_'];
    elseif NC == 18
        NAME = [NAME 'oecd_'];
    else
        NAME = [NAME num2str(NC) '_'];
    end

    if PENSION_SYSTEM == 0
        NAME = [NAME 'no_'];
    elseif PENSION_SYSTEM == 1
        NAME = [NAME 'dc_'];
    else
        NAME = [NAME 'db_'];
    end

    if INITIALLY_CLOSED
        NAME = [NAME 'closed_'];
    else
        NAME = [NAME 'open_'];
    end
    
    NAME = [NAME 'ss' num2str(SHIFT_SS)];

    save(NAME,'RPATH','PARAMS','USECTY','ca','s','i');
end
clear ca s i 