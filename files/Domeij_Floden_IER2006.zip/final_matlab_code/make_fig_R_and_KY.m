ii = 11:51;              % 1:71 = 1900-2250

K  = [RESULTS.CTY.K];
Y  = [RESULTS.CTY.GDP];
yy = 1900:5:2250;

set(0,'DefaultAxesColorOrder',[0 0 0; ones(20,1)*[0 0 1]],...
      'DefaultAxesLineStyleOrder','-')
[pl,h1,h2] = plotyy(yy(ii),(1+RPATH(ii)).^(1/5)-1,yy(ii),5*K(ii,:)./Y(ii,:));
set(h1,'LineWidth',2)
set(pl(1),'YLim',[0.04 0.07])
set(pl(2),'YLim',[2.5 4])
set(pl(1),'YTick',[0.04 0.05 0.06 0.07])
set(pl(2),'YTick',[2.5 3 3.5 4])

xlabel('year')
gtext('r (left scale)')
gtext('K/Y (right scale)')

