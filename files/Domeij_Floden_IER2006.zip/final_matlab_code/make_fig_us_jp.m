file1 = 'solution_adjcost_all_db_open_ss10';
file2 = 'solution_adjcost_oecd_db_open_ss10';

load(file1,'ca'); ca_all  = 100*ca;
load(file2,'ca'); ca_oecd = 100*ca; clear ca;
load('data\OECD_NA');
ca_data = 100*[OECD.ca];

year = 1900:5:2250;
ii   = 13:21;

figure
subplot(2,2,1)
plot((1960:2002),ca_data(18,1:43),'b-',...
     (1960:2002),ca_data(11,1:43),'r--','LineWidth',1.5);
axis([1960 2005 -10 12])
title('Data')

subplot(2,2,3)
plot(year(ii)+2.5,ca_all(ii,13),'b-',...
     year(ii)+2.5,ca_all(ii,17),'r--','LineWidth',1.5);
axis([1960 2005 -10 12])
title('Baseline model')

subplot(2,2,4)
plot(year(ii)+2.5,ca_oecd(ii,13),'b-',...
     year(ii)+2.5,ca_oecd(ii,17),'r--','LineWidth',1.5);
axis([1960 2005 -10 12])
title('OECD')
ll = legend('United States','Japan');
legend('boxoff');
set(ll,'FontSize',8);

