function [b,stdb,R2] = regress(X,Y);

[T,k] = size(X); 
b     = inv(X'*X)*X'*Y;
u     = Y - X*b;
SSE   = u'*u;
SSR   = (Y-mean(Y))'*(Y-mean(Y));
R2    = 1-SSE/SSR;
s2    = SSE /(T-k);
S     = s2*inv(X'*X);
stdb  = sqrt(diag(S));
