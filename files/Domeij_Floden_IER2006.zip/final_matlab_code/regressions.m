clear all
load data\OECD_NA

% ===========================================
% MODEL SPECIFICATION
% ===========================================
ADJCOST           = 1;
SHIFT_SS          = 10;
NC                = 19;
INITIALLY_CLOSED  = 0;  
PENSION_SYSTEM    = 2;                             % 1 = DC, 2 = DB

% ===========================================
% REGRESSIONS AND PROGRAM OUTPUT
% ===========================================
VARIABLE          = 'C';                           % C=CA, S, or I
FIRSTYEAR         = 1960;
FINALYEAR         = 2002;
FIXED_EFF         = 1;
PLOTS             = 1;
ANNUAL_PLOT       = 1;
REGRESSION_PLOT   = 0;
POOLED_OLS        = 0;
FILTER            = 0;


% misc
PERLENGTH         = 5;


% ===========================================
% Load ca data
% ===========================================
NAME = 'solution_';
if ADJCOST == 1
    NAME = [NAME 'adjcost_'];
elseif ADJCOST == 2
    NAME = [NAME 'adjcost2_'];
else
    NAME = [NAME 'nocost_'];
end
    
if NC == 19
    NAME = [NAME 'all_'];
elseif NC == 18
    NAME = [NAME 'oecd_'];
else
    NAME = [NAME num2str(NC) '_'];
end

if PENSION_SYSTEM == 0
    NAME = [NAME 'no_'];
elseif PENSION_SYSTEM == 1
    NAME = [NAME 'dc_'];
else
    NAME = [NAME 'db_'];
end


if INITIALLY_CLOSED
    NAME = [NAME 'closed_'];
else
    NAME = [NAME 'open_'];
end
    
NAME = [NAME 'ss' num2str(SHIFT_SS)];

if VARIABLE == 'C'
    load(NAME,'ca');
    V = ca;
    OECDV = [OECD.ca];
    clear ca
elseif VARIABLE == 'S'
    load(NAME,'s');
    V = s;
    OECDV = [OECD.s];
    clear s
else
    load(NAME,'i');
    V = i;
    OECDV = [OECD.i];
    clear i
end


CTYlist = ['AUS'; 'AUT'; 'BEL'; 'CAN'; 'DNK'; ...
           'FIN'; 'FRA'; 'GER'; 'IRL'; 'ITA'; ...
           'JPN'; 'NLD'; 'PRT'; 'SPA'; 'SWE'; ...
           'SWI'; 'UK '; 'USA'];

CTYindx = [15; 18; 1; 2; 3; ...
           4; 5; 6; 16; 7; ...
           17; 8; 9; 10; 11; ...
           19; 12; 13];

country = [...
   'Belgium       '; ...
   'Canada        '; ...
   'Denmark       '; ...
   'Finland       '; ...
   'France        '; ...
   'Germany       '; ...
   'Italy         '; ...
   'Netherlands   '; ...
   'Portugal      '; ...
   'Spain         '; ...
   'Sweden        '; ...
   'United Kingdom'; ...
   'United States '; ...
   'ROW           '; ...
   'Australia     '; ...
   'Ireland       '; ...
   'Japan         '; ...
   'Austria       '; ...
   'Switzerland   '];
       
useCTY  = 1:18;
%useCTY  = [1 2 3 4 7 9 10 6 12 13 14 15 16 8 17 5 11 18];
nC      = length(useCTY);
Y       = []; YY = [];
X       = []; XX = [];
Z       = [];


for cty = useCTY

  OECDy  = OECD.y(cty,:);
  OECDv  = OECDV(cty,:).*OECDy;
  
  keep    = find(isnan(OECDv)==0);
  OECDv   = OECDv(keep)';
  OECDy   = OECDy(keep)';
  yr      = OECD.year(keep)';
  Z       = [Z; [100*OECDv./OECDy cty*ones(length(OECDv),1) yr]];

  if rem(FIRSTYEAR,5) > 0, fprintf(1,'Warning: FIRSTYEAR should be multiple of 5\n'); end
  
  % convert to 5-year averages (or other depending on PERLENGTH)
  j = 1;
  OECDv5=[]; yr5=[]; V5=[];
  for i = FIRSTYEAR:PERLENGTH:FINALYEAR
      iyr = find(yr >= i & yr < i+PERLENGTH);
      if isempty(iyr), continue, end
      OECDv5(j)  = 100*sum(OECDv(iyr)) / sum(OECDy(iyr));
      yr5(j)     = i;
      Vindx      = (i-1949+SHIFT_SS*5-1)/5 + 1;
      
      if PERLENGTH == 5
          V5(j)      = 100*V(Vindx,CTYindx(cty));
      elseif PERLENGTH == 10
          V5(j)      = 100*mean(V(Vindx:Vindx+1,CTYindx(cty)));
      else
          'Error!!!'
      end
      
      Y          = [Y; OECDv5(j)];
      cdum       = zeros(1,nC);
      cdum(find(useCTY==cty))  = 1;
      X          = [X;  V5(j) cdum yr5(j)];
          
      j      = j + 1;
  end
       
end

YR      = X(:,end);
yr      = YR - FIRSTYEAR;
fullX   = X;
X       = X(:,1:end-1);
[T,k]   = size(X);


% %%%%%
w1 = 1;
w2 = 2;
w3 = 1;
newY = zeros(T,1);
for i = 2:k
    ii   = find(X(:,i)==1);
    ni   = length(ii);
    for j = 1:ni
        yr2 = yr(ii(j));
        weight = 0;
        if j == 1
          yr3 = yr(ii(j+1));
          if yr3-yr2 == 5
              weight = weight + w3;
              newY(ii(j)) = newY(ii(j)) + w3*Y(ii(j+1));
          end
          weight = weight + w2;
          newY(ii(j)) = newY(ii(j)) + w2*Y(ii(j));
          newY(ii(j)) = newY(ii(j)) / weight;

        elseif j == ni
          yr1 = yr(ii(j-1));
          if yr2-yr1 == 5
              weight = weight + w1;
              newY(ii(j)) = newY(ii(j)) + w1*Y(ii(j-1));
          end
          weight = weight + w2;
          newY(ii(j)) = newY(ii(j)) + w2*Y(ii(j));
          newY(ii(j)) = newY(ii(j)) / weight;

        else
          yr1 = yr(ii(j-1));
          yr3 = yr(ii(j+1));
          if yr2-yr1 == 5
              weight = weight + w1;
              newY(ii(j)) = newY(ii(j)) + w1*Y(ii(j-1));
          end
          if yr3-yr2 == 5
              weight = weight + w3;
              newY(ii(j)) = newY(ii(j)) + w3*Y(ii(j+1));
          end
          weight = weight + w2;
          newY(ii(j)) = newY(ii(j)) + w2*Y(ii(j));
          newY(ii(j)) = newY(ii(j)) / weight;
        end
    end
end

if FILTER
Y = newY;
end



X_Chow  = [X ((YR>=1985)*ones(1,size(X,2))).*X];            % Chow test of diff 1960 - 1985 using fixed effects panel
X_Pool  = [ones(T,1) X(:,1)];                               % Used for pooled ols
X_PC    = [X_Pool ((YR>=1985)*ones(1,2)).*X_Pool];          % Used for pooled ols
X_Expl  = X(:,1);                                           % Used to calculate R2X (remove country-specific means)
Y_Expl  = Y;
for i = 2:k
    ii         = find(X(:,i)==1);
    Y_Expl(ii) = Y(ii) - mean(Y(ii));
    X_Expl(ii) = X(ii,1) - mean(X(ii,1));
end
X_E85  = X(:,1);                                             % Used to calculate R2X (remove country-specific means)
Y_E85  = Y;
for i = 2:k
    ii         = intersect(find(X(:,i)==1),find(YR>=1985));   
    Y_E85(ii)  = Y(ii) - mean(Y(ii));
    X_E85(ii)  = X(ii,1) - mean(X(ii,1));
end

[b,stdb,R2]                = regress(X,Y);
[b_Chow,stdb_Chow,R2_Chow] = regress(X_Chow,Y);
[b_Pool,stdb_Pool,R2_Pool] = regress(X_Pool,Y);
[b_PC,stdb_PC,R2_PC]       = regress(X_PC,Y);
[b_Expl,stdb_Expl,R2_Expl] = regress(X_Expl,Y_Expl);
ii                         = find(YR>=1985);
[b_85,stdb_85,R2_85]       = regress(X(ii,:),Y(ii));
[b_P85,stdb_P85,R2_P85]    = regress(X_Pool(ii,:),Y(ii));
[b_E85,stdb_E85,R2_E85]    = regress(X_E85(ii),Y_E85(ii));


fprintf(1,'================================================================\n')
fprintf(1,'Tested variable: %1s\n',VARIABLE)
fprintf(1,'                         1960-2002               1985-2002\n')
fprintf(1,'Fixed effects panel:\n')
fprintf(1,'model X                    %5.2f                   %5.2f\n',b(1),b_85(1))
fprintf(1,'                          (%5.2f)                 (%5.2f)\n',stdb(1),stdb_85(1))
fprintf(1,'Chow 85-60                                         %5.2f\n',b_Chow(k+1))
fprintf(1,'                                                  (%5.2f)\n',stdb_Chow(k+1))
fprintf(1,'R2                         %5.2f                   %5.2f\n',R2,R2_85)
fprintf(1,'R2X                        %5.2f                   %5.2f\n',R2_Expl,R2_E85)
fprintf(1,'# expl variables           %5d                   %5d\n\n',k,k)
fprintf(1,'Pooled OLS:\n')
fprintf(1,'constant                   %5.2f                   %5.2f\n',b_Pool(1),b_P85(1))
fprintf(1,'                          (%5.2f)                 (%5.2f)\n',stdb_Pool(1),stdb_P85(1))
fprintf(1,'model X                    %5.2f                   %5.2f\n',b_Pool(2),b_P85(2))
fprintf(1,'                          (%5.2f)                 (%5.2f)\n',stdb_Pool(2),stdb_P85(2))
fprintf(1,'Chow 85-60                                         %5.2f\n',b_PC(4))
fprintf(1,'                                                  (%5.2f)\n',stdb_PC(4))
fprintf(1,'R2                         %5.2f                   %5.2f\n\n',R2_Pool,R2_P85)
fprintf(1,'# obs                      %5d                   %5d\n',T,length(ii))
fprintf(1,'================================================================\n')


% Plots
if PLOTS 
if POOLED_OLS
    YHAT = X_Pool*b_Pool;
elseif FIXED_EFF    
    YHAT = X*b;
else
    YHAT = X_Expl*b_Expl;
end
m = 1;
for i = 2:k
    ii = find(fullX(:,i)==1);
    if m == 7, figure, m=1; end
    subplot(3,2,m); m=m+1;
    if ANNUAL_PLOT
        jj = find(Z(:,2)==useCTY(i-1));
        if REGRESSION_PLOT
            plot(Z(jj,3),Z(jj,1),'b-',YR(ii)+2.5,X(ii,1),'r--',...
                 YR(ii)+2.5,YHAT(ii),'m-.','LineWidth',1.5);
        else
            plot(Z(jj,3),Z(jj,1),'b-',YR(ii)+2.5,X(ii,1),'r--',...
                 'LineWidth',1.5);
        end
    else
        if REGRESSION_PLOT
            plot(YR(ii),Y(ii),'b-',YR(ii),X(ii,1),'r--',...
                 YR(ii),YHAT(ii),'m-.','LineWidth',1.5);
        else
            plot(YR(ii),Y(ii),'b-',YR(ii),X(ii,1),'r--',...
                 'LineWidth',1.5);
        end
    end
    if VARIABLE == 'C'; axis([FIRSTYEAR 2003 -14 14]); 
    else axis([FIRSTYEAR 2003 14 40]);  end
    title(country(CTYindx(useCTY(i-1)),:));
    if m == 7; 
        if REGRESSION_PLOT
            ll = legend('data','model','regression',3); 
        else
            ll = legend('data','model',3); 
        end
        legend('boxoff');
        set(ll,'FontSize',8);
    end
end
end
