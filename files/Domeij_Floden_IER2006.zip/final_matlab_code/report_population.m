;% Generate graphs on demographic developmen
% For use in appendix
%

clear all
load data\popdata
YEARS = 1950:5:2250;
ii    = 1:61;

CTYindx = [15; 18; 1; 2; 3; ...
            4; 5; 6; 16; 7; ...
            17; 8; 9; 10; 11; ...
            19; 12; 13; 14];


tp = [POP.totpop];
tp = sum(tp')';
workers = 0;
for i = CTYindx'
    workers = workers + sum(POP(i).pop(:,5:13)')';
end
subplot(2,2,1);
[ax,h1,h2] = plotyy(YEARS(ii),tp(ii)/1000,...
     YEARS(ii),workers(ii)./tp(ii));
set(h1,'Color',[0 0 1]) 
set(h2,'Color',[1 0 0]) 
set(h1,'LineWidth',1.5) 
set(h2,'LineWidth',1.5) 
set(h1,'LineStyle','-') 
set(h2,'LineStyle',':') 
set(ax(1),'YColor',[0 0 1])
set(ax(2),'YColor',[1 0 0])
title('World');
       
m = 2;
for i = CTYindx'
    if m == 5, figure, m=1; end
    subplot(2,2,m); m=m+1;

    [ax,h1,h2] = plotyy(YEARS(ii),POP(i).totpop(ii)/1000,...
         YEARS(ii),sum(POP(i).pop(ii,5:13)')'./POP(i).totpop(ii));
    set(h1,'Color',[0 0 1]) 
    set(h2,'Color',[1 0 0]) 
    set(h1,'LineWidth',1.5) 
    set(h2,'LineWidth',1.5) 
    set(h1,'LineStyle','-') 
    set(h2,'LineStyle',':') 
    set(ax(1),'YColor',[0 0 1])
    set(ax(2),'YColor',[1 0 0])
    if strcmp(POP(i).cty,'Netherl. ')
        title('Netherlands')
    elseif strcmp(POP(i).cty,'Switz.   ')
        title('Switzerland')
    elseif strcmp(POP(i).cty,'U.K.     ')
        title('United Kingdom')
    elseif strcmp(POP(i).cty,'USA      ')
        title('United States')
    elseif strcmp(POP(i).cty,'ROW      ')
        title('Rest of the World')
    else
        title(strtrim(POP(i).cty));
    end
end

fprintf(1,'Solid line  = total population (millions, left scale)\n');
fprintf(1,'Dotted line = fraction of population in age 20-64 (right scale)\n');

