function [TOT_A,Qpath,output] = solve_country(rpath,Hpath,Kpath,Kss,Qss,Qshare,initial_a,COUNTRY,PARAMS)
%
% Input:
% rpath[T,1]           = path for interest rate
% Hpath
% Kpath[T,1]   
% fi[T,N]              : fi(t,age) = survival prob from age-1 to age of ind. born in year t
% initial_a[1,N]      : initial_a(y+1) = initial assets for those who entered the labor market y years ago
%
%
% in COUNTRY(struct)
% pop_struct[T,NLIFE]  = fraction of individuals of age x in any year
% LABPROD              = labor productivity relative to US 1950
%
%
% in PARAMS (struct)
% mu, beta, gamma, N, NLIFE, NCHILD, CHILDREN_PERIOD,
% psi[1,NCHILD]        = consumption of children relative to parent
% life_prod[1,N]       = labor productivity over life cycle
%
% Output:
% TOT_A     [T,1]      = total asset holdings
% Qpath     [T,1]      = value of representative firm
% output    [STRUCT]   = other results



N               = PARAMS.N;
NCHILD          = PARAMS.NCHILD;
NWORK           = PARAMS.NWORK;
NPARENT         = PARAMS.NPARENT;
life_prod       = PARAMS.life_prod;
psi             = PARAMS.psi;
gamma           = PARAMS.gamma;
BA              = PARAMS.beq_age;
PENSION_SYSTEM  = PARAMS.PENSION_SYSTEM;


LABPROD         = COUNTRY.LABPROD;
pop_struct      = COUNTRY.pop_struct;
fi              = COUNTRY.FI;
fi_ss           = COUNTRY.FI_ss;
tauP            = COUNTRY.tauP;
delta           = COUNTRY.delta;
theta           = COUNTRY.theta;


T               = length(rpath);
extend          = [(1:T)'; T*ones(N-1,1)];                      % add values at end to solve for final cohorts
rpath           = rpath(extend);

iPARENT         = NCHILD + (1:NPARENT);

% Population shares
frac_children   = sum(pop_struct(:,1:NCHILD)')';
frac_workers    = sum(pop_struct(:,NCHILD+1:NCHILD+NWORK)')';
frac_retired    = sum(pop_struct(:,NCHILD+NWORK+1:end)')';


GAMMA           = (1+gamma).^(0:T-1+N-1)';
Kpath           = [Kpath; Kpath(end)*GAMMA(T+1:end)/GAMMA(T)];
Hpath           = [Hpath; Hpath(end)*ones(size(GAMMA(T+1:end)))];
Ypath           = Kpath.^theta .* (LABPROD*GAMMA.*Hpath).^(1-theta);      % Output (per capita)

xsi             = PARAMS.xsi;
alpha           = PARAMS.alpha;
totpop          = COUNTRY.totpop;
k1              = Kpath(1:T) .* totpop;
k0              = [Kss/(1+gamma); Kpath(1:T-1)] .* totpop([1 1:T-1]);
delta1          = (1+delta)^(1/5)-1;
X               = 5 * xsi * (abs((k1./k0).^(1/5) - (1-delta1))).^alpha .* k0;
X               = X ./ totpop;                                            % Adjustment cost per capita
X               = [X; X(end)*GAMMA(T+1:end)/GAMMA(T)];


wpath           = (1-theta) * Ypath ./ Hpath;
DIVpath         = Ypath - (rpath + delta).*Kpath - X - wpath.*Hpath;
DIVpath         = DIVpath(1:T) .* totpop(1:T);

Hpath           = Hpath(1:T);
Rpath           = 1 + rpath;
GDP             = Ypath(1:T);

Rprod           = cumprod([1; 1./Rpath(2:end)]);
Qpath           = zeros(T,1);
Qpath(1)        = sum(Rprod(2:T-1).*DIVpath(2:T-1)) + Rprod(T)*DIVpath(T)/(1-(1+gamma)/Rpath(T));
for t = 2:T
    Qpath(t) = Rpath(t) .* Qpath(t-1) - DIVpath(t);
end
DIVpath         = DIVpath ./ totpop;
Qpath           = Qpath ./ totpop;


% Calculate portfolio return between old ss and t=1
if abs(Qss)>1e-12
    Rq      = (Qpath(1)+DIVpath(1)) / (Qss/(1+gamma));       % gross return on shares
    Rp      = Qshare*Rq + (1-Qshare)*Rpath(1);    % gross portfolio return
else 
    Rp  = Rpath(1);
end
hhRpath = [Rp; Rpath(2:end)];                 % household's interest rate


if PENSION_SYSTEM > 1
    xP          = tauP * frac_workers(1) ./ frac_retired(1);
    tauP        = xP * frac_retired ./ frac_workers;
else
    tauP        = tauP * ones(size(GDP));
end
ppath           = tauP .* wpath(1:T) .* Hpath ./ frac_retired;
ppath           = [ppath; ppath(end)*(1+gamma).^((1:N-1)')];
tauP            = [tauP; tauP(end)*ones(N-1,1)];




Bequest         = [initial_a(1); zeros(T-1,1)];

SAVE_C0          = zeros(N-1,N);
SAVE_H0          = zeros(N-1,N);
SAVE_E0          = zeros(N-1,N);
SAVE_T0          = zeros(N-1,N);
SAVE_A0          = zeros(N-1,N);
SAVE_C           = zeros(T,N);
SAVE_H           = zeros(T,N);
SAVE_E           = zeros(T,N);
SAVE_T           = zeros(T,N);
SAVE_A           = zeros(T,N);

h                = 1;

% Solve for those who also ever worked in old steady state
for i = 1:N-1
    Wlife           = (1-tauP(1:N-i)) .* life_prod(i+1:end)' .* wpath(1:N-i);      % wage over life cycle
    Plife           = [zeros(NWORK-i,1); ppath(max(1,NWORK+1-i):N-i)];             % pension over life cycle

    nChildren       = zeros(1,N-i);
    for j = 1:NPARENT-i
        nChildren(j) = sum(pop_struct(j,1:NCHILD)) / sum(pop_struct(j,iPARENT));
    end
    Psi             = 1 + nChildren*psi;

    PARAMS.beq_age  = BA - i;
    disp_y          = Wlife'.*h + Plife';
    [c,a,b]         = solve_household(disp_y,hhRpath(1:N-i)',fi_ss(i,1+i:end),...
                                        initial_a(i+1),Psi,PARAMS);
    SAVE_C0(i,1:N-i) = c;
    SAVE_H0(i,1:N-i) = h;
    SAVE_E0(i,1:N-i) = life_prod(i+1:end).*h;
    SAVE_T0(i,1:N-i) = c + 0*Psi.*c;
    SAVE_A0(i,1:N-i) = a(1:end-1)./fi_ss(i,1+i:end);
    if BA-i > NCHILD
        j            = 1 + BA - i - NCHILD;
        Bequest(j)   = b * pop_struct(j-1,BA) / pop_struct(j-1,NCHILD);
    end
end
PARAMS.beq_age       = BA;

% Solve for those who entered labor market after old steady state
for i = 1:T
    Wlife           = (1-tauP(i:i+N-1)) .* life_prod' .* wpath(i:i+N-1);               % wage over life cycle
    Plife           = [zeros(NWORK,1); ppath(i+NWORK:i+N-1)];                % pension over life cycle

    nChildren       = zeros(1,N);
    for j = 1:NPARENT
        year         = min(T,i+j-1);
        nChildren(j) = sum(pop_struct(year,1:NCHILD)) / sum(pop_struct(year,iPARENT));
    end
    Psi             = 1 + nChildren*psi;
    
    disp_y          = Wlife'.*h + Plife';
    [c,a,b]         = solve_household(disp_y,hhRpath(i:i+N-1)',fi(i,:),...
                                        Bequest(i),Psi,PARAMS);
    SAVE_C(i,:) = c;
    SAVE_H(i,:) = h;
    SAVE_E(i,:) = life_prod.*h;
    SAVE_T(i,:) = c + 0*Psi.*c;                                                      % consumption including children's cons
    SAVE_A(i,:) = a(1:end-1)./fi(i,:);
    j           = i + BA - NCHILD;
    if j <= T
    Bequest(j)  = b * pop_struct(j-1,BA) / pop_struct(j-1,NCHILD);
    end
end


TOT_C = zeros(T,1);  
TOT_H = zeros(T,1);  
TOT_A = zeros(T,1);
for i = 1:T;
    if i < N
        TOT_C(i) = sum(SAVE_T0(1:N-i,i).*pop_struct(i,NCHILD+1+i:end)');
        TOT_H(i) = sum(SAVE_E0(1:N-i,i).*pop_struct(i,NCHILD+1+i:end)');
        TOT_A(i) = sum(SAVE_A0(1:N-i,i).*pop_struct(i,NCHILD+1+i:end)');
        for j = 1:i
            TOT_C(i) = TOT_C(i) + SAVE_T(i+1-j,j) * pop_struct(i,NCHILD+j);
            TOT_H(i) = TOT_H(i) + SAVE_E(i+1-j,j) * pop_struct(i,NCHILD+j);
            TOT_A(i) = TOT_A(i) + SAVE_A(i+1-j,j) * pop_struct(i,NCHILD+j);
        end
    else
        for j = 1:N
            TOT_C(i) = TOT_C(i) + SAVE_T(i+1-j,j) * pop_struct(i,NCHILD+j);
            TOT_H(i) = TOT_H(i) + SAVE_E(i+1-j,j) * pop_struct(i,NCHILD+j);
            TOT_A(i) = TOT_A(i) + SAVE_A(i+1-j,j) * pop_struct(i,NCHILD+j);
        end
    end
end

output.C         = TOT_C;                   % [T,1]       Total consumption
output.a         = [SAVE_A; SAVE_A0];       % [T+N-1,N]   Down=cohorts, right=life cycle, last N-1 cohorts
output.c         = [SAVE_C; SAVE_C0];       % ...         were born in old ss. These come in reverse order!
output.h         = [SAVE_H; SAVE_H0];       % ...         were born in old ss. These come in reverse order!
output.GDP       = GDP;                     % [T,1]
output.w         = wpath;                   % [T,1]
output.b         = Bequest;
output.p         = ppath;
output.tauP      = tauP;
output.retired   = frac_retired;
output.DIV       = DIVpath;
output.Q         = Qpath;
output.Rp        = Rp;