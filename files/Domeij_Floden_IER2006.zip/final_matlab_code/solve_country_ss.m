function [implied_A,implied_K,implied_Q,implied_DIV,implied_H,implied_B,output] = ...
    solve_country_ss(r,H,B,fi,COUNTRY,PARAMS)
%
% Input:
% r                    = ss interest rate
% H
% B                    = bequest 
% fi[1,N]              : fi(age) = survival prob from age-1 to age
%
% in COUNTRY(struct)
% pop_struct[1,NLIFE]  = fraction of individuals of age x in any year
% LABPROD              = labor productivity relative to US 1950
%
%
% in PARAMS (struct)
% mu, beta, gamma, N, NLIFE, NCHILD, CHILDREN_PERIOD,
% psi[1,NCHILD]        = consumption of children relative to parent
% life_prod[1,N]       = labor productivity over life cycle
%
% Output:
% implied_A            = total asset holdings in SS-year implied by model
% implied_K            = capital stock implied by interest rate
% implied_Q            = value of representative firm implied by interest rate
% output      [STRUCT]


N               = PARAMS.N;
NCHILD          = PARAMS.NCHILD;
NWORK           = PARAMS.NWORK;
NPARENT         = PARAMS.NPARENT;
life_prod       = PARAMS.life_prod;
psi             = PARAMS.psi;
gamma           = PARAMS.gamma;
xsi             = PARAMS.xsi;
alpha           = PARAMS.alpha;
BA              = PARAMS.beq_age;


LABPROD         = COUNTRY.LABPROD;
pop_struct      = COUNTRY.pop_struct;
tauP            = COUNTRY.tauP;
delta           = COUNTRY.delta;
theta           = COUNTRY.theta;


iPARENT         = NCHILD + (1:NPARENT);
PSI             = ones(1,N);
nChildren       = sum(pop_struct(1:NCHILD)) / sum(pop_struct(iPARENT));
PSI(1:NPARENT)  = 1 + nChildren*psi;


% Population shares
frac_children   = sum(pop_struct(1:NCHILD));
frac_workers    = sum(pop_struct(NCHILD+1:NCHILD+NWORK));
frac_retired    = sum(pop_struct(NCHILD+NWORK+1:end));


h               = 1;
implied_H       = (life_prod.*h) * pop_struct(NCHILD+1:end)';

% adj. cost
gamma1          = (1+gamma)^(1/5)-1;
delta1          = (1+delta)^(1/5)-1;
XK              = 5 * xsi * (gamma1 + delta1)^alpha;                         % X(t) / K(t-1)
X1              = XK - xsi*(gamma1+delta1)^(alpha-1)*alpha*(1+gamma1);
X2              = xsi*(gamma1+delta1)^(alpha-1)*alpha*(1+gamma)^(-4/5);

implied_K       = (theta/(r(1) + delta + X2 + X1 / (1+r(1))))^(1/(1-theta)) * LABPROD * implied_H;


implied_Y       = implied_K^theta * (LABPROD*implied_H)^(1-theta);   % Output (per capita)
w               = (1-theta) * implied_Y ./ implied_H;
implied_DIV     =  implied_Y - (r(1) + delta + XK/(1+gamma))*implied_K - w.*implied_H;
implied_Q       = implied_DIV / r(1);


GAMMA           = (1+gamma).^(0:N-1);
reverseGAMMA    = GAMMA.^(-1);
r               = r*ones(1,N);
a1              = B;
R               = 1 + r;


P               = tauP * w*H / sum(pop_struct(NCHILD+NWORK+1:end));

life_wage       = (1-tauP)*w*life_prod.*GAMMA;

disp_y          = life_wage .* h + [zeros(1,NWORK) P*ones(1,N-NWORK)].*GAMMA;
[c,a,b]         = solve_household(disp_y,R,fi,a1,PSI,PARAMS);

C               = c.*reverseGAMMA;

ii              = 1:NCHILD;
children_c      = 0*nChildren*psi.*c(ii);
children_c      = 0*psi.*c(ii);
children_C      = 0*children_c.*reverseGAMMA(ii);

TOT_C           = [children_C C] * pop_struct';

A               = a(1:end-1)./fi.*reverseGAMMA;                           % A(t) = assets conditional on survival
implied_A       = A * pop_struct(NCHILD+1:end)';

implied_B       = b/((1+gamma)^(BA-NCHILD)) * pop_struct(BA) / pop_struct(NCHILD);

output.c        = c;
output.a        = a;
output.Y        = implied_Y;
output.DIV      = implied_DIV;
output.Q        = implied_Q;