function [c,a,b] = solve_household(y,R,fi,a1,PSI,PARAMS)
% Solve household consumption problem
% 
% INPUT
% y        = exogenous income path (including transfers etc)
% R        = interest rate path
% fi(t)    = survival prob from t-1 to t
% a1       = a(1) = end-of-period assets in period 0
% PSI      = number of children in consumption equivalents
%
% OUTPUT
% c        = consumption path, c(1:N)
% a        = assets a(1:N+1)

beta            = PARAMS.beta;
mu              = PARAMS.mu;
beq             = PARAMS.beq;
NCHILD          = PARAMS.NCHILD;
BA              = PARAMS.beq_age;

ba = BA - NCHILD;

P  = cumprod([fi(1) fi(2:end)./R(2:end)]);
Q  = cumprod([1 R(2:end)]);

N  = length(R);

if BA > NCHILD,
    LHS = P(ba)*(beta^ba*Q(ba)*beq)^(1/mu);
else 
    LHS = 0; 
end
RHS = R(1)*a1;
for t = 1:N
    LHS = LHS + beta^(t/mu) * P(t) * Q(t)^(1/mu) * PSI(t)^(-(1-mu)/mu);
    RHS = RHS + P(t)*y(t);
end

c_hat = RHS / LHS;                                              % = lambda^(-1/mu) 
if BA > NCHILD,
  b   =  (beta^(ba)*Q(ba)*beq)^(1/mu) * c_hat;                  % bequest
else, b = []; 
end
c     = c_hat*(beta.^(1:N).*Q).^(1/mu) .* PSI.^(-(1-mu)/mu);
a     = [a1 zeros(1,N)];
for t = 1:N
    if t == ba
      a(t+1) = R(t)*a(t)/fi(t) + y(t) - c(t) - b;
    else
      a(t+1) = R(t)*a(t)/fi(t) + y(t) - c(t);
    end
end
