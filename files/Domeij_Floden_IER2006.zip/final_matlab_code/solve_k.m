function Kdiff = solve_K(guess,Kss,Hpath,rpath,COUNTRY,PARAMS)
%
% Input:
% guess                : [Kpath[T,1]
%
% in COUNTRY(struct)
% pop_struct[1,NLIFE]  = fraction of individuals of age x in any year
% LABPROD              = labor productivity relative to US 1950
%
%
% in PARAMS (struct)
% mu, beta, N, NLIFE, NCHILD, CHILDREN_PERIOD, gamma
% psi[1,NCHILD]        = consumption of children relative to parent
% life_prod[1,N]       = labor productivity over life cycle


% =============================================================================================
% Solve
% =============================================================================================

N               = PARAMS.N;
gamma           = PARAMS.gamma;
xsi             = PARAMS.xsi;
alpha           = PARAMS.alpha;
LABPROD         = COUNTRY.LABPROD;
delta           = COUNTRY.delta;
theta           = COUNTRY.theta;

[T,nCOL]        = size(guess);
FILL            = ones(1,nCOL);
GAMMA           = ((1+gamma).^(0:T-1)') * FILL;

Kpath           = guess.*GAMMA;   
H               = Hpath*FILL;   


totpop          = COUNTRY.totpop * FILL;
k1              = Kpath .* totpop;
k0              = [Kss*FILL/(1+gamma); Kpath(1:end-1,:)] .* totpop([1 1:end-1],:);
delta1          = (1+delta)^(1/5)-1;
IND             = (k1./k0).^(1/5) > (1-delta1);
X               = 5 * xsi * (abs((k1./k0).^(1/5) - (1-delta1))).^alpha .* k0;
X1              = X./k0 - xsi*IND.*(abs((k1./k0).^(1/5) - (1-delta1))).^(alpha-1).*alpha.*(k1./k0).^(1/5);
X2              = xsi*IND.*(abs((k1./k0).^(1/5) - (1-delta1))).^(alpha-1).*alpha.*(k1./k0).^(-4/5);


X1              = X1([2:end end],:);
effective_H     = COUNTRY.LABPROD * H .* GAMMA .* totpop;
Kdiff           = theta.*(effective_H./k1).^(1-theta) - rpath*FILL - delta - ...
                  X2 - X1 ./ (1 + rpath([2:end end])*FILL);            

