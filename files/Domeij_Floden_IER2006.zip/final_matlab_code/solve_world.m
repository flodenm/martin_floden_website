function OUT = world_AandK(rpath,Kss,rss,Hpath,Qss,Qshare,initial_a,COUNTRY,PARAMS,results)
%
% Input:
% initial_a[1,N-1]     : initial asset holdings from steady states for those aged 21 to 99 in
%                        initial year
%
% in COUNTRY(struct)
% pop_struct[1,NLIFE]  = fraction of individuals of age x in any year
% LABPROD              = labor productivity relative to US 1950
%
%
% in PARAMS (struct)
% mu, beta, N, NLIFE, NCHILD, CHILDREN_PERIOD, gamma
% psi[1,NCHILD]        = consumption of children relative to parent
% life_prod[1,N]       = labor productivity over life cycle
%
% Output:
% OUT
% if results == 0      = [T,1] AKdiff
% if results == 1      = STRUCT with results


% =============================================================================================
% Solve
% =============================================================================================

N               = PARAMS.N;
NCHILD          = PARAMS.NCHILD;
life_prod       = PARAMS.life_prod;
gamma           = PARAMS.gamma;
xsi             = PARAMS.xsi;
alpha           = PARAMS.alpha;


NCOUNTRIES      = length(COUNTRY);
T               = length(rpath);
GAMMA           = (1+gamma).^(0:T-1)';


if exist('Kpath.mat')==2, load Kpath
    if size(Kpath,1) == NCOUNTRIES*T, oldKpath=Kpath;
    else oldKpath = []; end
else oldKpath = []; end
Kpath           = zeros(NCOUNTRIES*T,1);
KDIFF           = zeros(1,NCOUNTRIES);
for cty = 1:NCOUNTRIES
    cty_i             = (cty-1)*T+(1:T);
    if isempty(oldKpath)
        Kguess        = Kss(cty)*ones(T,1);
    else 
        Kguess        = oldKpath(cty_i);
    end
    [k,rc]            = csolve('solve_k',Kguess,[],1e-12,20,Kss(cty),Hpath(cty_i),rpath,COUNTRY(cty),PARAMS);
    Kpath(cty_i)      = k;
    Kdiff             = solve_k(k,Kss(cty),Hpath(cty_i),rpath,COUNTRY(cty),PARAMS);
    KDIFF(cty)        = sum(Kdiff.^2);
end
if max(KDIFF)>1e-8, fprintf(1,'Kdiff = %10.8f\n',max(KDIFF)), end
save Kpath Kpath


implied_A       = zeros(T,1);
implied_K       = zeros(T,1);
implied_Q       = zeros(T,1);
for cty = 1:NCOUNTRIES

    totpop        = COUNTRY(cty).totpop;
    cty_i         = (cty-1)*T+(1:T);
    K             = Kpath(cty_i).*GAMMA;   
    H             = Hpath(cty_i);   
    
    effective_H   = COUNTRY(cty).LABPROD * H .* GAMMA;

    [A,Q,out]     = solve_country(rpath,H,K,Kss(cty),Qss(cty),Qshare,initial_a(cty,:),COUNTRY(cty),PARAMS);
    
    implied_A     = implied_A + A .* totpop;    
    implied_K     = implied_K + K .* totpop;
    implied_Q     = implied_Q + [Qss(cty)/(1+gamma)*totpop(1); Q(1:end-1).*totpop(1:end-1)];
    
    if results
        out.A         = A;
        out.K         = K;
        out.Q         = Q;
        out.H         = H;
        CA            = (A(2:end)-K(2:end)-Q(2:end)).*totpop(2:end) - ...
                        (A(1:end-1)-K(1:end-1)-Q(1:end-1)).*totpop(1:end-1);
        out.ca        = [CA./out.GDP(1:end-1)./totpop(1:end-1)];    % We have checked that is is equivalent to other ways of calculating the CA
        out.ca        = [out.ca; out.ca(end)]; 
        OUT.CTY(cty)  = out;
    end
    
end


% Normalize
AKdiff        = (implied_A - implied_K - implied_Q) ./ GAMMA;

if results == 0
  plot([AKdiff]); drawnow
  OUT           = AKdiff;
else
    
  OUT.diff      = [AKdiff];
  OUT.A         = implied_A;
  OUT.K         = implied_K;
  OUT.Q         = implied_Q;
  OUT.r         = rpath;

end