function [f,output] = solve_world_ss(x,COUNTRY,PARAMS)
%
% Input:
%
% in COUNTRY(struct)
% pop_struct[1,NLIFE]  = fraction of individuals of age x in any year
% LABPROD              = labor productivity relative to US 1950
%
%
% in PARAMS (struct)
% mu, beta, N, NLIFE, NCHILD, CHILDREN_PERIOD, gamma
% psi[1,NCHILD]        = consumption of children relative to parent
% life_prod[1,N]       = labor productivity over life cycle
%
% Output:
% r                    = equilibrium interest rate
% output      [STRUCT]


NCOUNTRIES = length(COUNTRY);
NCHILD     = PARAMS.NCHILD;
gamma      = PARAMS.gamma;

r          = x(1);
h          = x(2:NCOUNTRIES+1);
b          = x(NCOUNTRIES+2:2*NCOUNTRIES+1);             % bequest


% =============================================================================================
% Solve
% =============================================================================================

A = 0;
K = 0;  
Q = 0;
H = zeros(1,NCOUNTRIES);
B = zeros(1,NCOUNTRIES);
for cty = 1:NCOUNTRIES
    ps = COUNTRY(cty).pop_struct;
    fi = ps(NCHILD+1:end) ./ ps(NCHILD:end-1);
    [a,k,q,div,H(cty),B(cty),country_output] = solve_country_ss(r,h(cty),b(cty),fi,COUNTRY(cty),PARAMS);
    A               = A + a*COUNTRY(cty).totpop;
    K               = K + k*COUNTRY(cty).totpop;
    Q               = Q + q*COUNTRY(cty).totpop;
    output(cty).c   = country_output.c;
    output(cty).a   = country_output.a;
    output(cty).K   = k;
    output(cty).A   = a;
    output(cty).Y   = country_output.Y;
    output(cty).DIV = div;
    output(cty).Q   = q;
end

f = [(A-K-Q/(1+gamma)) H-h B-b];