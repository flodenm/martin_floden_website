function euler = test_solution(c,a,w,p,R,fi,a1,COUNTRY,PARAMS)

beta            = PARAMS.beta;
mu              = PARAMS.mu;
psi             = PARAMS.psi;
beq             = PARAMS.beq;
BA              = PARAMS.beq_age;
NCHILD          = PARAMS.NCHILD;
NPARENT         = PARAMS.NPARENT;
iPARENT         = NCHILD + (1:NPARENT);

ba = BA - NCHILD;
N  = length(R);
FI = cumprod(fi(1:end));
Q  = cumprod([1 R(2:end)]);
P  = FI./Q;

pop_struct      = COUNTRY.pop_struct;
nChildren       = zeros(1,N);
for j = 1:NPARENT
    nChildren(j) = sum(pop_struct(j,1:NCHILD)) / sum(pop_struct(j,iPARENT));
end
Psi             = 1 + nChildren*psi;
 

h      = 1;
y      = h.*w+p;
lambda = beta*c(1)^(-mu) / (Psi(1)^(1-mu));
b      = (beta^(ba)*Q(ba)*beq/lambda)^(1/mu);
y(ba)  = y(ba) - b;

LHS = 0;
RHS = R(1)*a1;
for t = 1:N;
    LHS = LHS + P(t)*c(t);
    RHS = RHS + P(t)*y(t);
end

life_bc   = LHS - RHS;
period_bc = a(2:end) - R.*a(1:end-1)./fi - y + c;
euler     = c(2:end).*Psi(2:end).^((1-mu)/mu) - (beta*R(2:end)).^(1/mu) .* c(1:end-1).*Psi(1:end-1).^((1-mu)/mu);

ok_solution = abs(life_bc) < 1e-6 & ...
              max(abs(period_bc)) < 1e-6 & ...
              abs(a(end)) < 1e-6 & ...
              max(abs(euler)) < 1e-6;

          
fprintf(1,'=============================================================\n')
fprintf(1,'>>> Testing solution for specific country & time period <<<\n')
fprintf(1,'# Time periods:                      %8d\n',N)
fprintf(1,'Life-time budget constraint:         %2.4e\n',abs(life_bc))
fprintf(1,'Period-by-period budget constraints: %2.4e\n',max(abs(period_bc)))
fprintf(1,'Final assets:                        %2.4e\n',abs(a(end)))
fprintf(1,'Euler equations:                     %2.4e\n',max(abs(euler)))
if ok_solution
    fprintf(1,'THE SOLUTION IS GOOD\n')
else
    fprintf(1,'*** WARNING! THE SOLUTION IS BAD *** \n')
end
fprintf(1,'=============================================================\n')