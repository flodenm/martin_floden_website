function [diff,Y,USE,A,K,Q] = test_world_solution(Kss,Qss,RESULTS,COUNTRY,PARAMS)

beta            = PARAMS.beta;
mu              = PARAMS.mu;
psi             = PARAMS.psi;
gamma           = PARAMS.gamma;
xsi             = PARAMS.xsi;
alpha           = PARAMS.alpha;


CTY = RESULTS.CTY;
T   = length(CTY(1).GDP);
NC  = length(CTY); 

Y   = zeros(T,1);
USE = Y;
A   = Y;
K   = Y;
Q   = Y;

for i = 1:NC
    cty     = CTY(i);
    c       = COUNTRY(i);
    delta   = c.delta;
    totpop  = c.totpop;
    Y       = Y + totpop .* cty.GDP;
    dp      = totpop(2:end)./totpop(1:end-1);
    
    k1      = cty.K .* totpop;
    k0      = [Kss(i)*totpop(1)/(1+gamma); k1(1:end-1)];
    k2      = [k1(2:end); k1(end)*(1+gamma)];
    delta1  = (1+delta)^(1/5)-1;
    X       = 5 * xsi * (abs((k1./k0).^(1/5) - (1-delta1))).^alpha .* k0;

    USE     = USE + X + k2 - (1-delta) .* k1 + totpop .* cty.C;

    Q       = Q + [Qss(i)/(1+gamma)*totpop(1); cty.Q(1:end-1).*totpop(1:end-1)];
    A       = A + totpop.*cty.A;
    K       = K + totpop.*cty.K;   
end

diff   = Y - USE;
diff   = diff ./ Y;
plot(diff)
title('Testing world solution: diff')
AKdiff = (A-K-Q) ./ A;

fprintf(1,'=============================================================\n')
fprintf(1,'>>> Testing world resource constraint <<<\n')
fprintf(1,'# Time periods:                        %8d\n',T)
fprintf(1,'Period-by-period resource constraints: %2.4e\n',max(abs(diff)))
fprintf(1,'Assets and capital:                    %2.4e\n',max(abs(AKdiff)))
if max(abs(diff))<1e-4 & max(abs(AKdiff))<1e-4
    fprintf(1,'THE SOLUTION IS GOOD\n')
else
    fprintf(1,'*** WARNING! THE SOLUTION IS BAD *** \n')
end
fprintf(1,'=============================================================\n')

