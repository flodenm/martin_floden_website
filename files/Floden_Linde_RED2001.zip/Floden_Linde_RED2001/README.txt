This package contains computer code for "Idiosyncratic risk in the U.S. and Sweden: Is there a role for government insurance?", Review of Economic Dynamics 4, 406-437 (2001) by Martin Flod�n and Jesper Lind�.

This note is written in August 2010, but the other files in this package were produced around 1997-1999 and are of varying quality.

There are three subfolders in this package:

"sw_bench" contains matlab code to reproduce the main simulation results for Sweden. Run "script.m" or "script2.m" to generate results for tax rates between 0.22 and 0.70.

"us_bench" contains matlab code to reproduce the main simulation results for the U.S. Again, run "script.m" or "script2.m".

"wage_processes" contains some code and information about the data we used to estimate the wage processes. Unfortunately, these files are not well documented.
