% Produce figures and report statistics

FIGURES  = 0;
VOLATILS = 0;
LORENZ   = 0;		% Requires distribs = 1

nn = 25000;
nAs = size(As_low,1);
tmp_low = As_low(2:nAs,:) - (1-delta)*As_low(1:nAs-1,:);   % Gross saving, including new borns
tmp_hgh = As_hgh(2:nAs,:) - (1-delta)*As_hgh(1:nAs-1,:);   % Gross saving, including new borns
nb_low = NBs_low(2:nAs,:);
nb_hgh = NBs_hgh(2:nAs,:);

% Calculate labor earings before tax = 'Earnings'
Es_low = [Hs_low .* Qs_low * w];
Es_hgh = [Hs_hgh .* Qs_hgh * w];

% Calculate net factor income before tax but after transfers = 'Total Income'
Is_low = Es_low + r * As_low + b;
Is_hgh = Es_hgh + r * As_hgh + b;


% Remove new borns. Keep heirs.
g_sav_low = -1000 * ones(1,nn+floor(0.1*nn));
g_sav_hgh = -1000 * ones(1,nn+floor(0.1*nn));
j_low = 1;
j_hgh = 1;
for i = 1:(nn+floor(0.1*nn));
  if (nb_low(i) == 0) | (nb_low(i) == 5)
    g_sav_low(j_low) = tmp_low(i);
    j_low = j_low + 1;
  end;
  if (nb_hgh(i) == 0) | (nb_hgh(i) == 5)
    g_sav_hgh(j_hgh) = tmp_hgh(i);
    j_hgh = j_hgh + 1;
  end;
end;

g_sav = [g_sav_low(1:nn) g_sav_hgh(1:nn)];
H0 = [Hs_low(1:nn) Hs_hgh(1:nn)];

% DISTRIBUTIONS 

  C0 = sort([Cs_low(1:nn) Cs_hgh(1:nn)]);
  Y0 = sort([Ys_low(1:nn) Ys_hgh(1:nn)]);
  A0 = sort([As_low(1:nn) As_hgh(1:nn)]);
  E0 = sort([Es_low(1:nn) Es_hgh(1:nn)]);
  I0 = sort([Is_low(1:nn) Is_hgh(1:nn)]);

  gC = gini(C0)
  gY = gini(Y0)
  gA = gini(A0)
  gE = gini(E0)
  gI = gini(I0)

  nn = 2*nn;
  
  c40 = sum(C0(1:floor(nn*.4))) / sum(C0)
  y40 = sum(Y0(1:floor(nn*.4))) / sum(Y0)
  a40 = sum(A0(1:floor(nn*.4))) / sum(A0)
  e40 = sum(E0(1:floor(nn*.4))) / sum(E0)
  i40 = sum(I0(1:floor(nn*.4))) / sum(I0)
  
  c20 = sum(C0(floor(nn*.80):nn)) / sum(C0)
  y20 = sum(Y0(floor(nn*.80):nn)) / sum(Y0)
  a20 = sum(A0(floor(nn*.80):nn)) / sum(A0)
  e20 = sum(E0(floor(nn*.80):nn)) / sum(E0)
  i20 = sum(I0(floor(nn*.80):nn)) / sum(I0)
  
  c10 = sum(C0(floor(nn*.90):nn)) / sum(C0)
  y10 = sum(Y0(floor(nn*.90):nn)) / sum(Y0)
  a10 = sum(A0(floor(nn*.90):nn)) / sum(A0)
  e10 = sum(E0(floor(nn*.90):nn)) / sum(E0)
  i10 = sum(I0(floor(nn*.90):nn)) / sum(I0)

  c1  = sum(C0(floor(nn*.99):nn)) / sum(C0)
  y1  = sum(Y0(floor(nn*.99):nn)) / sum(Y0)
  a1  = sum(A0(floor(nn*.99):nn)) / sum(A0)
  e1  = sum(E0(floor(nn*.99):nn)) / sum(E0)
  i1  = sum(I0(floor(nn*.99):nn)) / sum(I0)


if FIGURES
  hh = figure;
  set(hh,'PaperType','a4letter');
  XX = -0.5:0.1:5;
  gs = hist(g_sav,XX);
  cc = hist(C0,XX);
  gy = hist(Y0,XX);
  nn2 = sum(XX <= 4);
  plot(XX(1:nn2),gs(1:nn2)/nn,'-',XX(1:nn2),cc(1:nn2)/nn,':',XX(1:nn2),gy(1:nn2)/nn,'--');
  legend('gross saving','consumption','net disp. income');
  title('Distributions');
  xlabel('s, c, y');
  ylabel('Density');


  hh = figure;
  set(hh,'PaperType','a4letter');
  AA = 0:0.2:A(gga);
  nn0 = size(AA,2) / 0.2;
  N = hist(A0,AA);
  nn2 = sum(AA <= 10);
  plot(AA(1:nn2),N(1:nn2)/nn0);
  title('Asset distribution');
  xlabel('A');
  ylabel('Density');
end;

if LORENZ
  indx = 100*(1:nn)/nn;
  plot(indx,indx,indx,100*cumsum(A0)/sum(A0),indx,100*cumsum(E0)/sum(E0));
  xlabel('% of individuals');
  ylabel('% of total');
  gtext('Wealth');
  gtext('Earnings');

end;

if VOLATILS
  std_ydsp = mean(std(Y0')./mean(Y0'))
  std_c    = mean(std(C0')./mean(C0'))
  std_a    = mean(std(A0')./mean(A0'))
  std_h    = mean(std(H0')./mean(H0'))
  std_e    = mean(std(E0')./mean(E0'))
  std_i    = mean(std(I0')./mean(I0'))
end;


