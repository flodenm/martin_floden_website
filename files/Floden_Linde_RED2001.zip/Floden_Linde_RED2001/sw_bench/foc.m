function [a, b] = foc(Cdec,Hdec,Adec,A,Kbar,Zprob,alfa,mu,beta,gmma,R,tauC,wQ)
% evaluate all foc:s

for i = 1:size(Cdec,1)
  for j = 1:size(Cdec,2)

    if Adec(i,j) > 1e-6
      [a(i,j), b(i,j)] = test_foc(i,j,Cdec,Hdec,Adec,A,Kbar,Zprob,alfa,mu,beta,gmma,R,tauC);
     else
       a(i,j) = -999; b(i,j) = -999;
     end

  end
end

