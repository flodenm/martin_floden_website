function g = gini(X);

X = sort(X);

nobs = size(X,2);

s = sum(X);

v = nobs:(-1):1;
g = 1 + 1/nobs - (2/(nobs*s)) * sum(X .* v);
g = nobs * g / (nobs-1);


