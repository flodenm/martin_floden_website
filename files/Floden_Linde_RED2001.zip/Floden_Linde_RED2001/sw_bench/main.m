% Idiosyncratic Risk, Labor Supply Decisions, and Optimal Taxation
% 971027. Updated 980712
% Updated 000317



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                        SETUP                                      %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



% Size of state space
gga = 50;
ggz = 7;
m = 3;						% Spread in Z grid (+- std. devs.)


% SET UP STATE SPACE

kmax = ((alfa^(1-theta)) / delta)^(1/(1-theta));
kmax = 1.75 * kmax;

% Assets
minA = 0;
maxA = kmax;
aa = linspace(2,gga,gga-1);
A = [0 (kmax/(gga^2.35)*aa.^2.35)];

% Productivity endowment
[Z, Zprob] = Tauchen(ggz,0,rho,sigma,m);
distr = (ones(1,ggz)/ggz) * Zprob^1000;
Q_low = exp(Z - sigma_perm);
Q_hgh = exp(Z + sigma_perm);
EQ = .5 * (distr * Q_low' + distr * Q_hgh');
Q_low = Q_low / EQ;
Q_hgh = Q_hgh / EQ;

% Initiate variables
ggTau = size(TAUgrid,2);
Rsav = zeros(1,ggTau);
Ksav = Rsav; Asav = Rsav; Bsav = Rsav; Tsav = Rsav; Usav = Rsav;
Hsav = Rsav; Csav = Rsav; Ysav = Rsav; HQsav = Rsav;

% Load saved solution?
if isempty(infile)
  w0 = (1-TAUgrid(1))*(1-theta) * ((R0grid(1)+delta)/theta)^(-theta/(1-theta));
  R = (1+(1-tauK)*R0grid(1));
  A_dec_low = zeros(gga,ggz);  		A_dec_hgh = A_dec_low;
  H_dec_low = alfa * ones(gga,ggz); 	H_dec_hgh = H_dec_low;
  C_dec_low = (A' * ones(1,ggz) + w0 * (1-H_dec_low) .* (ones(gga,1) * Q_low))/(1+tauC);
  C_dec_hgh = (A' * ones(1,ggz) + w0 * (1-H_dec_hgh) .* (ones(gga,1) * Q_hgh))/(1+tauC);
  Va_low = R * alfa * ((C_dec_low.^alfa).*((1-H_dec_low).^(1-alfa))).^(1-mu) ./ (C_dec_low*(1+tauC));
  Va_hgh = R * alfa * ((C_dec_hgh.^alfa).*((1-H_dec_hgh).^(1-alfa))).^(1-mu) ./ (C_dec_hgh*(1+tauC));
  clear R w0
else
  load(infile);
end;


% Iterate until asset demand eq. asset supply

for iTau = 1:ggTau;
  
  tau = TAUgrid(iTau);

  Rmin = 0.015; 			% Arbitrarily chosen. High r ==> faster solution
  Rmax = (1/beta-1)/(1-tauK)+.005;
  
  % Use previous solution or guess?
  if (iTau <= 1) | (initiate == 'guess') | (initiate == 'estim')
    Hbar = HQgrid(iTau);
    Next_r = R0grid(iTau);
    Rmin = Next_r - .0005;
    Rmax = Next_r + .0005;
  end;

  if (iTau > 2) & (initiate == 'estim')
    Hbar = 2 * HQ - results(end-1,19);
    Next_r = 2 * r - results(end-1,14);
    Rmin = Next_r - .0003;
    Rmax = Next_r + .0003;
  end
   
  prints('===========================================================================',0);
  prints('New TAU: ');  prints(tau);  prints('   Initial r: ');
  prints(Next_r,0);  prints('',0);
  
  KDiff = 1;  
  NEWKMIN = 0;
  NEWKMAX = 10000;
  Kmin = NEWKMIN;
  Kmax = NEWKMAX;
  rIter = 1; 

  while (KDiff > maxKDiff) & (rIter <= maxRIter)
  
    r = Next_r;
     
    Hdiff = 1;
    HIter = 1;
      
    while (Hdiff > maxHdiff) & (HIter <= maxHIter)
       
%      Kbar = Hbar * (theta / (r+delta))^(1/(1-theta));		% Firms' asset demand
      Kbar = theta/(r+delta);          % Y is normalized to unity
       
      % Solve value function and decision rules
      [Va_low, A_dec_low, C_dec_low, H_dec_low, w, b] = ...
        slv_foc(Va_low,A_dec_low,C_dec_low,H_dec_low, ...
		Kbar,r,tau,Hbar,maxiters,maxdiff,Q_low,Zprob);
      [Va_hgh, A_dec_hgh, C_dec_hgh, H_dec_hgh, w, b] = ...
        slv_foc(Va_hgh,A_dec_hgh,C_dec_hgh,H_dec_hgh, ...
		Kbar,r,tau,Hbar,maxiters,maxdiff,Q_hgh,Zprob);
 
      prints('Transfer = ',b,10,4,0);

      % Simulate the economy
      rand('seed',279357934218);				% Always use same random numbers
      [As_low, Cs_low, Hs_low, Qs_low, Ys_low, Us_low, Ts_low, HQs_low, NBs_low] = ...
        simulate(A_dec_low,Kbar,r,w,tau,b,nsimuls,Q_low,Zprob);
      rand('seed',279357934218);				% Always use same random numbers
      [As_hgh, Cs_hgh, Hs_hgh, Qs_hgh, Ys_hgh, Us_hgh, Ts_hgh, HQs_hgh, NBs_hgh] = ...
        simulate(A_dec_hgh,Kbar,r,w,tau,b,nsimuls,Q_hgh,Zprob);
      
      oldHbar = Hbar;
      newHbar = .5 * mean(mean(HQs_low + HQs_hgh));
      Hbar = 0.9 * newHbar + 0.1 * oldHbar;
        
      Hdiff = abs(newHbar/oldHbar-1);
      HIter = HIter + 1;
        
      EA = .5 * mean(mean(As_low + As_hgh));				% Simulated asset supply
%      K = Hbar * (theta / (r+delta))^(1/(1-theta));			% Firms' asset demand
      K = theta / (r+delta);

      prints('oldHbar, Hbar, repeat?: ');
      prints(oldHbar,8,4);      prints(Hbar,8,4);
      prints((Hdiff>maxHdiff) & (HIter <= maxHIter),8,4,3);
      prints('A = ',EA,8,4,3); prints('K = ',K,8,4,3); prints('r = ',r,8,4,0);  

    end;
      
    EA = .5 * mean(mean(As_low + As_hgh));				% Simulated asset supply
%    K = Hbar * (theta / (r+delta))^(1/(1-theta));			% Firms' asset demand
    K = theta / (r+delta);
      
    ET = .5 * mean(mean(Ts_low + Ts_hgh));
    EU = .5 * mean(mean(Us_low + Us_hgh));
             
    KDiff = abs(EA-K);
    
    % Alternative way of updating r:
    if (EA > K)
      if (Kmax < NEWKMAX)
        newK = (K + Kmax*Hbar) / 2;
      else
        newK = (K + EA) / 2;
      end; 
      Kmin = K/Hbar;
    elseif (EA < K)
      if (Kmin > NEWKMIN)
        newK = (Kmin*Hbar + K) / 2;
      else
        newK = (EA + K) / 2;
      end;
      Kmax = K/Hbar;
    end;
      
%    Next_r = theta * (Hbar/newK)^(1-theta) - delta;
    Next_r = theta / newK - delta;
    if KDiff < 1
      Next_r = 0.5 * r + 0.5 * Next_r;
    end;
    Next_r = min(Next_r,(1/beta-1)/(1-tauK));
    
    % If flexible LS and low mu then use this updating of r
if 3>2
    if (EA > K)
      Rmax = r;
      Next_r = (Rmin+r)/2;
    else
      Rmin = r;
      Next_r = (Rmax+r)/2;
    end;
end    
    rIter = rIter + 1;
  
    prints('A-K, A, K, newK, Next_r: ');
    prints(KDiff,8,4);
    prints([EA K newK Next_r],9,4,0);
  
  end; % rIter
  
  Rsav(iTau) = r;				% Do not use Next_r. Old r is guranteed to be good.
  Ksav(iTau) = K;
  Asav(iTau) = EA;
  Bsav(iTau) = b;
  Tsav(iTau) = ET;
  Usav(iTau) = EU;
  Hsav(iTau) = .5 * mean(mean(Hs_low + Hs_hgh));
  Csav(iTau) = .5 * mean(mean(Cs_low + Cs_hgh));
  Ysav(iTau) = .5 * mean(mean(Ys_low + Ys_hgh));
  HQsav(iTau) = .5 * mean(mean(HQs_low + HQs_hgh));

  report
  results = [results; res_vec];
  save(resfile,'results');
      
end; % iTau

%prints('   R         K         A         B          T',0);
%prints([Rsav' Ksav' Asav' Bsav' Tsav'],10,6,0);
%prints('   U         H         C         Y          HQ',0);
%prints([Usav' Hsav' Csav' Ysav' HQsav'],10,6,0);


diary off;