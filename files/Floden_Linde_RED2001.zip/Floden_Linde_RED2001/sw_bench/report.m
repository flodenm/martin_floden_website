% Report statistics. Euler Eq. tests not valid for this utility function
% 981016
  
  Cs = [Cs_low Cs_hgh]; Hs = [Hs_low Hs_hgh]; HQs = [HQs_low HQs_hgh]; 
  clear HQs_low HQs_hgh;
  Ts = [Ts_low Ts_hgh]; Us = [Us_low Us_hgh]; NBs = [NBs_low NBs_hgh];
  clear Ts_low Ts_hgh Us_low Us_hgh;
  Qs = [Qs_low Qs_hgh]; As = [As_low As_hgh];
  
  TT = mean(mean(Ts));
  CC = mean(mean(Cs));
  HQ = mean(mean(HQs));
  HH = mean(mean(Hs));
  YY = K^(theta/(1-theta)) * HQ;   % productivity normalized to unity
  UU = YY^(alfa*(1-mu)) * mean(mean(Us));
  WG = 1 - (benchU/UU)^(1/(alfa*(1-mu)));
  SS = 1-CC;
  
  % Test if simulations are stable. Estimate line a = b0 + b1 * t + eps, test b1 = 0
  meanA = mean(As');
  expl = [ones(nsimuls,1) (1:nsimuls)'];
  xprx = inv(expl' * expl);
  b0b1 = xprx * expl' * meanA';
  est  = b0b1' * expl';
  eps  = meanA - est;
  std_eps = sqrt(mean(eps.^2));
  t_ratio = b0b1 ./ (std_eps * diag(xprx).^(1/2));  
  
  % Correlations of hours, wages and assets
  hh0 = Hs(:); 
  aa0 = As(:);
  ww0 = w*(1-tau)*Qs(:);
  ccHW = corrcoef(hh0,ww0);
  ccHA = corrcoef(hh0,aa0);
  ccWA =  corrcoef(ww0,aa0);
  clear ww0 hh0
  ccHW = ccHW(1,2); ccHA = ccHA(1,2); ccWA = ccWA(1,2);
ee0 = w*Qs(:).*Hs(:);
ii0 = ee0 + b + r * As(:);
ccEA = corrcoef(ee0,aa0);
ccEI = corrcoef(ee0,ii0);
ccIA = corrcoef(ii0,aa0);
ccEA = ccEA(1,2); ccEI = ccEI(1,2); ccIA = ccIA(1,2);
 
clear ee0 ii0 aa0

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Calculate distributional implications and volatilities
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
FIGURES = 0;
LORENZ = 0;
VOLATILS = 1;
nn = 20000;
nAs = size(As_low,1);
tmp_low = As_low(2:nAs,:) - (1-delta)*As_low(1:nAs-1,:);   % Gross saving, including new borns
tmp_hgh = As_hgh(2:nAs,:) - (1-delta)*As_hgh(1:nAs-1,:);   % Gross saving, including new borns
nb_low = NBs_low(2:nAs,:);
nb_hgh = NBs_hgh(2:nAs,:);

% Calculate labor earings before tax = 'Earnings'
Es_low = [Hs_low .* Qs_low * w];
Es_hgh = [Hs_hgh .* Qs_hgh * w];

% Calculate net factor income before tax but after transfers = 'Total Income'
Is_low = Es_low + r * As_low + b;
Is_hgh = Es_hgh + r * As_hgh + b;

% Remove new borns. Keep heirs.
g_sav_low = -1000 * ones(1,nn+floor(0.1*nn));
g_sav_hgh = -1000 * ones(1,nn+floor(0.1*nn));
j_low = 1;
j_hgh = 1;
for i = 1:(nn+floor(0.1*nn));
  if (nb_low(i) == 0) | (nb_low(i) == 5)
    g_sav_low(j_low) = tmp_low(i);
    j_low = j_low + 1;
  end;
  if (nb_hgh(i) == 0) | (nb_hgh(i) == 5)
    g_sav_hgh(j_hgh) = tmp_hgh(i);
    j_hgh = j_hgh + 1;
  end;
end;

g_sav = [g_sav_low(1:nn) g_sav_hgh(1:nn)];
H0 = [Hs_low(1:nn) Hs_hgh(1:nn)];

clear tmp_* nb_*

% DISTRIBUTIONS 

C0 = sort([Cs_low(1:nn) Cs_hgh(1:nn)]);
A0 = sort([As_low(1:nn) As_hgh(1:nn)]);
E0 = sort([Es_low(1:nn) Es_hgh(1:nn)]);
I0 = sort([Is_low(1:nn) Is_hgh(1:nn)]);

gC = gini(C0);
gA = gini(A0);
gE = gini(E0);
gI = gini(I0);

nn = 2*nn;
  
c40 = sum(C0(1:floor(nn*.4))) / sum(C0);
a40 = sum(A0(1:floor(nn*.4))) / sum(A0);
e40 = sum(E0(1:floor(nn*.4))) / sum(E0);
i40 = sum(I0(1:floor(nn*.4))) / sum(I0);
  
c20 = sum(C0(floor(nn*.80):nn)) / sum(C0);
a20 = sum(A0(floor(nn*.80):nn)) / sum(A0);
e20 = sum(E0(floor(nn*.80):nn)) / sum(E0);
i20 = sum(I0(floor(nn*.80):nn)) / sum(I0);
  
c10 = sum(C0(floor(nn*.90):nn)) / sum(C0);
a10 = sum(A0(floor(nn*.90):nn)) / sum(A0);
e10 = sum(E0(floor(nn*.90):nn)) / sum(E0);
i10 = sum(I0(floor(nn*.90):nn)) / sum(I0);

c1  = sum(C0(floor(nn*.99):nn)) / sum(C0);
a1  = sum(A0(floor(nn*.99):nn)) / sum(A0);
e1  = sum(E0(floor(nn*.99):nn)) / sum(E0);
i1  = sum(I0(floor(nn*.99):nn)) / sum(I0);
  
if FIGURES
  hh = figure;
  set(hh,'PaperType','a4letter');
  XX = -0.5:0.1:5;
  gs = hist(g_sav,XX);
  cc = hist(C0,XX);
  gy = hist(Y0,XX);
  nn2 = sum(XX <= 4);
  plot(XX(1:nn2),gs(1:nn2)/nn,'-',XX(1:nn2),cc(1:nn2)/nn,':',XX(1:nn2),gy(1:nn2)/nn,'--');
  legend('gross saving','consumption','net disp. income');
  title('Distributions');
  xlabel('s, c, y');
  ylabel('Density');


  hh = figure;
  set(hh,'PaperType','a4letter');
  AA = 0:0.2:A(gga);
  nn0 = size(AA,2) / 0.2;
  N = hist(A0,AA);
  nn2 = sum(AA <= 10);
  plot(AA(1:nn2),N(1:nn2)/nn0);
  title('Asset distribution');
  xlabel('A');
  ylabel('Density');
end;

if LORENZ
  indx = 100*(1:nn)/nn;
  plot(indx,indx,indx,100*cumsum(A0)/sum(A0),indx,100*cumsum(E0)/sum(E0));
  xlabel('% of individuals');
  ylabel('% of total');
  gtext('Wealth');
  gtext('Earnings');

end;

if VOLATILS
  std_c    = mean(std(Cs(:))/mean(Cs(:)));
  std_a    = mean(std(As(:))/mean(As(:)));
  std_h    = mean(std(Hs(:))/mean(Hs(:)));
  std_e    = mean(std(E0)/mean(E0));
  std_i    = mean(std(I0)/mean(I0));
end;


diary off;
diary('stats.out');
  prints(' ',0);
  prints('===========================================================================',0);  
  prints(header); prints('   ');
  prints(date); cl = clock; prints('   ');
  prints(cl(4),2,0); prints(':'); prints(cl(5),2,0,0);
  prints(' ',0);
  prints('SET UP:',0);
  prints('Country =         '); prints(country,0);
  prints('TAU     = '); prints(tau,10,6);
  prints('   tauK    = '); prints(tauK,10,6);
  prints('   tauC    = '); prints(tauC,10,6,0);
  prints('mu      = '); prints(mu,10,6);
  prints('   G       = '); prints(G,10,6);
  prints('   leisure = '); prints(0,10,6,0);
  prints('rho     = '); prints(rho,10,6);
  prints('   sigma   = '); prints(sigma,10,6);
  prints('   alfa    = '); prints(alfa,10,6,0);
  prints('gmma    = '); prints(gmma,10,6);
  prints('   beta    = '); prints(beta,10,6,0);
  prints('#A      = '); prints(gga,10,0);
  prints('   #Z      = '); prints(ggz,10,0);
  prints('   #simuls = '); prints(nsimuls,10,0,0);
  prints(' ',0);
  prints('RESULTS:',0);
  prints('r       = '); prints(r,10,6);
  prints('   w       = '); prints(w,10,6,0);
  prints('K       = '); prints(K,10,6);
  prints('   A       = '); prints(EA,10,6,0);
  prints('H       = '); prints(HH,10,6);
  prints('   HQ      = '); prints(HQ,10,6,0);
  prints('T       = '); prints(TT,10,6);
  prints('   B       = '); prints(b,10,6);
  prints('   U       = '); prints(UU,10,6,0);
  prints('C       = '); prints(CC,10,6);
  prints('   Y       = '); prints(YY,10,6);
  prints('   Wgain   = '); prints(WG,10,6,0);
  prints('sd%(C)  = '); prints(std_c,10,6);
  prints('   sd%(A)  = '); prints(std_a,10,6);
  prints('   sd%(H)  = '); prints(std_h,10,6,0);
  prints('sd%(E)  = '); prints(std_e,10,6);
  prints('   sd%(I)  = '); prints(std_i,10,6,0);
  prints('cr(h,w) = '); prints(ccHW,10,6);
  prints('   cr(h,a) = '); prints(ccHA,10,6);
  prints('   cr(w,a) = '); prints(ccWA,10,6,0);
  prints('cr(e,a) = '); prints(ccEA,10,6);
  prints('   cr(e,i) = '); prints(ccEI,10,6);
  prints('   cr(i,a) = '); prints(ccIA,10,6,0);
  prints('gini(C) = '); prints(gC,10,6);
  prints('   gini(A) = '); prints(gA,10,6,0);
  prints('gini(E) = '); prints(gE,10,6);
  prints('   gini(I) = '); prints(gI,10,6,0);
  prints(' ',0);
  prints('(A40- A20+ A10+ A1+) = '); prints([a40 a20 a10 a1],8,4,0);
  prints('(E40- E20+ E10+ E1+) = '); prints([e40 e20 e10 e1],8,4,0);
  prints('(I40- I20+ I10+ I1+) = '); prints([i40 i20 i10 i1],8,4,0);
  prints(' ',0); prints('TESTS OF SOLUTION: ',0);
  prints('max(a)  = '); prints(max(max(As)),10,6);
  prints('   max(A)  = '); prints(A(gga),10,6);
  prints('   #a>.9A  = '); prints(sum(sum(As>.9*A(gga))),10,6,0);
  prints('slope in simulated assets = '); prints(b0b1(2),10,6);
  prints('   t-ratio = '); prints(t_ratio(2),10,6,0);
  prints('===========================================================================',0);  

% alfa=5, sigma=10, w=15, TT=20, std_c=25, ccHW=30, ccIA=35, G=40
res_vec = [tau tauK tauC b alfa beta gmma delta rho sigma gga ggz nsimuls r w K EA HH HQ TT UU CC YY SS std_c ...
           std_a std_h std_e std_i ccHW ccHA ccWA ccEA ccEI ccIA gC gA gE gI G theta WG];
diary off;

clear C0 A0 E0 I0 Cs As Hs Qs NBs HQs Us
pack