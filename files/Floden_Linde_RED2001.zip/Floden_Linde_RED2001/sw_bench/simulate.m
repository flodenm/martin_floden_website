function [As, Cs, Hs, Qs, Ys, Us, Ts, HQs, NBs] = ...
  simulate(A_dec,Kbar,r,w,tau,b,nPeriods,Q,Zprob);
% SIMULATE the economy for one agent, return vector of simulated assets, consumption,
% and labor supply

global sigma rho beta alfa theta delta mu gmma gga minA maxA A Afine nfine;
global ggz;
global tauK tauC G

prints('Simulating...',0);

nAg = 100;						% Simulate nAg agents at a time
nSkip = 500;

R = (1 + r * (1-tauK));

bigA = ones(nAg,1) * A;

x = cumsum(Zprob')';
x = [zeros(ggz,1) x];
 
n = nSkip + nPeriods + 1;

zz = rand(nAg,n);
As = zeros(nAg,n);
Cs = As; Hs = As; Qs = As; Ys = As; Us = As; Ts = As; HQs = As;
NBs = As;					% Add 1 if new born, add 5 if heir
iZ = floor(ggz/2) * ones(nAg,1) + 1;
As(:,1) = Kbar * ones(nAg,1);
  
for j = 1:n-1;
  
  % Kill some guys and give entrants zero assets
  surv = rand(nAg,1) < (1-gmma);
  As(:,j) = surv .* As(:,j);
  NBs(:,j) = NBs(:,j) + (1-surv);
  
  % Choose heirs and distribute bequests
  heir = rand(nAg,1) < gmma;
  As(:,j) = As(:,j) + heir * Kbar;
  As(:,j) = min(As(:,j),max(A));
  NBs(:,j) = NBs(:,j) + heir * 5;

  % Update Z and Q
  iZ = sum((x(iZ,:) < (zz(:,j) * ones(1,ggz+1)))')';
  Qs(:,j) = Q(iZ)';
       
  % Choose A(t+1) (= end of period t assets). Interpolate in A-dimension
  xlow = sum((As(:,j) * ones(1,gga) >= bigA)')';
  xlow = min(xlow,gga-1);
  xhigh = xlow+1;
  ilow = gga * (iZ-1) + xlow;
  ihigh = ilow + 1;
  frac = (A(xhigh)' - As(:,j)) ./ (A(xhigh)' - A(xlow)');
  As(:,j+1) = frac .* A_dec(ilow) + (1-frac) .* A_dec(ihigh);
  
  C0 = (alfa/(1+tauC)) * (b + (1-tau)*w*Qs(:,j) + R*As(:,j) - As(:,j+1));
  H0 = 1 - (1-alfa) * (1+tauC) * C0 ./ (alfa * (1-tau)*w*Qs(:,j));
  C1 = (b + R * As(:,j) - As(:,j+1)) / (1+tauC);
  pos_H0 = H0 > 0;
  H0 = max(H0,0);
  C0 = pos_H0 .* C0 + (1-pos_H0) .* C1;
  Hs(:,j) = H0;
  Cs(:,j) = C0;
  
  % test BC:
  df = C0*(1+tauC) + As(:,j+1) - b - (1-tau)*w*Qs(:,j).*H0 - R*As(:,j);

end;

% Labor income
HQs = Qs .* Hs;

% Income
Ys = b + (1-tau) * w * Qs .* Hs + (R-1) * As;

% Utility
Us = ( (Cs.^alfa) .* ((1-Hs).^(1-alfa)) ).^(1-mu) / (1-mu);

% Government tax revenues
Ts = tau * w * Qs .* Hs + tauK * r * As + tauC * Cs;

% Kill some guys and give entrants zero assets
surv = rand(nAg,1) < (1-gmma);
As(:,j+1) = surv .* As(:,j+1);

% Choose heirs and distribute bequests
heir = rand(nAg,1) < gmma;
As(:,j+1) = As(:,j+1) + heir * Kbar;

  
% Remove skip first observations and change timing of assets
As = As(:,nSkip+2:n)';
Hs = Hs(:,nSkip+1:n-1)';
Cs = Cs(:,nSkip+1:n-1)';
Qs = Qs(:,nSkip+1:n-1)';
Ys = Ys(:,nSkip+1:n-1)';
HQs = HQs(:,nSkip+1:n-1)';
Us = Us(:,nSkip+1:n-1)';
Ts = Ts(:,nSkip+1:n-1)';
NBs = NBs(:,nSkip+2:n)';


    

