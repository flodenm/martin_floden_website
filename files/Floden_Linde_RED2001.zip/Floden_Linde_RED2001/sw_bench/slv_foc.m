function [Va, A_dec, C_dec, H_dec, w, b] = ...
  slv_foc(Va,A_dec,C_dec,H_dec,Kbar,r,tau,Hbar,maxiters,maxdiff,Q,Zprob);

global sigma rho beta alfa delta theta mu gmma gga minA maxA A;
global ggz repinter solveiter firstiter maxsolvediff;
global tauK tauC G

% Wage as a function of r
%w = (1-theta) * ((r+delta)/theta)^(-theta/(1-theta));
w = (1-theta) / Hbar;        % Y=1 is assumed


Cbar = 1 - delta * Kbar - G;
b = tau * Hbar * w + tauK * r * Kbar + tauC * Cbar - G;
R = (1 + r * (1-tauK));

% ITERATE ON FOC TO SOLVE FOR VALUE FUNCTION

% Some calculations and initiations used in the loop

toc1 = toc;

Va = R * alfa * ((C_dec.^alfa).*((1-H_dec).^(1-alfa))).^(1-mu) ./ C_dec;

choose_h = zeros(gga,ggz);

indx = linspace(1,.5,gga);
indx = indx' * ones(1,gga);
  
diff = 1;
iters = 1;

while (iters <= maxiters) & (diff > maxdiff)
  
  preVa = Va;
  oldA_dec = A_dec;
  
  % Vectorize over current A
  % Right: current A
  
  for iZ = 1:ggz;
    
    PrNextZ = Zprob(iZ,:);
        
    EVanext = PrNextZ * preVa';       					% (1 * gga) vector 
    EVaBeq = interp1(A,EVanext,A+Kbar,'spline');			% Bequests possible
    EVanext = (1-gmma) * EVanext + gmma * EVaBeq;
    
    % Right: Current A, Down: Next A
    
    % 1. Solve for c, assuming h >= 0 does not bind
    cnst1 = ((1-alfa)*(1+tauC)/(alfa*(1-tau)*w*Q(iZ)))^((1-alfa)*(1-mu));
    c_dec = (alfa/(1+tauC)) * ...
            (b + (1-tau)*w*Q(iZ) + R*ones(gga,1)*A - A' * ones(1,gga));
    c_dec = max(c_dec,1e-8*indx);
    LHS = cnst1 * c_dec.^(-mu);
    RHS = (beta/alfa) * EVanext;
    compare = (LHS < (RHS' * ones(1,gga)));
    choice_indx = sum(compare);
    pick_low = min(max(choice_indx,1),gga-1);
    rr = spline(A,RHS);
    
        
        comp1 = choice_indx == gga;
        comp2 = choice_indx == 0;
        comp12 = 1 - (comp1 + comp2);
        Amin = comp1 .* A(gga) + (1-comp1) .* A(pick_low);
        Amax = comp2 .* A(1) + (1-comp2) .* A(pick_low+1);
        ind1 = (0:(gga-1)) * gga + pick_low;
        low_diff = comp12 .* (RHS(pick_low) - LHS(ind1)) + (1-comp12);
        hgh_diff = comp12 .* (-(RHS(pick_low+1) - LHS(ind1+1))) + (1-comp12);

        diff0 = 1;       
      
        ii = 1;
        while (ii <= solveiter) & (diff0 > maxsolvediff);
          
          if ii > firstiter,
            frac = hgh_diff ./ (low_diff + hgh_diff);
          else
            frac = 0.5;
          end;
          
          Aguess = frac .* Amin + (1-frac) .* Amax;

          RHS0 = ppval(rr,Aguess);
        
          ccc = (alfa/(1+tauC)) * (b + (1-tau)*w*Q(iZ) + R*A - Aguess);
%          if max(ccc) < 1e-5, 'ERROR (i)',  max(ccc), end;
%          ccc = max(ccc,1e-8);
          LHS0 = cnst1 * (ccc).^(-mu);
        
          diff0 = comp12 .* (RHS0 - LHS0);
          comp3 = diff0 > 0;
          Amin = comp3 .* Aguess + (1-comp3) .* Amin;
          low_diff = comp3 .* diff0 + (1-comp3) .* low_diff;
          Amax = comp3 .* Amax + (1-comp3) .* Aguess;
          hgh_diff = comp3 .* hgh_diff + (1-comp3) .* (-diff0);
          
%          if min(low_diff) < 0 | min(hgh_diff) < 0, 'ERROR (ii)', end;
          diff0 = max(abs(diff0) ./ (RHS0 + 1e-16));
          
          ii = ii + 1;
        end; % ii
        
        choice_A = Aguess;
        xx = diff0;
        if (abs(xx) > 0.01) & (diff < maxdiff * 100);
          prints('ERROR (iii)'); prints(xx,12,4,0);
        end;

        
        % *** %        
        
       
    % 2. Calculate implied labor supply
    h_dec = 1 - (1-alfa) * (1 + (b + R*A - choice_A)/((1-tau)*w*Q(iZ)));
    pos_h = (h_dec > 0);
    h_dec = min(h_dec,1-1e-8);
    h_dec = max(h_dec,0);
    
    % 3. For h >= 0 binding, recalculate A_next, i.e. assume h = 0
    c_dec = (b + R * ones(gga,1) * A - A' * ones(1,gga)) / (1+tauC);
    c_dec = max(c_dec,1e-8*indx);
    LHS = c_dec.^(alfa*(1-mu)-1);
    compare = (LHS < (RHS' * ones(1,gga)));
    choice_indx = sum(compare);
    pick_low = min(max(choice_indx,1),gga-1);
    
        comp1 = choice_indx == gga;
        comp2 = choice_indx == 0;
        comp12 = 1 - (comp1 + comp2);
        Amin = comp1 .* A(gga) + (1-comp1) .* A(pick_low);
        Amax = comp2 .* A(1) + (1-comp2) .* A(pick_low+1);
        ind1 = (0:(gga-1)) * gga + pick_low;
        low_diff = comp12 .* (RHS(pick_low) - LHS(ind1)) + (1-comp12);
        hgh_diff = comp12 .* (-(RHS(pick_low+1) - LHS(ind1+1))) + (1-comp12);
        comp12 = comp12 .* (1-pos_h);
        
        % *** %
        diff0 = 1;       
      
        ii = 1;
        while (ii <= solveiter) & (diff0 > maxsolvediff);
          
          if (ii > firstiter) & (low_diff + hgh_diff > 0),
            frac = hgh_diff ./ (low_diff + hgh_diff);
          else
            frac = 0.5;
          end;
          
          Aguess = frac .* Amin + (1-frac) .* Amax;

          RHS0 = ppval(rr,Aguess);
        
          ccc = (b + R*A - Aguess) / (1+tauC);
%          if max(ccc) < 1e-5, 'ERROR (i)b',  max(ccc), end;
%          ccc = max(ccc,1e-8);
          LHS0 = ccc.^(alfa*(1-mu)-1);
        
          diff0 = comp12 .* (RHS0 - LHS0);
          comp3 = diff0 > 0;
          Amin = comp3 .* Aguess + (1-comp3) .* Amin;
          low_diff = comp3 .* diff0 + (1-comp3) .* low_diff;
          Amax = comp3 .* Amax + (1-comp3) .* Aguess;
          hgh_diff = comp3 .* hgh_diff + (1-comp3) .* (-diff0);
          
%          if min(low_diff) < 0 | min(hgh_diff) < 0, 'ERROR (ii)b', end;
          diff0 = max(abs(diff0) ./ (RHS0 + 1e-16));
          
          ii = ii + 1;
        end; % ii
        
        choice_A2 = Aguess;
        xx = diff0;
        if (abs(xx) > 0.01) & (diff < maxdiff * 100);
          prints('ERROR (iii)b'); prints(xx,12,4,0);
        end;
        
    % 4. Is h = 0?
    choice_A = pos_h .* choice_A + (1-pos_h) .* choice_A2;    
    
    z = (b + (1-tau) * w * Q(iZ) * h_dec + R * A);
    Anext = choice_A;
    A_dec(:,iZ) = Anext';      
    C_dec(:,iZ) = max((z' - Anext')/(1+tauC),1e-8);
    H_dec(:,iZ) = h_dec';
    
  end;	% iQ
  
  % Update Va
  
  Va = R * alfa * ((C_dec.^alfa).*((1-H_dec).^(1-alfa))).^(1-mu) ...
       ./ C_dec;
     
  
  % Have we converged?
  
  nn = floor(0.99*gga);
  diff = norm(Va(1:nn,:)-preVa(1:nn,:)) / (norm(preVa(1:nn,:)) + 1E-16);

  [foc_a, foc_b] = foc(C_dec,H_dec,A_dec,A,Kbar,Zprob,alfa,mu,beta,gmma,R,tauC);
%  diff = norm(A_dec(1:nn,:) - oldA_dec(1:nn,:)) / (norm(oldA_dec(1:nn,:)) + 1E-16);
  
  toc2 = toc;
  if rem(iters,repinter) == 0
     prints('Iter: ');                prints(iters,4,0);
     prints('   Diff: ');             prints(diff,10,6);
     prints('   Elapsed time: ');     prints(toc2,8,2);
     prints('   Last loop: ');        prints(toc2-toc1,5,2,0);
  end;
  toc1 = toc2;

  iters = iters + 1;
  
end; % iters


diff2 = max(max(abs(foc_a-foc_b)./foc_a));
  
prints('Solved f.o.c. on iter: ');
prints(iters-1,4,0);
prints('   Diff: ');
prints(diff,10,6);
prints('   Diff2: ');
prints(diff2,10,6,0);

	