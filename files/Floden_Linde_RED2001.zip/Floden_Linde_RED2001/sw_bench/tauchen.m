function [Z,Zprob] = tauchen(ggz,a,rho,sigma,m)
%Function TAUCHEN
%
%Purpose:    Finds a discrete-valued Markov chain whose sample paths
%            approximate those of the AR(1) process
%                z(t+1) = a + rho * z(t) + eps(t+1)
%            where eps are normal with stddev sigma
%
%Format:     {Z, Zprob} = Tauchen(ggz,a,rho,sigma)
%
%Input:      ggz     scalar, number of points in z-grid
%            a       scalar
%            rho     scalar
%            sigma   scalar, std. dev. of epsilons
%            m       max +- std. devs.
%
%Output:     Z       ggz * 1 vector, grid for Z
%            Zprob   ggz * ggz matrix, transition probabilities
%
%    Martin Floden
%    Harvard U.
%    Fall 1996
%
%    This procedure is an implementation of George Tauchen's algorithm
%    described in Ec. Letters 20 (1986) 177-181.
%
%    The algorithm is extended to allow for a constant in the AR-process.
%


  Z = zeros(ggz,1);
  Zprob = zeros(ggz,ggz);

  Z(ggz) = m * sqrt(sigma^2 / (1 - rho^2));
  Z(1) = -Z(ggz);
  zstep = (Z(ggz) - Z(1)) / (ggz - 1);

  for i=2:(ggz-1),
    Z(i) = Z(1) + zstep * (i - 1);
  end 

  Z = Z + a / (1-rho);

  for j = 1:ggz,
    for k = 1:ggz,
      if k == 1,
        Zprob(j,k) = cdf('norm',(Z(1) - a - rho * Z(j) + zstep / 2) / sigma,0,1);
      elseif k == ggz,
        Zprob(j,k) = 1 - cdf('norm',(Z(ggz) - a - ... 
                       rho * Z(j) - zstep / 2) / sigma,0,1);
      else,
        Zprob(j,k) = ...
              cdf('norm',(Z(k) - a - rho * Z(j) + zstep / 2) / sigma,0,1) - ...
              cdf('norm',(Z(k) - a - rho * Z(j) - zstep / 2) / sigma,0,1);
      end
    end
  end

Z = Z';




