function [foc, next_foc] = test_foc(i,j,Cdec,Hdec,Adec,A,Kbar,Zprob,alpha,mu,beta,gmma,R,tauC,wQ)
% evaluate first order conditions
% 2000-03-27

[nA, nZ] = size(Cdec);

foc = alpha * (Cdec(i,j)^alpha * (1-Hdec(i,j))^(1-alpha))^(1-mu) / Cdec(i,j);

i1 = sum(Adec(i,j)>=A);
i1 = min(i1,nA-1);
i2 = min(i1+1,nA);
w1=(A(i2)-Adec(i,j))/(A(i2)-A(i1));
c1 = Cdec(i1,:)*w1+Cdec(i2,:)*(1-w1);
h1 = Hdec(i1,:)*w1+Hdec(i2,:)*(1-w1);


i1 = sum(Adec(i,j)+Kbar>=A);
i1 = min(i1,nA-1);
i2 = min(i1+1,nA);
w1=(A(i2)-Adec(i,j)-Kbar)/(A(i2)-A(i1));
c2 = Cdec(i1,:)*w1+Cdec(i2,:)*(1-w1);
h2 = Hdec(i1,:)*w1+Hdec(i2,:)*(1-w1);

foc1 = alpha * c1.^(alpha*(1-mu)-1) .* (1-h1).^((1-alpha)*(1-mu));
foc2 = alpha * c2.^(alpha*(1-mu)-1) .* (1-h2).^((1-alpha)*(1-mu));

%foc3 = alpha * c1.^(-mu) * ((1-alpha)*(1+tauC)./(alpha.*wQ)).^((1-alpha)*(1-mu));


next_foc1 = beta * R *  foc1 * Zprob(j,:)' / (1+tauC);
next_foc2 = beta * R *  foc2 * Zprob(j,:)' / (1+tauC);

next_foc = (1-gmma) * next_foc1 + gmma * next_foc2;

