clear all
global sigma rho beta alfa theta delta mu gmma gga minA maxA A
global ggz repinter solveiter firstiter maxsolvediff
global tauK tauC G


country = 'us';				% 'us' or 'swe'
outfile = 'us_tmp.out';	    % File for report
resfile = 'res_us';         % File for result matrix
infile  = 'v';		 		% Load previous solution
header  = 'US, benchmark';



maxiters = 100;				% Max iters on foc
maxdiff = 1e-5;				% Conv. crit. for foc
maxRIter = 18;				% Max r guesses / tax rate	
maxHIter = 8;               % Max Hbar guesses / r guess
maxKDiff = 0.002;			% Conv. crit. for capital
maxHdiff = 0.0002;			% Conv. crit. for aggr. hours
nsimuls = 2000;				% # of simulations

initiate = 'estim';			% 'prev ' or 'guess'
 
repinter   = 150;  			% Interval for showing foc progress
solveiter  = 25;			% Max iters when solving RHS = LHS
firstiter  = 3;				% Iters using half steps when solving
maxsolvediff  = 1e-4;		% Conv. crit. when solving RHS = LHS

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

tic;
diary(outfile);
rand('seed',124508977743109711);

% PARAMETER VALUES
if country == 'us'
  sigma 	  = sqrt(0.042568);	  % SD of productivity shocks 
  sigma_perm  = sqrt(0.11754);	  % SD of permanent income differences
  rho 		  = 0.91355;		  % Persistence of productivity shocks
  G = 0.217;                      % K�lla: AM
  tauK = 0.397;                   % DH, 2000         
  tauC = 0.054;                   % DH, 2000
elseif country == 'sw'
  sigma 	  = sqrt(0.032611);
  sigma_perm  = sqrt(0.046723);
  rho		  = 0.81386;
  G = 0.291;                      % K�lla: Jesper
  tauK = 0.3;           
  tauC = 0.177;                   % K�lla: Jesper
else
  'Incorrect country'
  break;
end;

theta   	= 0.36;				% Capital share in production
delta 	    = 0.1;				% Depreciation rate of physical capital
gmma		= 0.02;				% Death rate
alfa 	= 0.50;		    		% Disutility parameter for labor supply
beta = .94895;
mu		= 2;					% Risk aversion


% ==================== 
% Calibrate benchmark
% Find right beta
% ====================
if 3>2
  benchU = -1;
  betamin = .9623;
  betamax = .9627;
  
  targetB = .082;
  targetK = 2.6;
  targetC = 1 - delta*targetK - G;
  targetR = theta/targetK - delta
  tau0 = (G + targetB - tauC*targetC - tauK*targetR*targetK) / (1-theta)
  TAUgrid = tau0;
  R0grid = targetR;
  HQgrid = .42789;

  maxRIter = 1;				% Max r guesses / tax rate	
  diff = 1;
  while diff > .002
    results = [];
    beta = (betamin+betamax)/2
    main
    diff = abs(EA-K);
    if EA>Kbar
       betamax = beta
    else
       betamin = beta
    end
    HQgrid = Hbar;
    R0grid = targetR;
    save v Va_* A_dec_* C_dec_* H_dec_*
  end

end


% Tax rates to examine, initial guesses
TAUgrid =   [0.22:.01:.60];
R0grid =    [0.034 .0341];
HQgrid =    [0.470 .470];
maxRIter = 18;
load res_us
benchU = results(1,21);

main