/* Part 1 of program constructing w/h series from PSID data.
   First version: Nov/Dec 1997.
   Merge 1988 to 1992 files. Pick wage and hours worked info */

libname outdir 'c:\jesper\psid_wom\';

    /* Read in 1988-1992 cross-year individual file and select variables
      needed for analysis. */

data outdir.ind88_92(compress=no
                           rename=(V30570=ID88 V30606=ID89 V30642=ID90 V30689=ID91 V30733=ID92));
infile 'c:\martin\data\psid\taxation\ind68_92.dat' LRECL=1888;

input
       V30001  1-4
       V30002  5-7
       V30570  1238-1241
       V30571  1242-1243
       V30572  1244-1245
       V30573  1246-1247
       V30584  1266-1267
       V30606  1320-1323
       V30607  1324-1325
       V30608  1326-1327
       V30642  1402-1406
       V30643  1407-1408
       V30644  1409-1410
       V30689  1513-1517
       V30690  1518-1519
       V30691  1520-1521
       V30733  1623-1627
       V30734  1628-1629
       V30735  1630-1631
       V32000  1786;
label
       V30001 = "1968 INTERVIEW NUMBER 68"
       V30002 = "PERSON NUMBER         68"
       V30570 = "1988 INTERVIEW NUMBER"
       V30571 = "SEQUENCE NUMBER       88"
       V30572 = "RELATIONSHIP TO HEAD  88"
       V30573 = "AGE OF INDIVIDUAL     88"
       V30584 = "COMPLETED EDUCATION   88"
       V30606 = "1989 INTERVIEW NUMBER"
       V30607 = "SEQUENCE NUMBER       89"
       V30608 = "RELATIONSHIP TO HEAD  89"
       V30642 = "1990 INTERVIEW NUMBER"
       V30643 = "SEQUENCE NUMBER       90"
       V30644 = "RELATIONSHIP TO HEAD  90"
       V30689 = "1991 INTERVIEW NUMBER"
       V30690 = "SEQUENCE NUMBER       91"
       V30691 = "RELATIONSHIP TO HEAD  91"
       V30733 = "1991 INTERVIEW NUMBER"
       V30734 = "SEQUENCE NUMBER       92"
       V30735 = "RELATIONSHIP TO HEAD  92"
       V32000 = "SEX OF INDIVIDUAL";

/* Missing values */
if V30573 = 99 then V30573 = .;
if V30584 = 99 then V30584 = .;

/* Select those men who were always heads 1988 and 1990-1992 */
if  (V30571 = 1 and V30572 = 10) and
    (V30607 = 1 and V30608 = 10) and
    (V30643 = 1 and V30644 = 10) and
    (V30690 = 1 and V30691 = 10) and
    (V30734 = 1 and V30735 = 10);

/* Select SRC sample only */
if V30001 < 5000;

MAN = (2 - V32000);

drop V30571 V30572 V30607 V30608 V30643 V30644 V30690 V30691 V30734 V30735 V32000;

run;


/* ======== 1988 ======== */

/* Read in 1988 family file and select variables needed for analysis */
data outdir.fam88(compress=no
                           rename=(V14802=ID88));
infile 'c:\martin\data\psid\taxation\fam88.dat' LRECL=2721;
input
       V14802  4-7
       V14830  65
       V14832  70
       V14834  75
       V14835  76-79
       V14836  80-83
       V14837  84
       V14838  85-88
       V14839  89
       V14842  95-98
       V14843  99
       V14911  208-212
       V14912  213-217
       V14913  218-223
       V14914  224
       V14915  225-229
       V14916  230-235
       V14917  236-240
       V14918  241-245
       V15154  839
       V15162  848-850;
label
       V14802 = "1988 INTERVIEW NUMBER"
       V14830 = "ACC HD 87 MAIN JOB WRKHR"
       V14832 = "ACC HD 87 OVERTIME WRKHR"
       V14834 = "ACC HD 87 XTRA JOB WRKHR"
       V14835 = "HD ANN WRK HRS IN 87"
       V14836 = "HD 87 HRS WRK LOST OTR ILL"
       V14837 = "ACC HD HR LOST OTR ILL"
       V14838 = "HD 87 HRS WRK LOST OWN ILL"
       V14839 = "ACC HD HR LOST OWN ILL"
       V14842 = "HD UNEMP HRS 87"
       V14843 = "ACC 87 HD UNEMP HRS"
       V14911 = "LABOR PART FARM 87"
       V14912 = "LABOR PART BUS 87"
       V14913 = "HEAD 87 WAGES"
       V14914 = "ACC HEAD 87 WAGES"
       V14915 = "HD BONUS/OT/COMM 87"
       V14916 = "HD PROF PRAC/TRADE 87"
       V14917 = "LABOR PT MKT GARDEN 87"
       V14918 = "LABOR PART ROOMERS 87"
       V15154 = "EMPLOYMENT STATUS 87"
       V15162 = "MAIN OCCUPATION 87";

/* Missing values */
if V15162 = 999 then V15162 = .;

/* Remove heavily assigned values, top-loaded data, and people not in labor force */
if    V14830 < 2 and V14832 < 2 and V14834 < 2 and
      V14837 < 2 and V14839 < 2 and
      V14843 < 2 and
      V14914 < 2 and
      V14911 < 99999  and V14912 < 99999 and
      V14913 < 999999 and V14915 < 99999 and
      V14916 < 999999 and V14917 < 99999 and V14918 < 99999 and
      V15154 < 4;
run;

/* Sort files by id88 and merge */
proc sort data=outdir.ind88_92 tagsort; by ID88;
proc sort data=outdir.fam88    tagsort; by ID88;
run;

data outdir.fam_ind(compress=yes);
merge outdir.fam88 outdir.ind88_92(in=ind88_92); by ID88; if ind88_92;
drop V14830 V14832 V14834 V14837 V14839 V14843 V14914 V15154;
run;


/* ======== 1989 ======== */

/* Read in 1989 family file and select variables needed for analysis */
data outdir.fam89(compress=no
                           rename=(V16302=ID89));
infile 'c:\martin\data\psid\taxation\fam89.dat' LRECL=2506;
input
       V16302  4-7
       V16330  65
       V16332  70
       V16334  75
       V16335  76-79
       V16336  80-83
       V16337  84
       V16338  85-88
       V16339  89
       V16342  95-98
       V16343  99
       V16411  208-212
       V16412  213-217
       V16413  218-223
       V16414  224
       V16415  225-229
       V16416  230-235
       V16417  236-240
       V16418  241-245
       V16655  843;
label
       V16302 = "1989 INTERVIEW NUMBER"
       V16330 = "ACC HD 88 MAIN JOB WRKHR"
       V16332 = "ACC HD 88 OVERTIME WRKHR"
       V16334 = "ACC HD 88 XTRA JOB WRKHR"
       V16335 = "HD ANN WRK HRS IN 88"
       V16336 = "HD 88 HRS WRK LOST OTR ILL"
       V16337 = "ACC HD HR LOST OTR ILL"
       V16338 = "HD 88 HRS WRK LOST OWN ILL"
       V16339 = "ACC HD HR LOST OWN ILL"
       V16342 = "HD UNEMP HRS 88"
       V16343 = "ACC 88 HD UNEMP HRS"
       V16411 = "LABOR PART FARM 88"
       V16412 = "LABOR PART BUS 88"
       V16413 = "HEAD 88 WAGES"
       V16414 = "ACC HEAD 88 WAGES"
       V16415 = "HD BONUS/OT/COMM 88"
       V16416 = "HD PROF PRAC/TRADE 88"
       V16417 = "LABOR PT MKT GARDEN 88"
       V16418 = "LABOR PART ROOMERS 88"
       V16655 = "EMPLOYMENT STATUS 88";

/* Remove heavily assigned values, top-loaded data, and people not in labor force */
if    V16330 < 2 and V16332 < 2 and V16334 < 2 and
      V16337 < 2 and V16339 < 2 and
      V16343 < 2 and
      V16414 < 2 and
      V16411 < 99999  and V16412 < 99999 and
      V16413 < 999999 and V16415 < 99999 and
      V16416 < 999999 and V16417 < 99999 and V16418 < 99999 and
      V16655 < 4;
run;

/* Sort files by id89 and merge */
proc sort data=outdir.fam_ind tagsort; by ID89;
proc sort data=outdir.fam89   tagsort; by ID89;
run;

data outdir.fam_ind(compress=no);
merge outdir.fam89 outdir.fam_ind(in=fam_ind); by ID89; if fam_ind;
drop V16330 V16332 V16334 V16337 V16339 V16343 V16414 V16655;
run;


/* ======== 1990 ======== */

/* Read in 1990 family file and select variables needed for analysis */
data outdir.fam90(compress=no
                           rename=(V17702=ID90));
infile 'c:\martin\data\psid\taxation\fam90.dat' LRECL=2333;
input
       V17702  4-8
       V17739  93
       V17741  98
       V17743  103
       V17744  104-107
       V17745  108-111
       V17746  112
       V17747  113-116
       V17748  117
       V17751  123-126
       V17752  127
       V17827  252-256
       V17828  257-261
       V17829  262-267
       V17830  268
       V17831  269-273
       V17832  274-279
       V17833  280-284
       V17834  285-289
       V18093  918;
label
       V17702 = "1990 INTERVIEW NUMBER"
       V17739 = "ACC HD 89 MAIN JOB WRKHR"
       V17741 = "ACC HD 89 OVERTIME WRKHR"
       V17743 = "ACC HD 89 XTRA JOB WRKHR"
       V17744 = "HD ANN WRK HRS IN 89"
       V17745 = "HD 89 HRS WRK LOST OTR ILL"
       V17746 = "ACC HD HR LOST OTR ILL"
       V17747 = "HD 89 HRS WRK LOST OWN ILL"
       V17748 = "ACC HD HR LOST OWN ILL"
       V17751 = "HD UNEMP HRS 89"
       V17752 = "ACC 89 HD UNEMP HRS"
       V17827 = "LABOR PART FARM 89"
       V17828 = "LABOR PART BUS 89"
       V17829 = "HEAD 89 WAGES"
       V17830 = "ACC HEAD 89 WAGES"
       V17831 = "HD BONUS/OT/COMM 89"
       V17832 = "HD PROF PRAC/TRADE 89"
       V17833 = "LABOR PT MKT GARDEN 89"
       V17834 = "LABOR PART ROOMERS 89"
       V18093 = "EMPLOYMENT STATUS 89";

/* Remove heavily assigned values, top-loaded data, and people not in labor force */
if    V17739 < 2 and V17741 < 2 and V17743 < 2 and
      V17746 < 2 and V17748 < 2 and
      V17752 < 2 and
      V17830 < 2 and
      V17827 < 99999  and V17830 < 99999 and
      V17829 < 999999 and V17831 < 99999 and
      V17832 < 999999 and V17833 < 99999 and V17834 < 99999 and
      V18093 < 4;
run;

/* Sort files by id90 and merge */
proc sort data=outdir.fam_ind tagsort; by ID90;
proc sort data=outdir.fam90   tagsort; by ID90;
run;

data outdir.fam_ind(compress=no);
merge outdir.fam90 outdir.fam_ind(in=fam_ind); by ID90; if fam_ind;
drop V17739 V17741 V17743 V17746 V17748 V17752 V17830 V18093;
run;


/* ======== 1991 ======== */

/* Read in 1991 family file and select variables needed for analysis */
data outdir.fam91(compress=no
                           rename=(V19002=ID91));
infile 'c:\martin\data\psid\taxation\fam91.dat' LRECL=2336;
input
       V19002  4-8
       V19039  93
       V19041  98
       V19043  103
       V19044  104-107
       V19045  108-111
       V19046  112
       V19047  113-116
       V19048  117
       V19051  123-126
       V19052  127
       V19127  252-256
       V19128  257-261
       V19129  262-267
       V19130  268
       V19131  269-273
       V19132  274-279
       V19133  280-284
       V19134  285-289
       V19393  919;
label
       V19002 = "1991 INTERVIEW NUMBER"
       V19039 = "ACC HD 90 MAIN JOB WRKHR"
       V19041 = "ACC HD 90 OVERTIME WRKHR"
       V19043 = "ACC HD 90 XTRA JOB WRKHR"
       V19044 = "HD ANN WRK HRS IN 90"
       V19045 = "HD 90 HRS WRK LOST OTR ILL"
       V19046 = "ACC HD HR LOST OTR ILL"
       V19047 = "HD 90 HRS WRK LOST OWN ILL"
       V19048 = "ACC HD HR LOST OWN ILL"
       V19051 = "HD UNEMP HRS 90"
       V19052 = "ACC 90 HD UNEMP HRS"
       V19127 = "LABOR PART FARM 90"
       V19128 = "LABOR PART BUS 90"
       V19129 = "HEAD 90 WAGES"
       V19130 = "ACC HEAD 90 WAGES"
       V19131 = "HD BONUS/OT/COMM 90"
       V19132 = "HD PROF PRAC/TRADE 90"
       V19133 = "LABOR PT MKT GARDEN 90"
       V19134 = "LABOR PART ROOMERS 90"
       V19393 = "EMPLOYMENT STATUS 90";

/* Remove heavily assigned values, top-loaded data, and people not in labor force */
if    V19039 < 2 and V19041 < 2 and V19043 < 2 and
      V19046 < 2 and V19048 < 2 and
      V19052 < 2 and
      V19130 < 2 and
      V19127 < 99999  and V19130 < 99999 and
      V19129 < 999999 and V19131 < 99999 and
      V19132 < 999999 and V19133 < 99999 and V19134 < 99999 and
      V19393 < 4;
run;

/* Sort files by id91 and merge */
proc sort data=outdir.fam_ind tagsort; by ID91;
proc sort data=outdir.fam91   tagsort; by ID91;
run;

data outdir.fam_ind(compress=no);
merge outdir.fam91 outdir.fam_ind(in=fam_ind); by ID91; if fam_ind;
drop V19039 V19041 V19043 V19046 V19048 V19052 V19130 V19393;
run;


/* ======== 1992 ======== */

/* Read in 1992 family file and select variables needed for analysis */
data outdir.fam92(compress=no
                           rename=(V20302=ID92));
infile 'c:\martin\data\psid\taxation\fam92.dat' LRECL=2347;
input
       V20302  4-8
       V20339  93
       V20341  98
       V20343  103
       V20344  104-107
       V20345  108-111
       V20346  112
       V20347  113-116
       V20348  117
       V20351  123-126
       V20352  127
       V20427  252-256
       V20428  257-261
       V20429  262-267
       V20430  268
       V20431  269-273
       V20432  274-279
       V20433  280-284
       V20434  285-289
       V20693  926;
label
       V20302 = "1991 INTERVIEW NUMBER"
       V20339 = "ACC HD 91 MAIN JOB WRKHR"
       V20341 = "ACC HD 91 OVERTIME WRKHR"
       V20343 = "ACC HD 91 XTRA JOB WRKHR"
       V20344 = "HD ANN WRK HRS IN 91"
       V20345 = "HD 91 HRS WRK LOST OTR ILL"
       V20346 = "ACC HD HR LOST OTR ILL"
       V20347 = "HD 91 HRS WRK LOST OWN ILL"
       V20348 = "ACC HD HR LOST OWN ILL"
       V20351 = "HD UNEMP HRS 91"
       V20352 = "ACC 91 HD UNEMP HRS"
       V20427 = "LABOR PART FARM 91"
       V20428 = "LABOR PART BUS 91"
       V20429 = "HEAD 91 WAGES"
       V20430 = "ACC HEAD 91 WAGES"
       V20431 = "HD BONUS/OT/COMM 91"
       V20432 = "HD PROF PRAC/TRADE 91"
       V20433 = "LABOR PT MKT GARDEN 91"
       V20434 = "LABOR PART ROOMERS 91"
       V20693 = "EMPLOYMENT STATUS 91";

/* Remove heavily assigned values, top-loaded data, and people not in labor force */
if    V20339 < 2 and V20341 < 2 and V20343 < 2 and
      V20346 < 2 and V20348 < 2 and
      V20352 < 2 and
      V20430 < 2 and
      V20427 < 99999  and V20428 < 99999 and
      V20429 < 999999 and V20431 < 99999 and
      V20432 < 999999 and V20433 < 99999 and V20434 < 99999 and
      V20693 < 4;
run;

/* Sort files by id92 and merge */
proc sort data=outdir.fam_ind tagsort; by ID92;
proc sort data=outdir.fam92   tagsort; by ID92;
run;

data outdir.fam_ind(compress=no);
merge outdir.fam92 outdir.fam_ind(in=fam_ind); by ID92; if fam_ind;
drop V20339 V20341 V20343 V20346 V20348 V20352 V20430 V20693;
run;
