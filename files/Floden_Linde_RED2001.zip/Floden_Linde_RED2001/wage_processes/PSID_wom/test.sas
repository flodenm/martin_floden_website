/* Part 2 of PSID data manipulation.
   Generate series for hours worked and wage per hour. */

libname outdir 'c:\';
libname indir 'c:\';

data outdir.nyfil;
set indir.eva;

remark = 'xxxxxx';

run;
/* Part 2 of PSID data manipulation.
   Generate series for hours worked and wage per hour. */

libname outdir 'c:\jesper\psid_wom\';
libname indir 'c:\jesper\psid_wom\';

data outdir.psid(rename=(V15162=OCC V30573=AGE V30584=EDUC));
set indir.fam_ind;

remark2 = 'xxxxxx';

run;
