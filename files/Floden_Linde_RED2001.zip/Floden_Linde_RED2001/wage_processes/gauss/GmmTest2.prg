New;

output file = c:\jesper\hink\psid\gmmuncUS.out reset;

Library pgraph, optmum;

    /* First I do some datatransformations. */

load data[] = c:\jesper\hink\psid\mkuudata.txt;
data = reshape( data,rows(data)/17,17 );
age = data[.,1];
educ = data[.,2];
dman = data[.,3];
occ1 = data[.,9];
occ2 = data[.,10];
occ3 = data[.,11];
occ4 = data[.,12];
occ5 = data[.,13];
occ6 = data[.,14];
occ7 = data[.,15];
occ8 = data[.,16];
occ9 = data[.,17];
wh88 = data[.,4]; /* Note: Hourly wages in nominal USD. */
wh89 = data[.,5];
wh90 = data[.,6];
wh91 = data[.,7];
wh92 = data[.,8];

/* Computing means for the hourly wages. */

print "Mean WH 1988 in USD" meanc(wh88); "";
print "Mean WH 1989 in USD" meanc(wh89); "";
print "Mean WH 1990 in USD" meanc(wh90); "";
print "Mean WH 1991 in USD" meanc(wh91); "";
print "Mean WH 1992 in USD" meanc(wh92); "";

/* Taking Averages and compute statistics. */

wh88 = wh88./meanc(wh88);
wh89 = wh89./meanc(wh89);
wh90 = wh90./meanc(wh90);
wh91 = wh91./meanc(wh91);
wh92 = wh92./meanc(wh92);

/* Generate some descriptive statistics for the untransformed WH-variables. */

desc_mat = wh88~wh89~wh90~wh91~wh92;
__altnam = { WH88, WH89 , WH90 , WH91, WH92 };
""; "Descriptive statistics for the untransformed wage variables";
{ vnam, mean, var, std, min, max, valid, mis } = dstat(0,desc_mat); "";

pause(5);

/* Compute individual descriptive statistics. */

"Descriptive statistics for the untransformed wage variables - agent level";"";

min_ave_indw = minc(meanc(desc_mat'));
max_ave_indw = maxc(meanc(desc_mat'));
var_ave_indw = desc_mat-meanc(desc_mat');
ave_var_indw = meanc(diag(var_ave_indw*var_ave_indw'));
min_var_indw = minc(diag(var_ave_indw*var_ave_indw'));
max_var_indw = maxc(diag(var_ave_indw*var_ave_indw'));

print "Minimum average relative wage in the sample" min_ave_indw;"";
print "Maximum average relative wage in the sample" max_ave_indw;"";
print "Average individual variance in w in the sample" ave_var_indw;"";
print "Minimum individual variance in w in the sample" min_var_indw;"";
print "Maximum individual variance in w in the sample" max_var_indw;"";

/* Do this since Martin do it. */

wh = wh88~wh89~wh90~wh91~wh92;

BigN = rows(wh);
ncol = cols(wh);
icol = 1;
Counter = 0;
do while icol <= ncol;

 Counter = 0;
 i=1;
  do while i<=BigN;
    if wh[i,icol] < 0.10;
    wh[i,icol] = 0.10;
    Counter = Counter+1;
    endif;
   i=i+1;
  Endo;

 print "The number with less than 10% of average WH in";;
 print (1987+icol) "is";; print Counter; "";

 icol=icol+1;

Endo;

pause(5);

wh88 = ln(wh[.,1]);
wh89 = ln(wh[.,2]);
wh90 = ln(wh[.,3]);
wh91 = ln(wh[.,4]);
wh92 = ln(wh[.,5]);

/* Generate some descriptive statistics for the untransformed WH-variables. */

desc_mat = exp(wh88)~exp(wh89)~exp(wh90)~exp(wh91)~exp(wh92);
__altnam = { WH88, WH89 , WH90 , WH91, WH92 };
""; "Descriptive statistics for the untransformed wage variables - min10%";
{ vnam, mean, var, std, min, max, valid, mis } = dstat(0,desc_mat); "";

pause(5);

/* Compute individual descriptive statistics. */

"Descriptive statistics for the untransformed wages min 10% - agent level";"";

min_ave_indw = minc(meanc(desc_mat'));
max_ave_indw = maxc(meanc(desc_mat'));
var_ave_indw = desc_mat-meanc(desc_mat');
ave_var_indw = meanc(diag(var_ave_indw*var_ave_indw'));
min_var_indw = minc(diag(var_ave_indw*var_ave_indw'));
max_var_indw = maxc(diag(var_ave_indw*var_ave_indw'));

print "Minimum average relative wage in the sample" min_ave_indw;"";
print "Maximum average relative wage in the sample" max_ave_indw;"";
print "Average individual variance in w in the sample" ave_var_indw;"";
print "Minimum individual variance in w in the sample" min_var_indw;"";
print "Maximum individual variance in w in the sample" max_var_indw;"";

/*
/* Extracting out just mens (or wo-mens). */

save_mat = zeros(1,15);
i = 1;
do while i <= rows(dman);
  if dman[i] == 0;
    save_mat = save_mat |
    (wh88[i]~wh89[i]~wh90[i]~wh91[i]~wh92[i]~age[i]~educ[i]~
     occ1[i]~occ2[i]~occ3[i]~occ4[i]~occ5[i]~occ6[i]~occ7[i]~occ8[i]);
  endif;
  i = i + 1;
endo;

save_mat = save_mat[2:rows(save_mat),.];
wh88 = save_mat[.,1];
wh89 = save_mat[.,2];
wh90 = save_mat[.,3];
wh91 = save_mat[.,4];
wh92 = save_mat[.,5];
age = save_mat[.,6];
educ = save_mat[.,7];
occ1 = save_mat[.,8];
occ2 = save_mat[.,9];
occ3 = save_mat[.,10];
occ4 = save_mat[.,11];
occ5 = save_mat[.,12];
occ6 = save_mat[.,13];
occ7 = save_mat[.,14];
occ8 = save_mat[.,15];
*/

/* Doing the regression to extract out the systematic part of the wages. */

__altnam = { AGE, AGE_sq, EDUC, OCC1, OCC2, OCC3, OCC4, OCC5, OCC6, OCC7,
             OCC8, DMAN, lnWH88 };

BigX = age~(age.^2)~educ~occ1~occ2~occ3~occ4~occ5~occ6~occ7~occ8~dman;

"Regression results for the systematic part of the wage equation";"";
{ var1, var2, beta_hat, var3, var4, var5, var6, var7, var8, var9, var10 } =
OLS(0,wh88,BigX);"";

BigX = ones(rows(BigX),1)~BigX;

/* Extracting out the idiosyncratic part. */

wh88 = wh88 - BigX*beta_hat;
wh89 = wh89 - BigX*beta_hat;
wh90 = wh90 - BigX*beta_hat;
wh91 = wh91 - BigX*beta_hat;
wh92 = wh92 - BigX*beta_hat;

/* Generate some descriptive statistics for the transformed WH-variables. */

desc_mat = exp(wh88)~exp(wh89)~exp(wh90)~exp(wh91)~exp(wh92);
__altnam = { WH88, WH89 , WH90 , WH91, WH92 };
""; "Descriptive statistics for the transformed wage variables";
{ vnam, mean, var, std, min, max, valid, mis } = dstat(0,desc_mat); "";

pause(5);

/* Compute individual descriptive statistics. */

"Descriptive statistics for the transformed wage variables - agent level";"";

min_ave_indw = minc(meanc(desc_mat'));
max_ave_indw = maxc(meanc(desc_mat'));
var_ave_indw = desc_mat-meanc(desc_mat');
ave_var_indw = meanc(diag(var_ave_indw*var_ave_indw'));
min_var_indw = minc(diag(var_ave_indw*var_ave_indw'));
max_var_indw = maxc(diag(var_ave_indw*var_ave_indw'));

print "Minimum average relative wage in the sample" min_ave_indw;"";
print "Maximum average relative wage in the sample" max_ave_indw;"";
print "Average individual variance in w in the sample" ave_var_indw;"";
print "Minimum individual variance in w in the sample" min_var_indw;"";
print "Maximum individual variance in w in the sample" max_var_indw;"";

/* Demeaning the transformed wages. */
/*
wh = wh88~wh89~wh90~wh91~wh92;
wh = wh - meanc(wh)';
*/

/* GENERATE A NEW WAGE VARIABLE. */

wh = (wh89-wh88)~(wh90-wh89)~(wh91-wh90)~(wh92-wh91);
wh = wh - meanc(wh)';

clear data;

/* **************** End data generation and transformation. ************* */

/*
/* **************** Testing for normality. ****************************** */

/* Computing the Jarque-Bera test statistic for each year in the panel. */

/* First Skewness. Following Hamilton[1994] page 746. */

Skew = ( meanc(wh.^3) ) ./ ( (meanc(wh.^2)).^(3/2) ) ;
print "Skew" Skew;"";

/* Then Kurtosis. Following Hamilton[1994] page 746. */

Kurt = ( meanc(wh.^4) ) ./ ( (meanc(wh.^2)).^(4/2) ) ;
print "Kurt" Kurt;"";

/* Calculating the Jarqe-Bera statistic. Following S"derlind[1996] LecNotes. */

JB = (rows(wh)/6) * Skew.^2 + (rows(wh)/24) * (Kurt-3*ones(cols(wh),1)).^2 ;
print "Jarque-Bera test statistic for 1988, 1989, 1990, 1991 and 1992" JB;"";

pause(5);

/* Computing the Jarque-Bera test statistic without time-dimension -
   taking individual averages for the years in the panel. */

/* First Skewness. Following Hamilton[1994] page 746. */

Skew = ( meanc(meanc(wh').^3) ) ./ ( (meanc(meanc(wh').^2)).^(3/2) ) ;
print "Skew" Skew;"";

/* Then Kurtosis. Following Hamilton[1994] page 746. */

Kurt = ( meanc(meanc(wh').^4) ) ./ ( (meanc(meanc(wh').^2)).^(4/2) ) ;
print "Kurt" Kurt;"";

/* Calculating the Jarqe-Bera statistic. Following S"derlind[1996] LecNotes. */

JB = (rows(wh)/6) * Skew^2 + (rows(wh)/24) * (Kurt-3)^2 ;
print "Jarque-Bera test statistic for average individual wage" JB;"";

pause(5);

/* Computing the Jarque-Bera test statistic without time-dimension. */

/* First Skewness. Following Hamilton[1994] page 746. */

Skew = ( meanc(vecr(wh).^3) ) ./ ( (meanc(vecr(wh).^2)).^(3/2) ) ;
print "Skew" Skew;"";

/* Then Kurtosis. Following Hamilton[1994] page 746. */

Kurt = ( meanc(vecr(wh).^4) ) ./ ( (meanc(vecr(wh).^2)).^(4/2) ) ;
print "Kurt" Kurt;"";

/* Calculating the Jarqe-Bera statistic. Following S"derlind[1996] LecNotes. */

JB = (rows(wh)/6) * Skew^2 + (rows(wh)/24) * (Kurt-3)^2 ;
print "Jarque-Bera test statistic for truncated 1988, 89, 90, 91 and 92" JB;"";

pause(5);

/* Draw Histograms over the sample. */

graphset;

_ptek = "Histgram.tkf";
_pylabel = "Number of individuals";
_pxlabel = "Relative wages in natural logs 1988";
{ b,g,f } = hist(wh[.,1],100);
exec( "c:\\jesper~2\\gauss\\pqgrun.exe","Histgram -c=3 -cf=UsHi1988.hgl" );
_pxlabel = "Relative wages in natural logs 1989";
{ b,g,f } = hist(wh[.,2],100);
exec( "c:\\jesper~2\\gauss\\pqgrun.exe","Histgram -c=3 -cf=UsHi1989.hgl" );
_pxlabel = "Relative wages in natural logs 1990";
{ b,g,f } = hist(wh[.,3],100);
exec( "c:\\jesper~2\\gauss\\pqgrun.exe","Histgram -c=3 -cf=UsHi1990.hgl" );
_pxlabel = "Relative wages in natural logs 1991";
{ b,g,f } = hist(wh[.,4],100);
exec( "c:\\jesper~2\\gauss\\pqgrun.exe","Histgram -c=3 -cf=UsHi1991.hgl" );
_pxlabel = "Relative wages in natural logs 1992";
{ b,g,f } = hist(wh[.,5],100);
exec( "c:\\jesper~2\\gauss\\pqgrun.exe","Histgram -c=3 -cf=UsHi1992.hgl" );
_pxlabel = "Relative wages in natural logs 1988, 1989, 1990, 1991 and 1992";
{ b,g,f } = hist(vecr(wh),100);
exec( "c:\\jesper~2\\gauss\\pqgrun.exe","Histgram -c=3 -cf=UsHi82.hgl" );
_pxlabel = "Relative average indvidual wages in natural logs";
{ b,g,f } = hist(meanc(wh'),100);
exec( "c:\\jesper~2\\gauss\\pqgrun.exe","Histgram -c=3 -cf=UsHi82a.hgl" );

/* ********************* End testing for normality. ********************** */
*/


/* ********************* GMM estimation. ********************************* */

/* Estimate w/h process:
     x(t) = z(t) + eps(t)
     z(t) = rho*z(t-1) + xsi(t)
   z = wage/hour
   x = observed 'z'
   eps = measurement error
   Estimate rho and var(xsi). Use GMM.
*/

n = rows(wh);
mn = meanc(wh);
nMC = 10;            /* # of moment conditions used */

  /* Initialize parameters */
theta = {0.94, 0.06, 0.03};
W = eye(nMC);

nIters = 7;
iter = 1;
Do While (iter <= nIters);

  /* Solve GMM */
  __title = "Minimize GMM Loss Function";
  _opgtol = 1E-5;
  _opparnm = "rho " | "s2x " | "s2e ";
  _opalgr = 2;
  /*_opstep = 1;*/
  _opgdmd = 1;
  _opgrdh = 1e-6;
  _grdh = 1e-6;
  _opgdprc = &_opgrad;
  {xx, ff, gg, rr} = optmum(&loss,theta);
  theta = xx;

  /* Update weighting matrix W */
  S = zeros(nMC,nMC);
  mc = momcond(wh,theta);
  i = 1;
  Do While i <= n;
    S = S + mc[i,.]' * mc[i,.] / n;
    i = i + 1;
  Endo;
  W = inv(S);

  iter = iter + 1;
Endo;

  /* Calculate std. errors of estimates */
  /* See Hamilton eqs. 14.2.5-14.2.7 */
D = gradcd(&h,theta);
V = inv(D' * W * D);
V = V / n;
se = sqrt(diag(V));

print "theta   std.err.";
print (theta ~ se);

/* Calculate test statistic for overidentifying assumptions. */

Chi_sq_stat = n * loss(theta);
"";print "Hansens Chi square statistic";
print Chi_sq_stat;

output off;

/******* END OF PROGRAM *******/


/* Calculate loss */
Proc loss(theta);
  local h;
  h = meanc(momcond(wh,theta));
  retp(h' * W * h);
Endp;

/* Calculate moments */
Proc h(theta);
  retp(meanc(momcond(wh,theta)));
Endp;

/* Calculate moment conditions used */
Proc momcond(wh,theta);

  local n,mom,mom_cond,rho,sigma2x,sigma2e;

  n = rows(wh);
  rho = theta[1];
  sigma2x = theta[2];
  sigma2e = theta[3];

mom = zeros(n,nMC);

  /* Variances */
  mom[.,1:4] = wh.^2;

  /* Covariances with D(x89) */
  mom[.,5:7] = wh[.,1] .* wh[.,2:4];

  /* Covariances with D(x90). */
  mom[.,8:9] = wh[.,2] .* wh[.,3:4];

  /* Covariances with D(x91). */
  mom[.,10] = wh[.,3] .* wh[.,4];



  mom_cond = zeros(n,nMC);

/* First 4 unconditional variance moments. */

  mom_cond[.,1] = mom[.,1] - 2 * sigma2x / ( 1 + rho ) - 2 * sigma2e ;
  mom_cond[.,2] = mom[.,2] - 2 * sigma2x / ( 1 + rho ) - 2 * sigma2e ;
  mom_cond[.,3] = mom[.,3] - 2 * sigma2x / ( 1 + rho ) - 2 * sigma2e ;
  mom_cond[.,4] = mom[.,4] - 2 * sigma2x / ( 1 + rho ) - 2 * sigma2e ;

/* Then 3 covariance moments for E[D(x(t+1))D(x(t))]. */

  mom_cond[.,5] = mom[.,5] - ( rho - 1 ) * sigma2x / ( 1 + rho ) + sigma2e ;
  mom_cond[.,6] = mom[.,8] - ( rho - 1 ) * sigma2x / ( 1 + rho ) + sigma2e ;
  mom_cond[.,7] = mom[.,10] - ( rho - 1 ) * sigma2x / ( 1 + rho ) + sigma2e ;

/* Then 2 covariance moments for E[D(x(t+2))D(x(t+1))]. */

  mom_cond[.,8] = mom[.,6] - rho * ( rho - 1 ) * sigma2x / ( 1 + rho ) ;
  mom_cond[.,9] = mom[.,9] - rho * ( rho - 1 ) * sigma2x / ( 1 + rho ) ;

/* Then 1 covariance moments for E[D(x(t+3))D(x(t))]. */

  mom_cond[.,10] = mom[.,7] - rho^2 * ( rho - 1 ) * sigma2x / ( 1 + rho ) ;

  retp(mom_cond);

Endp;


Proc _opgrad(x0);
    local f;

    f = &loss;
    retp(gradp(f,x0));
Endp;


