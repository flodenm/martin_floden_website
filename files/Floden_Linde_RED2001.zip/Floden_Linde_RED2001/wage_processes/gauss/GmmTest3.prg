new;

/* Estimate w/h process:
     x(t) = z(t) + eps(t)
     z(t) = rho*z(t-1) + xsi(t)
   z = wage/hour
   x = observed 'z'
   eps = measurement error
   Estimate rho and var(xsi). Use GMM.
*/

Library maxlik , /*nlsys,*/ optmum;
/*#include gradhess.prg;*/


  /* Load data calculated from PSID 1988-1992
     Col1 = 1988 etc. 1592 individuals observed. */
/*load wh[1592,5] = c:\jesper\gauss\wh.asc;*/

/* Generate data */

rho = 0.75;
sigme = sqrt(0.01);
sigmx = sqrt(0.05);
NN = 1592;
wh = zeros(NN,5);
xx = zeros(NN,1);
i = 2;
do while i <= 1005;
  xx = rho * xx + sigme * rndn(NN,1);
  if i > 1000;
    wh[.,i-1000] = xx + sigmx * rndn(NN,1);
  endif;
  i = i + 1;
endo;


/* Use diff. data */
wh = wh[.,2:5] - wh[.,1:4];

n = rows(wh);
mn = meanc(wh);
nMC = 10;            /* # of moment conditions used */

  /* Initialize parameters */
theta = {0.94, 0.06, 0.03};
W = eye(nMC);

nIters = 7;
iter = 1;
Do While (iter <= nIters);

  /* Solve GMM */
  __title = "Minimize GMM Loss Function";
  _opgtol = 1E-5;
  _opparnm = "rho " | "s2x " | "s2e ";
  _opalgr = 2;
  /*_opstep = 1;*/
  _opgdmd = 1;
  _opgrdh = 1e-6;
  _grdh = 1e-6;
  _opgdprc = &_opgrad;
  {xx, ff, gg, rr} = optmum(&loss,theta);
  theta = xx;

  /* Update weighting matrix W */
  S = zeros(nMC,nMC);
  mc = momcond(wh,theta);
  i = 1;
  Do While i <= n;
    S = S + mc[i,.]' * mc[i,.] / n;
    i = i + 1;
  Endo;
  W = inv(S);

  iter = iter + 1;
Endo;

  /* Calculate std. errors of estimates */
  /* See Hamilton eqs. 14.2.5-14.2.7 */
D = gradcd(&h,theta);
V = inv(D' * W * D);
V = V / n;
se = sqrt(diag(V));

print "theta   std.err.";
print (theta ~ se);

/* Calculate test statistic for overidentifying assumptions. */

Chi_sq_stat = n * loss(theta);
"";print "Hansens Chi square statistic";
print Chi_sq_stat;

output off;

/******* END OF PROGRAM *******/


/* Calculate loss */
Proc loss(theta);
  local h;
  h = meanc(momcond(wh,theta));
  retp(h' * W * h);
Endp;

/* Calculate moments */
Proc h(theta);
  retp(meanc(momcond(wh,theta)));
Endp;

/* Calculate moment conditions used */
Proc momcond(wh,theta);

  local n,mom,mom_cond,rho,sigma2x,sigma2e;

  n = rows(wh);
  rho = theta[1];
  sigma2x = theta[2];
  sigma2e = theta[3];

mom = zeros(n,nMC);

  /* Variances */
  mom[.,1:4] = wh.^2;

  /* Covariances with D(x89) */
  mom[.,5:7] = wh[.,1] .* wh[.,2:4];

  /* Covariances with D(x90). */
  mom[.,8:9] = wh[.,2] .* wh[.,3:4];

  /* Covariances with D(x91). */
  mom[.,10] = wh[.,3] .* wh[.,4];



  mom_cond = zeros(n,nMC);

/* First 4 unconditional variance moments. */

  mom_cond[.,1] = mom[.,1] - 2 * sigma2x / ( 1 + rho ) - 2 * sigma2e ;
  mom_cond[.,2] = mom[.,2] - 2 * sigma2x / ( 1 + rho ) - 2 * sigma2e ;
  mom_cond[.,3] = mom[.,3] - 2 * sigma2x / ( 1 + rho ) - 2 * sigma2e ;
  mom_cond[.,4] = mom[.,4] - 2 * sigma2x / ( 1 + rho ) - 2 * sigma2e ;

/* Then 3 covariance moments for E[D(x(t+1))D(x(t))]. */

  mom_cond[.,5] = mom[.,5] - ( rho - 1 ) * sigma2x / ( 1 + rho ) + sigma2e ;
  mom_cond[.,6] = mom[.,8] - ( rho - 1 ) * sigma2x / ( 1 + rho ) + sigma2e ;
  mom_cond[.,7] = mom[.,10] - ( rho - 1 ) * sigma2x / ( 1 + rho ) + sigma2e ;

/* Then 2 covariance moments for E[D(x(t+2))D(x(t+1))]. */

  mom_cond[.,8] = mom[.,6] - rho * ( rho - 1 ) * sigma2x / ( 1 + rho ) ;
  mom_cond[.,9] = mom[.,9] - rho * ( rho - 1 ) * sigma2x / ( 1 + rho ) ;

/* Then 1 covariance moments for E[D(x(t+3))D(x(t))]. */

  mom_cond[.,10] = mom[.,7] - rho^2 * ( rho - 1 ) * sigma2x / ( 1 + rho ) ;

  retp(mom_cond);

Endp;


Proc _opgrad(x0);
    local f;

    f = &loss;
    retp(gradp(f,x0));
Endp;


