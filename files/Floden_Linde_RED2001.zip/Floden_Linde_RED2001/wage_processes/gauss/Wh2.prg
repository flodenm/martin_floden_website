/* Estimate w/h process:
     x(t) = z(t) + eps(t)
     z(t) = rho*z(t-1) + xsi(t)
   z = wage/hour
   x = observed 'z'
   eps = measurement error
   Estimate rho and var(xsi). Use GMM.

   Same as Wh.prg but no moments for sigma2e.
*/

New;
Library maxlik, nlsys, optmum;
#include gradhess.prg;


  /* Load data calculated from PSID 1988-1992
     Col1 = 1988 etc. 1592 individuals observed. */
load wh[1592,5] = wh.asc;
n = rows(wh);
mn = meanc(wh);
wh = wh - meanc(mn);
nMC = 3;            /* # of moment conditions used */

  /* Initialize parameters */
theta = {0.94, 0.03};
W = eye(nMC);
/*load W;
load theta;*/

nIters = 7;
iter = 1;
Do While (iter <= nIters);

  /* Solve GMM */
  __title = "Minimize GMM Loss Function";
  _opgtol = 1E-5;
  _opparnm = "rho " | "s2x ";
  _opalgr = 2;
  /*_opstep = 1;*/
  _opgdmd = 1;
  _opgrdh = 1e-6;
  _grdh = 1e-6;
  _opgdprc = &_opgrad;
  {xx, ff, gg, rr} = optmum(&loss,theta);
  theta = xx;

  /* Update weighting matrix W */
  S = zeros(nMC,nMC);
  mc = momcond(wh,theta);
  i = 1;
  Do While i <= n;
    S = S + mc[i,.]' * mc[i,.] / n;
    i = i + 1;
  Endo;
  W = inv(S);

  iter = iter + 1;
Endo;

  /* Calculate std. errors of estimates */
  /* See Hamilton eqs. 14.2.5-14.2.7 */
D = gradcd(&h,theta);
V = inv(D' * W * D);
V = V / n;
se = sqrt(diag(V));

print "theta   std.err.";
print (theta ~ se);



/* Calculate loss */
Proc loss(theta);
  local h;
  h = meanc(momcond(wh,theta));
  retp(h' * W * h);
Endp;

/* Calculate moments */
Proc h(theta);
  retp(meanc(momcond(wh,theta)));
Endp;

/* Calculate moment conditions used */
Proc momcond(wh,theta);

  local n,mom,mom_cond,rho,sigma2x;

  n = rows(wh);
  rho = theta[1];
  sigma2x = theta[2];

  mom = zeros(n,4);

  /* Covariances with x1 */
  mom[.,1:4] = wh[.,1] .* wh[.,2:5];

  mom_cond = zeros(n,3);

  mom_cond[.,1] = mom[.,2] - rho * mom[.,1];
  mom_cond[.,2] = mom[.,3] - rho^4 * mom[.,1] - (rho + rho^3) * sigma2x;
  mom_cond[.,3] = mom[.,4] - rho^6 * mom[.,1] -
                  (rho + rho^3 + rho^5) * sigma2x;

  retp(mom_cond);

Endp;


Proc _opgrad(x0);
    local f;

    f = &loss;
    retp(gradient(f,x0,_opgrdh)');
Endp;
