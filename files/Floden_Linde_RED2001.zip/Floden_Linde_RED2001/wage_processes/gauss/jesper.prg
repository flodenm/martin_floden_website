/* Doing some testing stuff. */

New;

output file = c:\jesper\gauss\gmmtest.out reset;

/* ************* First I do some datatransformations. ******************* */

load data[] = c:\jesper\gauss\jdata.asc;
data = reshape( data,rows(data)/11,11 );

age = data[.,2];
dprivat = data[.,4];
db23y = data[.,6];
db36y = data[.,7];
dmt6y = data[.,8];
wh89 = data[.,9];
wh90 = data[.,10];
wh92 = data[.,11];

BigX = age~dprivat~db23y~db36y~dmt6y;

{ var1, var2, beta_hat, var3, var4, var5, var6, var7, var8, var9, var10 } =
OLS(0,wh89,BigX);

BigX = ones(rows(BigX),1)~BigX;

/* Extracting out the idiosyncratic part. */

wh89 = wh89 - BigX*beta_hat;
wh90 = wh90 - BigX*beta_hat;
wh92 = wh92 - BigX*beta_hat;

/* To get starting values for the GMM-estimation below. */

{ var1, var2, beta_hat, var3, var4, var5, var6, var7, var8, var9, var10 } =
OLS(0,wh90,wh89);

wh = wh89~wh90~wh92;
wh = wh - meanc(wh)';

@clear data;@

/* **************** End data transformations. *************************** */



/* Do not use this now! If one uses namn_sni8992.txt; then use this!!!
load data[] = c:\jesper\hink\hhsni.txt;
data = reshape( data,rows(data)/13,13 );
age = data[.,2];
dpind = data[.,3];
dbygg = data[.,4];
daff = data[.,5];
dkomm = data[.,6];
db23y = data[.,9];
db36y = data[.,10];
dmt6y = data[.,11];
wh87 = data[.,12];
wh88 = data[.,13];
BigX = age~dpind~dbygg~daff~dkomm~db23y~db36y~dmt6y;
{ vnam, m, b, stb, vc, stderr, sigma, cx, rsq, resid, dwstat } =
OLS(0,wh87,BigX);
BigX = ones(rows(BigX),1)~BigX;
wh87 = wh87 - BigX*b;
wh88 = wh88 - BigX*b;
{ vnam, m, b, stb, vc, stderr, sigma, cx, rsq, resid, dwstat } =
OLS(0,wh88,wh87);
clear data;
*/



/* Estimate w/h process:
     x(t) = z(t) + eps(t)
     z(t) = rho*z(t-1) + xsi(t)
   z = wage/hour
   x = observed 'z'
   eps = measurement error
   Estimate rho and var(xsi). Use GMM.
*/


Library maxlik, optmum;
#include gradhess.prg;

n = rows(wh);
mn = meanc(wh);
wh = wh - meanc(mn);

nMC = 4;            /* # of moment conditions used */

  /* Initialize parameters */
theta = {1.0, 0.01, 0.01};
W = eye(nMC);
/* load W;
load theta; */

nIters = 14;
iter = 1;
Do While (iter <= nIters);

  /* Solve GMM */
  __title = "Minimize GMM Loss Function";
  _opgtol = 1E-5;
  _opparnm = "rho " | "s2x " | "s2e ";
  _opalgr = 2;
  /*_opstep = 1;*/
  _opgdmd = 1;
  _opgrdh = 1e-4;
  _grdh = 1e-4;
  _opgdprc = &_opgrad;
  {xx, ff, gg, rr} = optmum(&loss,theta);
  theta = xx;

  /* Update weighting matrix W */
  S = zeros(nMC,nMC);
  mc = momcond(wh,theta);
  i = 1;
  Do While i <= n;
    S = S + mc[i,.]' * mc[i,.] / n;
    i = i + 1;
  Endo;
  W = inv(S);

  iter = iter + 1;
Endo;

  /* Calculate std. errors of estimates */
  /* See Hamilton eqs. 14.2.5-14.2.7 */
D = gradcd(&h,theta);
V = inv(D' * W * D);
V = V / n;
se = sqrt(diag(V));

print "theta   std.err.";
print (theta ~ se);


output off;

/******* END OF PROGRAM *******/


/* Calculate loss */
Proc loss(theta);
  local h;
  h = meanc(momcond(wh,theta));
  retp(h' * W * h);
Endp;

/* Calculate moments */
Proc h(theta);
  retp(meanc(momcond(wh,theta)));
Endp;

/* Calculate moment conditions used */
Proc momcond(wh,theta);

  local n,mom,mom_cond,rho,sigma2x,sigma2e;

  n = rows(wh);
  rho = theta[1];
  sigma2x = theta[2];
  sigma2e = theta[3];

/* Use this if only 4 moments are to be used - give higher variance. */
  mom = zeros(n,5); /* No of obs x no of variances plus covariances. */

  /* Variances. */
  mom[.,1:3] = wh.^2;

  /* Covariances with x1. */
  mom[.,4:5] = wh[.,1] .* wh[.,2:3];

/*
  mom = zeros(n,6); /* No of obs x no of variances plus covariances. */

  /* Variances. */
  mom[.,1:3] = wh.^2;

  /* Covariances with x1. */
  mom[.,4:5] = wh[.,1] .* wh[.,2:3];

  /* Covariances x2 and x3. */
  mom[.,6] = wh[.,2] .* wh[.,3];
*/
  mom_cond = zeros(n,nMC); /* nMC = no of moment conditions. */

/* First 3 moments which are the same as for the US. */

  mom_cond[.,1] = mom[.,2] - rho^2 * mom[.,1] - sigma2x -
                    (1 - rho^2) * sigma2e;
  mom_cond[.,2] = mom[.,3] - rho^6 * mom[.,1] -
                  (1 + rho^2 + rho^4) * sigma2x - (1 - rho^6) * sigma2e;
  mom_cond[.,3] = mom[.,4] - rho * (mom[.,1] - sigma2e);

/* Then 2 Sweden specific moments. */

mom_cond[.,4] = mom[.,5] - rho^3 * (mom[.,1] + (rho-1)*sigma2x - sigma2e);
/*
  mom_cond[.,5] = mom[.,6] - rho^4 * mom[.,1] -
                  rho^2 * (sigma2x - rho^2*sigma2e);
*/
  retp(mom_cond);

Endp;


Proc _opgrad(x0);
    local f;

    f = &loss;
    retp(gradient(f,x0,1e-4)');
Endp;


