/* Part 2 of PSID data manipulation.
   Generate series for hours worked and wage per hour. */

libname outdir 'c:\jesper\psid\';
libname indir 'c:\jesper\psid\';

data outdir.psid(rename=(V15162=OCC V30573=AGE V30584=EDUC));
set indir.fam_ind;


/* ======== GENERATE NEW VARIABLES ======== */

/* Hours in labor force (working, ill, unemployed): */
H88 = V14835 + V14836 + V14838 + V14842;
H89 = V16335 + V16336 + V16338 + V16342;
H90 = V17744 + V17745 + V17747 + V17751;
H91 = V19044 + V19045 + V19047 + V19051;
H92 = V20344 + V20345 + V20347 + V20351;

/* Remove unreasonable and missing values */
/* Also, only include those who have been in the labor force at least 1000h / year: */

if H88 >= 1000 and H89 >= 1000 and H90 >= 1000 and H91 >= 1000 and H92 >= 1000 and
   H88 < 5000 and H89 < 5000 and H90 < 5000 and H91 < 5000 and H92 < 5000;


/* Wages */
W88 = V14913 + V14915 + V14911 + V14912 + V14916 + V14917 + V14918;
W89 = V16413 + V16415 + V16411 + V16412 + V16416 + V16417 + V16418;
W90 = V17829 + V17831 + V17827 + V17828 + V17832 + V17833 + V17834;
W91 = V19129 + V19131 + V19127 + V19128 + V19132 + V19133 + V19134;
W92 = V20429 + V20431 + V20427 + V20428 + V20432 + V20433 + V20434;

/* Wage per hour */
WH88 = W88 / H88;
WH89 = W89 / H89;
WH90 = W90 / H90;
WH91 = W91 / H91;
WH92 = W92 / H92;

/* Remove all year effects in wage/hour */
/* Put wage per hour with year effects removed in WHyyN */
lnWH88=WH88; lnWH89=WH89; lnWH90=WH90; lnWH91=WH91; lnWH92=WH92;
run;

proc iml;
edit outdir.psid var{lnWH88 lnWH89 lnWH90 lnWH91 lnWH92};
read all var{lnWH88 lnWH89 lnWH90 lnWH91 lnWH92};

lnWH88 = lnWH88/(sum(lnWH88)/nrow(lnWH88));
lnWH89 = lnWH89/(sum(lnWH89)/nrow(lnWH89));
lnWH90 = lnWH90/(sum(lnWH90)/nrow(lnWH90));
lnWH91 = lnWH91/(sum(lnWH91)/nrow(lnWH91));
lnWH92 = lnWH92/(sum(lnWH92)/nrow(lnWH92));

lnWH88 = lnWH88 <> 0.10;
lnWH89 = lnWH89 <> 0.10;
lnWH90 = lnWH90 <> 0.10;
lnWH91 = lnWH91 <> 0.10;
lnWH92 = lnWH92 <> 0.10;

lnWH88 = log(lnWH88);
lnWH89 = log(lnWH89);
lnWH90 = log(lnWH90);
lnWH91 = log(lnWH91);
lnWH92 = log(lnWH92);

replace all var{lnWH88 lnWH89 lnWH90 lnWH91 lnWH92};

close outdir.psid;

quit;
