/* Part 3 of program.
   Estimate and remove predictable part of wage per hour.
*/

libname outdir 'c:\jesper\psid\';
libname indir 'c:\jesper\psid\';

data outdir.psid2(compress=no);
set indir.psid;

AGE2 = AGE**2;

OCC1 = ((OCC >= 1) and (OCC <= 195));
label OCC1 = "Prof., Techn. Workers";
OCC2 = ((OCC >= 201) and (OCC <= 245));
label OCC2 = "Managers";
OCC3 = ((OCC >= 260) and (OCC <= 285));
label OCC3 = "Sales workers";
OCC4 = ((OCC >= 301) and (OCC <= 395));
label OCC4 = "Clerical workers";
OCC5 = ((OCC >= 401) and (OCC <= 600));
label OCC5 = "Craftsmen";
OCC6 = ((OCC >= 601) and (OCC <= 715));
label OCC6 = "Operatives";
OCC7 = ((OCC >= 801) and (OCC <= 824));
label OCC7 = "Farmers, Farm laborers";
OCC8 = ((OCC >= 901) and (OCC <= 984));
label OCC8 = "Service workers";
OCC9 = 1 - (OCC1+OCC2+OCC3+OCC4+OCC5+OCC6+OCC7+OCC8);
label OCC9 = "Other";
run;

/* Estimate */
proc syslin simple ols data=indir.psid2 out=indir.psid2;
     model lnWH88=AGE AGE2 EDUC OCC1 OCC2 OCC3 OCC4 OCC5 OCC6 OCC7 OCC8;
     output predicted=PRE_1;
run;


/* Remove the part of w/h which is predicted by these factors: */

data outdir.psid2(compress=no);
set indir.psid2;

Z88 = lnWH88 - PRE_1;
Z89 = lnWH89 - PRE_1;
Z90 = lnWH90 - PRE_1;
Z91 = lnWH91 - PRE_1;
Z92 = lnWH92 - PRE_1;

label Z88 = "Log wage per hour, adjusted, 1988"
      Z89 = "Log wage per hour, adjusted, 1989"
      Z90 = "Log wage per hour, adjusted, 1990"
      Z91 = "Log wage per hour, adjusted, 1991"
      Z92 = "Log wage per hour, adjusted, 1992";

if (z88+z89+z90+z91+z92) ^= .;


/* Produce ASCII file with Zyy */
filename fileref 'c:\jesper\psid\wh.asc';
file fileref;
put @1 Z88 @15 Z89 @30 Z90 @45 Z91 @60 Z92;

run;
