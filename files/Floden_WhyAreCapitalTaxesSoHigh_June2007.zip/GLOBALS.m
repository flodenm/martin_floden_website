global delta theta mu gmma bta zeta tauC Dss
