Matlab code to solve basic optimal taxation experiments in
"Why Are Capital Income Taxes So High?"
by Martin Floden, June 2007
martin.floden@hhs.se
Stockholm School of Economics

The following files are included in this package:

main.m        This is the main script, calling other scripts
              Change OPTIMIZED_A0 to find optimal policy for other agents

solve_ss.m    Finds the parameter zeta in the utility function so that
              h = 1/3 in the initial steady state
              
optimal_tax.m Solves for the Ramsey optimal tax policy when tauK(t) is 
              constrained to be lower than tauKss for NRESTRICT>0 periods

optimal_tax_unconstr.m 
              Solves for the Ramsey optimal tax policy when tauK(t) is
              unconstrained in all periods (not used in the paper)

solve_agents_bc.m
              Used to find the implied consumption paths for all households
              after the optimal policy was found

value.m       Used to calculate welfare implications

GLOBALS.m     Loads global variables

csolve.m      An equation solver written by Chris Sims

fGini.m       Calculates gini coefficient

distributions.mat
              File with wealth and productivity distribution

utilfcn_GHH/U.m
              The utility function
           /Uxx.m
              Derivatives of the utility function with respect to 
              consumption (1) and labor (2)

 
