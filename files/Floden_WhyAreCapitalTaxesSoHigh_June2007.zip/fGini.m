function g = fGini(F,X)

A1 = 0.5;

if X(1) ~= 0 | F(1) ~= 0; fprintf(1,'Warning: first elements in F and X must be zero'); end
A = 0;
for i = 2:length(F)
    A = A + (F(i)-F(i-1))*(X(i)+X(i-1))/2;
end

g = (A1 - A)/A1;