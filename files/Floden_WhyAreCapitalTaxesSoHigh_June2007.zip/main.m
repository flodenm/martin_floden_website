clear all

GLOBALS

% ===============================================================================
% User changes allowed here!
% --------------------------
OPTIMIZED_A0     = 1;                % initial wealth of optimized agent relative to average wealtH
LOADSOLUTION     = 0;
SAVESOLUTION     = 0;
NRESTRICT        = 1;                % # periods with tauK restricted to tauKss
ZEROTAX          = 0;                % Remove capital income tax immediately?
NONEGATIVEWEALTH = 0;                % Rule out negative wealth positions?
% ===============================================================================

% Program specifications
T        = 300;                      % length of transition (# of years)

addpath utilfcn_ghh
load distributions

if NONEGATIVEWEALTH
i         = find(wealth<0);
wealth(i) = 0;
w         = sum(wealth.*mass);
wealth    = wealth./w;
clear w i
end



% Preferences
mu       = 2;
gmma     = 0.5;

productivity = earnings.^(1/(1+gmma));
Z            = sum(productivity.^(1+gmma) .* mass).^(1/(1+gmma));


% Production, prices, population and initial conditions
delta    = .10;
theta    = .40;
Hss      = 1/3;
KYss     = 3.0;
zfrac    = 1;
afracss  = OPTIMIZED_A0;            
z        = zfrac*Z;            % productivity of optimized agent relative to representative agent
D0       = 0.6;             % initial gvt debt, frac of gdp

% Initial policy
tauKss   = 0.311;
tauHss   = 0.226;
tauCss   = 0.061;

tauC     = tauCss;

% Restrictions on new tax policy
TAUKTARGET = tauKss*ones(NRESTRICT,1); STOPTAX=0;
if ZEROTAX
    TAUKTARGET = 0*ones(T,1); STOPTAX=0;
end


% Initial ss
Lss    = Z * Hss;                               % labor supply in efficiency units
Yss    = KYss^(theta/(1-theta)) * Lss;
Kss    = KYss * Yss;
FKss   = theta/KYss;
wss    = (1-theta) * Yss / Lss;                 % wage per efficiency unit of labor
Rss    = 1 + (1-tauKss) * (FKss - delta);
bta    = 1 / Rss;
Dss    = D0 * Yss;
Ass    = Kss + Dss;
ass    = afracss * Ass;
Css    = ((Rss-1)*Ass + (1-tauHss) * wss * Lss) / (1+tauCss);
Gss    = Yss - delta*Kss - Css;
[zeta,f]   = fzero('solve_ss',10,optimset('TolFun',1e-12,'Display','notify'),Css,Hss,(1-tauHss)*Z*wss,tauCss);
fprintf(1,'zeta = %10.6f, f = %10.8f\n',zeta,f);


% Solve for optimal tax
Cguess = Css * ones(T,1);
Hguess = Hss * ones(T,1);
Kguess = Kss * ones(T,1);
nu     = U1(Css,Hss) * ones(T,1);
rho    = 0*bta.^(1:T)';
xsi    = 0*bta.^(1:T)';
lambda = 0.3;

qq       = zfrac^(1/(1+gmma));
x        = [zfrac*Cguess; Cguess; z^gmma*Hguess; Hguess; Kguess; nu*zfrac; rho/zfrac; xsi/qq; lambda; lambda];
x(1:5*T) = log(x(1:5*T));

if isempty(TAUKTARGET)
    t = 0;
else
    t = length(TAUKTARGET)-1;
end


if LOADSOLUTION
    sol = load('x');
    if size(sol.x) == size(x)
        x = sol.x;
    else
        warning('Loadsolution only implemented for saved solution.T = T')
    end
end
    

% ==========================
% FIND RAMSEY OPTIMAL POLICY
% ==========================
if isempty(TAUKTARGET)
    x   = [x; -0.9];
    x   = csolve('optimal_tax_unconstr',x,[],1e-9,25,T,ass,Ass,z,Z,Gss);
else
    x    = [x; ones(t,1)];
    x    = csolve('optimal_tax',x,[],1e-9,25,T,ass,Ass,z,Z,Gss,TAUKTARGET);
end


y         = x;
y(1:5*T)  = exp(y(1:5*T));
c         = y(1:T);
C         = y(T+1:2*T);
h         = y(2*T+1:3*T);
H         = y(3*T+1:4*T);
nextK     = y(4*T+1:5*T);
nu        = y(5*T+1:6*T);
rho       = y(6*T+1:7*T);
xsi       = y(7*T+1:8*T);
lambda    = y(8*T+1);
Lambda    = y(8*T+2);

L       = Z*H;    
K       = [Kss; nextK(1:end-1,:)];
V1      = U1(C,H);
V2      = U2(C,H);
Y       = K.^theta .* L.^(1-theta);
FK      = theta * Y./K;
FL      = (1-theta) * Y./L;

if isempty(TAUKTARGET)
    R0    = y(8*T+3);
    tauK0 = 1 + (1-R0) ./ (FK(1,:)-delta);
else
    tauK0 = TAUKTARGET(1);
end
tauH    = 1 + (1+tauC)*V2./(Z*FL.*V1);
R       = V1(1:end-1) ./ (bta*V1(2:end));
tauK    = [tauK0; 1+(1-R)./(FK(2:end)-delta)];
R       = 1 + (1-tauK) .* (FK - delta);

if STOPTAX, close all, plot(tauK), break, end

% Welfare
V   = value(C,H,bta);
Vss = value(Css,Hss,bta);

v   = value(c,h,bta); 
hss = (z/Z).^gmma * Hss;
css = ((1-tauHss)*wss*z*hss + (Rss-1)*ass) / (1+tauCss);
vss = value(css,hss,bta);

fprintf(1,'Finding consumption path for all agents in the distribution...\n')
nAg    = length(wealth);
allH   = H * (productivity'/Z).^gmma;
allHss = (productivity'/Z).^gmma * Hss;
allCss = ((1-tauHss)*wss*productivity'.*allHss + (Rss-1)*wealth'*Ass) / (1+tauCss);
opt    = optimset('Display','notify','JacobPattern',sparse(eye(nAg)),...
                  'TolX',1e-10,'TolFun',1e-10);
logc0  = fsolve(@solve_agents_bc,log(allCss),opt,allH,R,Ass*wealth');
f0     = solve_agents_bc(logc0,allH,R,Ass*wealth');
f0(2)  = 0;
if max(abs(f0)>1e-8), warning('Did not solve consumption paths'); end

% agent #2 is difficult to solve for: solve separately:
logc2    = fzero(@solve_agents_bc,log(allCss(2))-0.1,optimset('Display','off','TolX',1e-16,'TolFun',1e-16),allH(:,2),R,Ass*wealth(2)');
logc0(2) = logc2;
f2       = solve_agents_bc(logc2,allH(:,2),R,Ass*wealth(2)');
if abs(f2)>5e-8, warning('Did not solve consumption path for hh #2'); end

% implied consumption
allC    = [exp(logc0); zeros(T-1,nAg)];
v1      = zeros(T,nAg);
v1(1,:) = U1(allC(1,:),allH(1,:));
for i = 2:T
    allC(i,:) = zeta*allH(i,:).^(1+1/gmma)/(1+1/gmma) + (bta*R(i,:)./v1(i-1,:)).^(1/mu);
    v1(i,:) = U1(allC(i,:),allH(i,:));
end
clear v1

% test implied foc
foc    = zeros(T-1,nAg);
for t = 1:T-1
  foc(t,:) = bta*U1(allC(t+1,:),allH(t+1,:))./U1(allC(t,:),allH(t,:)) - 1./R(t+1);
end
if max(abs(foc(:)))>1e-10
    warning('Bad solution. FOC not satisfied!')
end


% implied assets
D         = zeros(T+1,1); 
A         = zeros(T+1,1);
a         = zeros(T+1,1);
allA      = zeros(T+1,nAg);
D(1)      = Dss;
A(1)      = Ass;
a(1)      = Ass*afracss;
allA(1,:) = Ass*wealth';
for t = 1:T
    D(t+1)      = R(t)*D(t) + Gss - tauK(t)*(FK(t)-delta)*K(t) - tauH(t)*FL(t)*L(t) - tauC*C(t);
    A(t+1)      = R(t)*A(t) - (1+tauC)*C(t) + (1-tauH(t))*FL(t)*L(t);
    a(t+1)      = R(t)*a(t) - (1+tauC)*c(t) + (1-tauH(t))*FL(t)*z*h(t);  
    allA(t+1,:) = R(t)*allA(t,:) + (1-tauH(t))*FL(t)*productivity'.*allH(t,:) - (1+tauC)*allC(t,:);
end
if max(abs(allA(end,:)-allA(end-1,:)))>1
    warning('Did not find implied consumption paths for all households!!!')
    ifail = find((abs(allA(end,:)-allA(end-1,:)))>1);
    fprintf('Failed solving for household #: \n')
    ifail
end

allV   = value(allC,allH,bta);
allVss = value(allCss,allHss,bta);


% Welfare gain: Solve U(x*Css,Hss)/U(Css,Hss) = V/Vss
fprintf(1,'Calculating welfare gains...\n')
allUss = U(allCss,allHss);
allWG  = zeta*allHss.^(1+1/gmma)/(1+1/gmma)./allCss + ((1-mu)*allUss.*allV./allVss).^(1/(1-mu)) ./allCss;
WG     = zeta*Hss.^(1+1/gmma)/(1+1/gmma)./Css + ((1-mu)*U(Css,Hss).*V./Vss).^(1/(1-mu)) ./Css;
wg     = zeta*hss.^(1+1/gmma)/(1+1/gmma)./css + ((1-mu)*U(css,hss).*v./vss).^(1/(1-mu)) ./css;
[xwgUti,F1] = fzero('(U(exp(x)*P1,P2)*P4)/(U(P1,P2)*P4)-P3',1,opt,allCss,allHss,(allV*mass)/(allVss*mass),mass);
wgUti       = exp(xwgUti);
if max(abs(F1)) > 1e-10
    fprintf(1,'Warning: Did not solve welfare gains!!!\n')
end


iWorker    = find((wealth <= min(wealth)+1e-12));
[tmp,itmp] = min(productivity(iWorker));         % Note: not clear whom to choose here...
iWorker    = iWorker(itmp);

we_ratio   = wealth./(productivity.^(1+gmma));
[tmp,iCap] = max(we_ratio);

% Find median voter
[sortWE,iSortWE] = sort(we_ratio);
cumMass          = cumsum(mass(iSortWE));
[tmp,iMedianWE]  = min(abs(cumMass-0.5));
iMedianWE        = iSortWE(iMedianWE);

[sortWG,iSort] = sort(allWG);
cumMass        = cumsum(mass(iSort));
iMedian        = sum(cumMass<0.5);
iGain          = find(allWG>1);
fracGain       = sum(mass(iGain));

fprintf(1,'=====================================================\n')
fprintf(1,'Optimized agent:\nWealth/Mean       = %10.6f\nProductivity/Mean = %10.6f\n',afracss,z/Z)
fprintf(1,'\nWelfare gain of optimal tax reform:\nRepr agent     = %8.4f%%\nWorker         = %8.4f%%\nCapitalist     = %8.4f%%\n',...
    100*(WG-1),100*(allWG(iWorker)-1),100*(allWG(iCap)-1))
fprintf(1,'Median welfare = %8.4f%%\nOptimized      = %8.4f%%\n',...
    100*(sortWG(iMedian)-1),100*(wg-1))
fprintf(1,'Median voter   = %8.4f%%   (a0/z^(1+gamma) = %8.4f)\n',...
    100*(allWG(iMedianWE)-1),we_ratio(iMedianWE))
fprintf(1,'Utilitarian    = %8.4f%%\n',100*(wgUti-1))
fprintf(1,'%% gaining      = %8.4f%%\n',100*fracGain); 


[sortWss,iSort] = sort(wealth);
cumMassW        = cumsum(mass(iSort));
giniWss         = fGini([0; cumMassW],[0; cumsum(wealth(iSort).*mass(iSort))/sum(wealth.*mass)]);
[sortW,iSort]   = sort(allA(end,:)');
cumMassW        = cumsum(mass(iSort));
giniW           = fGini([0; cumMassW],[0; cumsum(allA(end,iSort)'.*mass(iSort))/sum(allA(end,:)'.*mass)]);

[sortE,iSort]   = sort(productivity);
cumMassE        = cumsum(mass(iSort));
giniE           = fGini([0; cumMassE],[0; cumsum(productivity(iSort).*allHss(iSort)'.*mass(iSort))/sum(productivity.*allHss'.*mass)]);


fprintf(1,'Initial wealth gini = %8.4f\nFinal wealth gini   = %8.4f\nEarnings gini       = %8.4f\n',giniWss,giniW,giniE)


fprintf(1,'\nChange in (%%):\nK = %8.1f\nL = %8.1f\nC = %8.1f\n',100*(K(end)/Kss-1),100*(L(end)/Lss-1),100*(C(end)/Css-1))
fprintf(1,'\nValues (%%):\nD/Y(end)  = %8.1f\ntauK(1)   = %8.1f\ntauH(end) = %8.1f\n',100*D(end-1)/Y(end),100*tauK(2),100*tauH(end))

figure
ii=find(allWG>1);
jj=find(allWG<1);
plot(wealth(ii),productivity(ii),'b+','MarkerSize',6)
hold on
plot(wealth(jj),productivity(jj),'ro','MarkerSize',6)
axis([-0.3 11 0 4.5])
xlabel('initial wealth')
ylabel('productivity')
title('Distribution of winners (+) and losers (o)')

figure
plot(tauK)

if SAVESOLUTION;
    save x T t x
end
