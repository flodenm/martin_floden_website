function f = solve_agents_bc(x,h,R,a0);
% Code assumes constant tauC, and GHH utility

global delta theta mu gmma bta zeta tauC Dss

[T,N]   = size(h);
c0      = min(1e5,exp(x));

% implied consumption
c       = [c0; zeros(T-1,N)];
v1      = zeros(T,N);
v1(1,:) = U1(c0,h(1,:));
for i = 2:T
    c(i,:) = zeta*h(i,:).^(1+1/gmma)/(1+1/gmma) + (bta*R(i,:)./v1(i-1,:)).^(1/mu);
    v1(i,:) = U1(c(i,:),h(i,:));
end

ic     = ((bta.^(0:T-1)')*ones(1,N)) .* (U1(c,h).*c + U2(c,h).*h);
f      = sum(ic) + bta*ic(end,:)/(1-bta) - U1(c(1,:),h(1,:)).*R(1).*a0/(1+tauC);


