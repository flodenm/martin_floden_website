function y = solve_ss(z,c,h,w,tauCss);

global mu gmma zeta

zeta = z;
y    = w*U1(c,h) + (1+tauCss)*U2(c,h);

  