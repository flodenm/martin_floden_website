function x = U(c,h);

global mu gmma zeta

x = (c - zeta*h.^(1+1/gmma)/(1+1/gmma)).^(1-mu) / (1-mu);