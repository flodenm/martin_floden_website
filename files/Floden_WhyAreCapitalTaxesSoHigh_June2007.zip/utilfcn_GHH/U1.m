function x = U1(c,h);

global mu gmma zeta

x = (c - zeta*h.^(1+1/gmma)/(1+1/gmma)).^(-mu);