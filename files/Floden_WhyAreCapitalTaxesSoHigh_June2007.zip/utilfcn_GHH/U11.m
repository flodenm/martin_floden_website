function x = U11(c,h);

global mu gmma zeta

x = -mu * (c - zeta*h.^(1+1/gmma)/(1+1/gmma)).^(-mu-1);