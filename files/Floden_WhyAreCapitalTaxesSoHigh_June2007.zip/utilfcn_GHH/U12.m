function x = U12(c,h);

global mu gmma zeta

x = zeta * mu * h.^(1/gmma) .* (c - zeta*h.^(1+1/gmma)/(1+1/gmma)).^(-mu-1);