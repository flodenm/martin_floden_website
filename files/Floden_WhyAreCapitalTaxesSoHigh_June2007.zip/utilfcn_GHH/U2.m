function x = U2(c,h);

global mu gmma zeta

x = -zeta * h.^(1/gmma) .* (c - zeta*h.^(1+1/gmma)/(1+1/gmma)).^(-mu);