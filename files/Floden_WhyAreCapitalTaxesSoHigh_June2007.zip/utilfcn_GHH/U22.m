function x = U22(c,h);

global mu gmma zeta

x = -mu * (zeta * h.^(1/gmma)).^2 .* (c - zeta*h.^(1+1/gmma)/(1+1/gmma)).^(-mu-1) + ...
    -(zeta/gmma) * h.^(1/gmma-1) .* (c - zeta*h.^(1+1/gmma)/(1+1/gmma)).^(-mu);