function V = value(c,h,bta)

T   = size(c,1);
N   = size(c,2);
v   = (bta.^(0:T-1)'*ones(1,N)) .* U(c,h);
if T > 1
    V   = sum(v) + bta*v(end,:)/(1-bta);
else
    V   = v + bta*v(end,:)/(1-bta);
end