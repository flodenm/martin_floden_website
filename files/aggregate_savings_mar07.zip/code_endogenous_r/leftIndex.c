 /*=================================================================
 *
 * LEFTINDEX.C
 * The calling syntax is:
 *
 *		[I,W] = leftIndex(X,Y)
 *
 * X is an 1*nX vector
 * Y is an 1*nY vector
 * I is an 1*nX vector with left indicies to x in y, 1 <= I < nY
 * W is the weight on the left node -inf < W < inf
 * ... but 0 <= W <= 1 if 2 <= nY <= nY-2
 * Note: I must be sorted
 *=================================================================*/

#include "mex.h"
#include <stdio.h>


/* Output Arguments */
#define	I_OUT	plhs[0]
#define	W_OUT	plhs[1]


/*=================================================================
 *  function GET_INDEX
 *  i = get_index(x,Y,nY)
 * 
 *  input   x   = scalar
 *          y   = 1*nY vector
 *  output  i   = index for x in Y, 1 <= ind < nY
 */
static int get_index(
           double   x,
           double	Y[],
           int      nY
		   )
{
    int     i;
    
    for (i = 0; i < nY; i++) {
        if (x < Y[i]) break;
    }
    if (i == 0) i = 1;
    else if (i == nY) i = nY - 1;
    
    return i;
}


void mexFunction( int nlhs, mxArray *plhs[], 
		  int nrhs, const mxArray *prhs[] )
{     
    double *X,*Y,*I,*W;
    int    nX,nY;
    int    i,ind;
    
    /* Check for proper number of arguments */    
    if (nrhs != 2) { 
	mexErrMsgTxt("Two input arguments required."); 
    } else if (nlhs > 2) {
	mexErrMsgTxt("Too many output arguments."); 
    } 
   
       
    /* Assign pointers to the various parameters */ 
    X   = mxGetPr(prhs[0]);   
    Y   = mxGetPr(prhs[1]);       
    nX  = mxGetN(prhs[0]);
    nY  = mxGetN(prhs[1]);

    /* Create a matrix for the return argument */ 
    I_OUT = mxCreateDoubleMatrix(1, nX, mxREAL); 
    W_OUT = mxCreateDoubleMatrix(1, nX, mxREAL); 
    I     = mxGetPr(I_OUT);
    W     = mxGetPr(W_OUT);
                  
    for (i = 0; i < nX; i++) {
        ind  = get_index(X[i],Y,nY);
        I[i] = ind;
        W[i] = 1 - (X[i] - Y[ind-1]) / (Y[ind] - Y[ind-1]);
    }
    
    return;
    
}


