 /*=================================================================
 *
 * LIFE_CYCLE_BR.C
 * The calling syntax is:
 *
 *		[a,c,i] = life_cycle_equilibrium(y,R,beta,gamma)
 *
 * assumes CRRA utility, gamma = risk aversion
 *
 *=================================================================*/

#include "mex.h"
#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <math.h>


/* Output Arguments */
#define	A_OUT	plhs[0]
#define	C_OUT	plhs[1]
#define	I_OUT	plhs[2]

/* Program Settings */
#define HORIZON     700
#define UPDATE_NPV   70
#define UPDATE_C     50
#define EPS        1E-6

/*=================================================================
 *  function NPV 
 *  f = npv(T,nT,y,disc,R,ind)
 * 
 *  input   T   = length of y
 *          nT  = # periods to use
 *          ind = index to first period in y
 *  output  f   = npv of y discounted at disc and R
 */
static double npv(
           int      T,
           int      nT,
           double	y[],
 		   double	disc[],
 		   double	R,
           int      ind
		   )
{
    int     i,j,n;
    double  thisNPV;

    if (nT < HORIZON) n = nT; else n = HORIZON;

    thisNPV = 0;
    i       = ind;
    for (j = 0; j < n; j++) {
        thisNPV = thisNPV + disc[j] * y[i];
        if (++i == T) i = 0;
    }

    return thisNPV;
}



/*=================================================================
 *  function max_NPV 
 *  f = max_NPV(T,y,disc,R,ind)
 * 
 *  input   T  = # periods
 *  output  f   = npv of y discounted at disc and R
 *          ind = pointer to index to time period with highest npv
 */
static int max_npv(
           int      T,
		   double	y[],
		   double	disc[],
 		   double	R
		   )
{
    int     t,iMaxNPV;
    double  maxVal,thisNPV,f;

    maxVal  = 0;
    iMaxNPV = 0;
    f       = pow(R,-(T-1));
    
    for (t = 0; t < T; t++) {
        
        /* recalculate npv occasionally to increase precision */
        if (t % UPDATE_NPV == 0)
            thisNPV = npv(T,T,y,disc,R,t);
        else
            thisNPV = R*(thisNPV-y[t-1]) + f*y[t-1];
            
        if (thisNPV > maxVal) {
            maxVal = thisNPV;
            iMaxNPV = t;
        }
    }


    return iMaxNPV;
}



/*=================================================================
 *  function PARTIAL_ASSET_PATH
 *  partial_asset_path(T,nT,y,ind,disc,R,x,a,c,negA)
 *
 *  output: a      nT+1 vector
 *          c      nT   vector
 *          negA   scalar, indicates that some a<0
 *
 *  Calculate consumption and asset path for subpath where constraint
 *  does not bind.
 */
static void partial_asset_path(
           int     T,
           int     nT,
		   double  y[],
           int     ind,
           double  disc[],
           double  R,
           double  x,
           double  *a,
           double  *c,
           int     *negA
  		   )
{
    int      i,j,k;
    double   r;
       
    k = ind+1;
    if (k == T) k = 0;
    *negA = 0;
   
    for (j = 0; j < nT; j++) {
        
        if (k > 0) i = k-1;
        else i = T-1;

        if (j % UPDATE_C == 0) {
            r  = (1-x/R) / (1-pow(x/R,nT-j));
            c[j] = r * (R*a[j] + npv(T,nT-j,y,disc,R,i));
        }
        else
            c[j] = c[j-1]*x;

        a[j+1] = R * a[j] + y[i] - c[j];
        if ((j+1 < nT) && (a[j+1] < 0)) {*negA = 1; break;}

        if (++k == T)
            k = 0;
    }
                            
}        



/*=================================================================
 *  function FULL_ASSET_PATH
 *  full_asset_path(T,y,ind,disc,R,x,a,c,atmp,ctmp)
 * 
 *  output: a      nT+1 vector
 *          c      nT   vector
 */
static void full_asset_path(
           int     T,
		   double  y[],
           int     ind,
           double  disc[],
           double  R,
           double  x,
           double  *a,
           double  *c,
           double  *atmp,
           double  *ctmp
		   )
{
    int      i,j,k,s,t,negA;
    
    a[0] = 0;
    i    = 0;
    k    = ind;

    while (i < T) {
        atmp[0] = a[i];
        for (j = T; j > 0; j--) {
            partial_asset_path(T,j,y,k,disc,R,x,atmp,ctmp,&negA);
            if (negA == 0)
                break;
        } 
        t = i;
        for (s = 0; (s < j && t < T); s++) {
            a[t] = atmp[s];
            c[t] = ctmp[s];
            t++;
        }

        if (t == T) a[t] = atmp[s];
        else        a[t] = atmp[j];
        
        i += j;
        k = (k + j) % T;
    }            
 
}        


void mexFunction( int nlhs, mxArray *plhs[], 
		  int nrhs, const mxArray *prhs[] )
{     
    double       *Y,*pR,*pB,*pG,*A,*C; 
    int          T,N;
    int          i,j,k,ind;
    double       *y,R,beta,gamma,*disc;
    double       *a,*c,*atmp,*ctmp;
    double       x;
    double       *I;
    
    /* Check for proper number of arguments */    
    if (nrhs != 4) { 
	mexErrMsgTxt("Four input arguments required."); 
    } else if (nlhs != 3) {
	mexErrMsgTxt("Three output arguments required."); 
    } 
   
       
    /* Assign pointers to the various parameters */ 
    Y     = mxGetPr(prhs[0]);          /* income */
    pR    = mxGetPr(prhs[1]);          /* gross interest rate, 1+r */
    pB    = mxGetPr(prhs[2]);          /* beta */
    pG    = mxGetPr(prhs[3]);          /* gamma, parameter in utility fcn */
    
    T  = mxGetM(prhs[0]);
    N  = mxGetN(prhs[0]);

    /* Create a matrix for the return argument */ 
    A_OUT = mxCreateDoubleMatrix(T+1, N, mxREAL); 
    C_OUT = mxCreateDoubleMatrix(T, N, mxREAL); 
    I_OUT = mxCreateDoubleMatrix(1, N, mxREAL); 
    A     = mxGetPr(A_OUT);
    C     = mxGetPr(C_OUT);
    I     = mxGetPr(I_OUT);
              
    y      = (double*) calloc(T,sizeof(double));
    disc   = (double*) calloc(T,sizeof(double));
    a      = (double*) calloc(T+1,sizeof(double));
    c      = (double*) calloc(T,sizeof(double));
    atmp   = (double*) calloc(T+1,sizeof(double));
    ctmp   = (double*) calloc(T,sizeof(double));


    R           = *pR;
    beta        = *pB;
    gamma       = *pG;

    
    disc[0] = 1;
    for (i = 1; i < T; i++)
        disc[i] = disc[i-1]/R;
    
    x  = pow(beta*R,1/gamma);
           
    for (i = 0; i < N; i++) {

        /* Life-cycle income for this household */
        for (j = 0; j < T; j++)
            y[j] = Y[j+i*T];

       
        /* find period with highest npv, use as initial guess */
        if (R < 1.0001)
            ind = max_npv(T,y,disc,1.0001);
        else
            ind = max_npv(T,y,disc,R);      
        ind = (T + ind - (T % 10) ) % T;
                        
        /* Find first period k where initial a = 0 is a solution */
        for (k = 0; k < T; k++) {
            full_asset_path(T,y,ind,disc,R,x,a,c,atmp,ctmp);
            if (a[T] < EPS) break;
            if (++ind == T) ind = 0;
        }
        
        if (k==T) {printf("Warning: k = T!!!\n"); ind--;}
        I[i] = ind+1;

        for (j = 0; j < T; j++) {
            A[j+i*(T+1)] = a[j];
            C[j+i*T] = c[j];
        }
        A[T+i*(T+1)] = a[T];        
        
    }

    free(y); free(disc);
    free(a); free(c);
    free(atmp); free(ctmp);
    
    return;
    
}


