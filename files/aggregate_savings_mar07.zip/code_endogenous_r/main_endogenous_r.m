clear all

PROCESS      = 'STY';                          % Income process. Choose STY, HSZ, or AIY

% settings for stochastic simulation
PARAMS.sto.T  = 1200;
PARAMS.sto.N  = 2000;

% settings for "deterministic simulation"
PARAMS.det.T  = 500;
PARAMS.det.N  = 200;                           % # households per iteration
PARAMS.det.NN = 10;                            % # iterations on household loop

% settings for "deterministic simulation"
PARAMS.det.T  = 300;
PARAMS.det.N  = 100;                           % # households per iteration
PARAMS.det.NN = 10;                            % # iterations on household loop

% settings for "certainty equivalent simulation"
PARAMS.ce.T   = 1300;
PARAMS.ce.N   = 10;                            % # households per iteration
PARAMS.ce.NN  = 10;                            % # iterations on household loop

% Income process
if PROCESS == 'STY'
    rho    = 0.98;                             % autocorr. (gamma in paper)
    sigma  = sqrt(0.020);
elseif PROCESS == 'HSZ'
    rho    = 0.95;
    sigma  = sqrt(0.030);
else
    rho    = 0.60;
    sigma  = sqrt(0.013);
end

[E,PI] = tauchen(9,0,rho,sigma,3);
E      = exp(E)'; 
nE     = length(E);                            % # income states
ergPI  = PI^1000;
ergPI  = ergPI(ceil(nE/2),:)';
E      = E / (ergPI'*E);

% Parameters
theta = 0.36;
beta  = 1/1.04;
delta = 0.08;
gamma = 1.00;                                  % risk aversion (mu in paper)

PARAMS.beta    = beta;
PARAMS.theta   = theta;
PARAMS.delta   = delta;
PARAMS.rho     = rho;
PARAMS.sigma   = sigma;
PARAMS.nE      = nE;
PARAMS.E       = E;
PARAMS.PI      = PI;
PARAMS.ergPI   = ergPI;
PARAMS.gamma = gamma;

    fprintf(1,'================================================\n');
    fprintf(1,'Solving with gamma = %8.4f\n',gamma)

    fprintf(1,'>>>>> 1. Solving stochastic economy\n')
    STO_OUT = solve_stochastic(0.030,0.031,0,PARAMS);

    fprintf(1,'>>>>> 2. Solving deterministic economy\n')
    DET_OUT = solve_deterministic_r(STO_OUT.r,1/beta-1,PARAMS);

    fprintf(1,'>>>>> 3. Solving certainty-equivalent economy\n')
    CE_OUT = solve_certequiv_r(DET_OUT.r,1/beta-1,PARAMS);


    prec_sav = STO_OUT.K - DET_OUT.K;
    fprintf(1,'gamma = %6.2f, K = %6.2f, deterministic K = %6.2f\n',...
            gamma,STO_OUT.K,DET_OUT.K)
    fprintf(1,'Prec savings = %6.2f, prec sav relative to stoch K = %8.4f relative to determ K = %8.4f\n',...
            prec_sav,prec_sav/STO_OUT.K,prec_sav/DET_OUT.K)
