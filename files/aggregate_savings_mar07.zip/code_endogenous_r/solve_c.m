function C = solve_c(r,C,PARAMS)
% =================================================================
% Solve for decision rule C as a function of interest rate r
% =================================================================

maxdiff     = 1e-4;        % convergence criterion for dec. rule
EEtolerance = 1e-4;        % tolerance when solving Euler eq.
maxdiff     = 1e-6;        % convergence criterion for dec. rule
EEtolerance = 1e-6;        % tolerance when solving Euler eq.
 
gamma       = PARAMS.gamma;
beta        = PARAMS.beta;
theta       = PARAMS.theta;
delta       = PARAMS.delta;
E           = PARAMS.E;
PI          = PARAMS.PI;
nE          = PARAMS.nE;
A           = PARAMS.A;
nA          = PARAMS.nA;

K  = (theta / (r+delta))^(1/(1-theta));
Y  = K^theta;
W  = (1-theta)*Y;

% Cash on hand
X = (1+r)*ones(nE,1)*A + W*E*ones(1,nA); 

% Index to income state
I = (1:nE)'*ones(1,nA);


% =================================================================
% Update C based on previous guess. Iterate until convergence.
% =================================================================
nextC = zeros(nE,nA);
sA = zeros(nE,2*nA-1);
s1 = zeros(nE,2*(nA-1));
s2 = zeros(nE,2*(nA-1));
s3 = zeros(nE,2*(nA-1));

diff = 1;
iter = 1;
while (diff > maxdiff) & (iter <= 200)
     
  % Check first if liquidity constraint binds, i.e. let c = x
  rhs   = beta*(1+r)*C(:,1).^(-gamma);
  lhs   =  X.^(-gamma);
  E_rhs = PI*rhs*ones(1,nA);
  unconstrained = lhs < E_rhs;
  constrained = lhs >= E_rhs;

  % For all unconstrained, find new c(y,a) to solve the Euler eq.
  c_min  = max(1e-4,W*E(1))*ones(nE,nA);   % no one would consume less
  c_max  = X;
  old_C  = C;
  [C(:),rc] = solve_euler(c_min(:),c_max(:),constrained(:),C(:),A,I(:),PI(:),X(:),...
                       [nE nA beta r gamma]);                        
  
  if max(rc)>1e-4, disp('*** Warning. EE not solved ***'); end

  diff  = max(max(abs((C-old_C)./old_C)));
  
  iter = iter + 1;
end

fprintf(1,'Stopped iterating after %5d iterations\n',iter-1)
if diff > maxdiff,
    fprintf(1,'*** Warning. Decision rule for c not solved. Diff = %10.2e\n',diff)
end
