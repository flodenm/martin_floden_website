function OUTPUT = solve_deterministic_r(minR,maxR,PARAMS)
% Solve for equilibrium interest rate under certainty equivalence,
% i.e. households think that future income equals expected future
% income conditional on today's income. 
% ... But income actually follows the stochastic process

gamma       = PARAMS.gamma;
beta        = PARAMS.beta;
theta       = PARAMS.theta;
delta       = PARAMS.delta;
E           = PARAMS.E;
PI          = PARAMS.PI;
nE          = PARAMS.nE;
ergPI       = PARAMS.ergPI;
T           = PARAMS.ce.T;
N           = PARAMS.ce.N;
nN          = PARAMS.ce.NN;

nFORWARD    = 400;              % periods forward to calculate income path

% Calculate expected future income path (divided by wage) for each state
EE = zeros(nE,nFORWARD);
for i = 1:nE
    S    = zeros(nE,1);
    S(i) = 1;
    for j = 1:nFORWARD;
        EE(i,j) = E'*S;
        S       = PI'*S;
    end
end


% Solve for r
solution = 0;
while (solution == 0)

    r  = (minR + maxR) / 2;
        
    R  = 1+r;
    K  = (theta / (r+delta))^(1/(1-theta));
    Y  = K^theta;
    C  = Y - delta*K;
    W  = (1-theta)*Y;

    % Calculate NPV(income) for each state
    NPV = zeros(nE,1);
    for iE = 1:nE
        for t = 1:nFORWARD
            NPV(iE) = NPV(iE) + R^(-(t-1))*W*EE(iE,t);
        end
        NPV(iE) = NPV(iE) + R^(-nFORWARD)*W/(1-1/R);      % Assumes E(inf) = 1
    end

    % Solve/simulate households
    saveA = [];
    rand('state',12474884);

    for bigI = 1:nN

    % draw initial states
    eps          = rand(1,N);
    initialState = zeros(1,N);
    for i = 1:N
        sumP = ergPI(1);
        for j = 1:nE-1
            if eps(i) < sumP
                break
            else
                sumP = sumP + ergPI(j+1);
            end
        end
        initialState(i) = j;
    end
           

    eps     = rand(T,N);
    yi      = markov(initialState,PI,eps);
    y       = W*E(yi);
    tic
    [A,C]   = cert_equiv_solution(y,R,beta,gamma,NPV,yi);
    fprintf(1,'Elapsed time = %4d seconds, mean(A) = %10.4f\n',toc,mean(mean(A(1:end-1,:))));

    saveA = [saveA mean(mean(A(1:end-1,:)))];

    end

    Abar = mean(saveA);
    
    r_Abar = theta / (Abar^(1-theta)) - delta;   % r such that K(r) = Abar


    if Abar > K
        maxR = r;
        minR = max(minR,r_Abar);
    else
        minR = r;
        maxR = min(maxR,r_Abar);
    end

    if abs(Abar-K) < 0.01
        solution = 1;
    end

    fprintf(1,'r = %6.4f, K = %6.2f, A = %6.2f\n',r,K,Abar);
    
end


OUTPUT.r        = r;
OUTPUT.K        = K;
OUTPUT.A        = Abar;
OUTPUT.exampleY = y;
OUTPUT.exampleA = A;
OUTPUT.exampleC = C;





function [A,C] = cert_equiv_solution(y,R,beta,gamma,NPV,yi);

[T,N] = size(y);
A     = zeros(T+1,N);
x     = beta^(1/gamma)*R^(1/gamma-1);

for t=1:T
    % 1. if constraint does not bind
    c      = (1-x) * (R*A(t,:) + NPV(yi(t,:))');
    next_a = y(t,:) + R*A(t,:) - c;
    next_a = max(0,next_a);
    c      = y(t,:) + R*A(t,:) - next_a;
    A(t+1,:) = next_a;
    C(t,:)   = c;
end

A = A(300:end-1,:);
C = C(300:end,:);