function OUTPUT = solve_deterministic_r(minR,maxR,PARAMS)

gamma       = PARAMS.gamma;
beta        = PARAMS.beta;
theta       = PARAMS.theta;
delta       = PARAMS.delta;
E           = PARAMS.E;
PI          = PARAMS.PI;
nE          = PARAMS.nE;
ergPI       = PARAMS.ergPI;
T           = PARAMS.det.T;
N           = PARAMS.det.N;
nN          = PARAMS.det.NN;

solution = 0;

while (solution == 0)

    r  = (minR + maxR) / 2;
        
    R  = 1+r;
    K  = (theta / (r+delta))^(1/(1-theta));
    Y  = K^theta;
    C  = Y - delta*K;
    W  = (1-theta)*Y;

    saveA = [];
    rand('state',12474884);

    for bigI = 1:nN

    % draw initial states
    eps          = rand(1,N);
    initialState = zeros(1,N);
    for i = 1:N
        sumP = ergPI(1);
        for j = 1:nE-1
            if eps(i) < sumP
                break
            else
                sumP = sumP + ergPI(j+1);
            end
        end
        initialState(i) = j;
    end

    eps     = rand(T,N);
    y       = W*E(markov(initialState,PI,eps));
    tic
    [A,C,I] = life_cycle_equilibrium(y,R,beta,gamma);
    fprintf(1,'Elapsed time = %4d seconds, mean(A) = %10.4f\n',toc,mean(mean(A(1:end-1,:))))

    saveA = [saveA mean(mean(A(1:end-1,:)))];

    end

    Abar = mean(saveA);
    
    r_Abar = theta / (Abar^(1-theta)) - delta;   % r such that K(r) = Abar


    if Abar > K
        maxR = r;
        minR = max(minR,r_Abar);
    else
        minR = r;
        maxR = min(maxR,r_Abar);
    end

    if abs(Abar-K) < 0.01
        solution = 1;
    end

    fprintf(1,'r = %6.4f, K = %6.2f, A = %6.2f\n',r,K,Abar);

end


OUTPUT.r        = r;
OUTPUT.K        = K;
OUTPUT.A        = Abar;
OUTPUT.exampleY = y;
OUTPUT.exampleA = A;
OUTPUT.exampleC = C;
OUTPUT.exampleI = I;
