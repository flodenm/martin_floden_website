#include "mex.h"
#include <stdio.h>
#include <math.h>


/* Output Arguments */
#define	C_OUT	plhs[0]
#define	R_OUT	plhs[1]

#define EEtolerance 1e-6

/*=================================================================
 *  function LEFTINDEX
 *  i = leftIndex(x,Y,iY,nY)
 * 
 *  input   x   = scalar
 *          Y   = 1*nY vector
 *  output  i   = index for x in Y, 0 <= ind < nY-1
 */
static int leftIndex(
           double   x,
           double	Y[],
           int      nY
		   )
{
    int     i;
       
    i = 0;
    while ((i < (nY-1)) && (x > Y[i+1])) i++;
    
    return i;
}


static double solve_euler(
           double  c_min, double c_max,
           double  *C, double *A,
           int     iCurrent,
           double  *PI,
           int     nE, int nA,
           double  X,
           double  BR,
           double  gamma,
           double  *success
		   )
{
int     iE,iA,iter;
double  c_guess,a_prime,E_rhs,w,nextC,rhs,lhs,solution;

solution = 0;
iter = 1;

while ((solution==0) && (iter <= 100)) {

    c_guess = .5*(c_min+c_max);
    a_prime = X - c_guess;                
    iA      = leftIndex(a_prime,A,nA);         
    w       = 1 - (a_prime-A[iA]) / (A[iA+1]-A[iA]);
    if (w < 0) w = 0;
    else if (w > 1) w = 1;

    E_rhs   = 0;
    for (iE = 0; iE < nE; iE++) {
      nextC = w*C[iE+iA*nE] + (1-w)*C[iE+(iA+1)*nE];
      rhs   = BR*pow(nextC,-gamma);
      E_rhs = E_rhs + rhs*PI[iCurrent + iE*nE];
    }
    lhs = pow(c_guess,-gamma);
  
    if (lhs < E_rhs) 
        c_max = c_guess;
    else 
        c_min = c_guess;
        
    if (fabs(lhs-E_rhs) < EEtolerance) solution = 1;
    iter++;
}

*success = (1-solution) * fabs(lhs-E_rhs);
return c_guess;
}



void mexFunction( int nlhs, mxArray *plhs[], 
		  int nrhs, const mxArray *prhs[] )
{     
    double *C,*R;
    double *pCMIN,*pCMAX,*pC,*pA,*pI,*pPI,*pX,*pARG;
    char   *pCONSTR;
    double nE,nA,beta,r,gamma,c,ret;
    int    i,n;
    
    /* Check for proper number of arguments */
    if (nrhs != 9) { 
	mexErrMsgTxt("Two input arguments required."); 
    } else if (nlhs > 2) {
	mexErrMsgTxt("Too many output arguments."); 
    } 
   
       
    /* Assign pointers to the various parameters */ 
    pCMIN   = mxGetPr(prhs[0]);   
    pCMAX   = mxGetPr(prhs[1]);       
    pCONSTR = mxGetPr(prhs[2]);
    pC      = mxGetPr(prhs[3]);
    pA      = mxGetPr(prhs[4]);
    pI      = mxGetPr(prhs[5]);
    pPI     = mxGetPr(prhs[6]);
    pX      = mxGetPr(prhs[7]);       
    pARG    = mxGetPr(prhs[8]);
    
    n       = mxGetN(prhs[0]);
    if (n == 1) n = mxGetM(prhs[0]);
    
    nE      = pARG[0];
    nA      = pARG[1];
    beta    = pARG[2];
    r       = pARG[3];
    gamma   = pARG[4];

   
    /* Create a matrix for the return argument */ 
    C_OUT = mxCreateDoubleMatrix(1, n, mxREAL); 
    R_OUT = mxCreateDoubleMatrix(1, n, mxREAL); 
    C     = mxGetPr(C_OUT);
    R     = mxGetPr(R_OUT);
                  
    for (i = 0; i < n; i++) {
        if (pCONSTR[i] > 0) {
            C[i] = pX[i];
            R[i] = -1;
        }
        else {
            c = solve_euler(pCMIN[i],pCMAX[i],pC,pA,pI[i]-1,pPI,nE,nA,pX[i],
                            beta*(1+r),gamma,&ret);
            C[i] = c;
            R[i] = ret;
        }
    }
    
    return;
    
}


