function OUTPUT = solve_stochastic(minR,maxR,REPORT,PARAMS)
% =================================================================
% Solve stochastic model with heterogenous households
% ... similar to Aiyagara (QJE 1994).
%
% Linearize decision rule between grid points
%
% Assume CRRA utility
% =================================================================

gamma       = PARAMS.gamma;
beta        = PARAMS.beta;
theta       = PARAMS.theta;
delta       = PARAMS.delta;
E           = PARAMS.E;
PI          = PARAMS.PI;
nE          = PARAMS.nE;
ergPI       = PARAMS.ergPI;
T           = PARAMS.sto.T;
nAg         = PARAMS.sto.N;


solution = 0;
iter = 0;

while (solution == 0) & iter < 20

    iter = iter + 1;
    r = (minR+maxR) / 2;


    % Implications for aggregates
    K  = (theta / (r+delta))^(1/(1-theta));
    Y  = K^theta;
    W  = (1-theta)*Y;

    % Grid for savings (= assets in end of period)
    A  = [0:0.002:0.05 0.06:0.01:0.1 0.12:.02:0.2 0.25:0.05:1.4 1.5:0.1:10 10.25:.25:15 15.5:.5:20 21:30 35:5:70 80 90 100 150 200 500]*(K/10);
    fprintf(1,'Length A = %5d\n',length(A));
   
    nA = length(A);
    PARAMS.A  = A;
    PARAMS.nA = nA;


    % Let C(y,a) 
    % Initial guess for decision rule. Guess that all cash is consumed.
    disp('Solving decision rule...')
    X    = (1+r)*ones(nE,1)*A + W*E*ones(1,nA); 
    if iter == 1
        Cdec = solve_c(r,X,PARAMS);
    else
        Cdec = solve_c(r,Cdec,PARAMS);
    end
    Adec = X - Cdec;



    %==================================================================
    % Simulate the economy
    % =================================================================

    disp('Starting simulations...')
    Csim   = zeros(T,nAg);
    Asim   = zeros(T,nAg);


    % draw initial states
    rand('state',12474884);
    eps          = rand(1,nAg);
    initialState = zeros(1,nAg);
    for i = 1:nAg
        sum = ergPI(1);
        for j = 1:nE-1
            if eps(i) < sum
                break
            else
                sum = sum + ergPI(j+1);
            end
        end
        initialState(i) = j;
    end

    eps   = rand(T,nAg);
    iYsim = markov(initialState,PI,eps);
    Ysim  = W*E(iYsim);

    Asim(1,:) = K;

    for i = 2:T;
      [indxA,w] = leftIndex(Asim(i-1,:),A);
      w         = min(1,max(0,w));
      indx      = (indxA-1)*nE + iYsim(i,:);
      Csim(i,:) = w.*Cdec(indx) + (1-w).*Cdec(indx+nE);
      Asim(i,:) = min(A(end),(1+r)*Asim(i-1,:) + Ysim(i,:) - Csim(i,:));
    end


    Abar = Asim(201:end,:);
    Abar = mean(Abar(:));

    r_Abar = theta / (Abar^(1-theta)) - delta;   % r such that K(r) = Abar

    if Abar > K
        maxR = r;
        minR = max(minR,r_Abar);
   else
        minR = r;
        maxR = min(maxR,r_Abar);
    end

    if abs(Abar-K) < 0.01
        solution = 1;
    end

    fprintf(1,'r = %6.4f, K = %6.2f, A = %6.2f\n',r,K,Abar);
    
    a = Asim(201:end,:);
    higha = find(a(:) > 0.95*A(end));
    if length(higha) > 0
        fprintf('*** Warning, # simulated a > 0.95*maxA = %5d\n',length(higha))
    end
    
end


OUTPUT.r     = r;
OUTPUT.K     = K;
OUTPUT.A     = Abar;
OUTPUT.Agrid = A;
OUTPUT.solutionA = Adec;
OUTPUT.solutionC = Cdec;
OUTPUT.exampleA  = Asim(201:end,1:10);
OUTPUT.exampleC  = Csim(201:end,1:10);
OUTPUT.exampleY  = Ysim(201:end,1:10);

if REPORT
    
%==================================================================
% Report results
%==================================================================

% Plot C(y,a+y)
figure
for i = 1:nE
  plot(A+W*E(i),Cdec(i,:))
  hold on
end
title('Decision rule for consumption')
xlabel('cash on hand')

figure
t = 301:T;                  % Skip first 300 periods
n = length(t);
plot(1:n,Ysim(t,1))
hold on
plot(1:n,Csim(t,1))
plot(1:n,Asim(t,1))


sdY0 = sigma / sqrt(1-rho^2)
sdY = mean(std(log(Ysim(t,:))))
sdC = mean(std(log(Csim(t,:))))
sdCY = sdC / sdY


%==================================================================
% A simple test of the solution 
%==================================================================
minA = [0      Abar/8 Abar/5 Abar];
maxA = [Abar/8 Abar/5 Abar   1e10];
for j = 1:length(minA);
  eps = [];
  for i = t-1
    itest = find((Asim(i,:) > minA(j)) & (Asim(i,:) < maxA(j)));
    lhs   = Csim(i,itest).^(-gamma);
    rhs   = beta*(1+r)*Csim(i+1,itest).^(-gamma);
    eps   = [eps (lhs - rhs)];
  end

  test = mean(eps)/std(eps)*sqrt(length(eps))
end
end

