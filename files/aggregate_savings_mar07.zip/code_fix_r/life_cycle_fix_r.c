 /*=================================================================
 *
 * LIFE_CYCLE.C
 * The calling syntax is:
 *
 *		[a] = life_cycle_assets(y,disc,R)
 *
 *
 *=================================================================*/

#include "mex.h"
#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <math.h>


/* Output Arguments */
#define	A_OUT	plhs[0]
#define	I_OUT	plhs[1]
#define	M_OUT	plhs[2]

/* Program Settings */
#define HORIZON    1000
#define UPDATE_NPV  100
#define UPDATE_C     80


/*=================================================================
 *  function NPV 
 *  f = npv(T,y,disc,R,ind)
 * 
 *  input   T   = # periods
 *          ind = index to first period 
 *  output  f   = npv of y discounted at disc and R
 */
static double npv(
           int      T,
		   double	y[],
		   double	disc[],
 		   double	R,
           int      ind
		   )
{
    int     i,j,n;
    double  thisNPV;

    if (T < HORIZON) n = T; else n = HORIZON;

    thisNPV = 0;
    i       = ind;
    for (j = 0; j < n; j++) {
        thisNPV = thisNPV + disc[j] * y[i];
        if (++i == T) i = 0;
    }
    thisNPV = thisNPV / (1 - disc[T-1]/R);    

    return thisNPV;
}


/*=================================================================
 *  function maxNPV 
 *  f = maxNPV(T,y,disc,R,ind)
 * 
 *  input   T  = # periods
 *  output  f   = npv of y discounted at disc and R
 *          ind = pointer to index to time period with highest npv
 */
static double maxNPV(
           int      T,
		   double	y[],
		   double	disc[],
 		   double	R,
           int      *ind
		   )
{
    int     t;
    double  maxVal,iMaxNPV,thisNPV;

    maxVal  = 0;
    iMaxNPV = 0;
    
    for (t = 0; t < T; t++) {
        
        /* recalculate npv occasionally to increase precision */
        if (t % UPDATE_NPV == 0)
            thisNPV = npv(T,y,disc,R,t);
        else
            thisNPV = R*(thisNPV-y[t-1]);
            
        if (thisNPV > maxVal) {
            maxVal = thisNPV;
            iMaxNPV = t;
        }
    }
   
    *ind = iMaxNPV;    
    return maxVal;
}


/*=================================================================
 *  function ASSET_PATH
 *  asset_path(T,y,ind,disc,R,a)
 * 
 */
void asset_path(
           int     T,
		   double  y[],
           int     ind,
           double  disc[],
           double  R,
           double  *a
		   )
{
    int      i,j,k;
    double   c,r;
    

    k = ind+1;
    if (k == T) {k = 0; a[T-1] = 0;}
    else a[k-1] = 0;
    
    r = (1-1/R)*R;
        
    for (j = 0; j < T-1; j++) {
        
        if (k > 0) i = k-1;
        else i = T-1;
        
        /* recalculate c occasionally to increase precision */
        if (j % UPDATE_C == 0)
            c = (1-1/R) * npv(T,y,disc,R,i) + r*a[i];   
       
        a[k] = R * a[i] + y[i] - c;

        if (++k == T)
            k = 0;
    }
                
        
}        


void mexFunction( int nlhs, mxArray *plhs[], 
		  int nrhs, const mxArray *prhs[] )
{     
    double       *Y,*pR,*A,*M; 
    int          T,N;
    int          i,j;
    double       *y,npvY,R,*disc;
    double       *a;
    int          maxIndex;
    double       *I;
    
    /* Check for proper number of arguments */    
    if (nrhs != 2) { 
	mexErrMsgTxt("Two input arguments required."); 
    } else if (nlhs > 3) {
	mexErrMsgTxt("Max three output arguments allowed."); 
    } 
   
       
    /* Assign pointers to the various parameters */ 
    Y     = mxGetPr(prhs[0]);          /* income */
    pR    = mxGetPr(prhs[1]);          /* gross interest rate, 1+r */
    
    T  = mxGetM(prhs[0]);
    N  = mxGetN(prhs[0]);

    /* Create a matrix for the return argument */ 
    A_OUT = mxCreateDoubleMatrix(T, N, mxREAL); 
    I_OUT = mxCreateDoubleMatrix(1, N, mxREAL); 
    M_OUT = mxCreateDoubleMatrix(1, N, mxREAL); 
    A     = mxGetPr(A_OUT);
    I     = mxGetPr(I_OUT);
    M     = mxGetPr(M_OUT);
              
    y     = (double*) calloc(T,sizeof(double));
    disc  = (double*) calloc(T,sizeof(double));
    a     = (double*) calloc(T,sizeof(double));

    
    R       = *pR;
    disc[0] = 1;
    for (i = 1; i < T; i++)
        disc[i] = disc[i-1]/R;
   
    for (i = 0; i < N; i++) {


        /* Life-cycle income for this household */
        for (j = 0; j < T; j++)
            y[j] = Y[j+i*T];
    
        /* Highest NPV */
        npvY = maxNPV(T,y,disc,R,&maxIndex);

        /* Implied asset path */        
        asset_path(T,y,maxIndex,disc,R,a);
        

        for (j = 0; j < T; j++)
            A[j+i*T] = a[j];
        
        I[i] = maxIndex+1;
        M[i] = npvY;
    }
    
    free(y); free(disc); free(a);

    return;
    
}


