% Code to generate Figure 1 in Floden (2007), "Aggregate Savings when
% Individual Income Varies"
%
% The code thus solves for aggregate savings in an economy where
% the discount rate = r and where agents have perfect foresight over 
% future income.
%
% T is the length of the income cylce and the economy is populated by nN*N
% agents.
%
% TLOOP contains all T that will be considered
% Results are stored in A_T: This is the implied aggregate savings level A(T) 
%
% Martin Floden
% Stockholm School of Economics

clear all

PROCESS      = 'AIY';                                  % Income process. Choose STY, HSZ, or AIY

TLOOP = [20:10:100 200:100:1000 2000:1000:10000 12000 15000 20000 50000 100000];

N     = 1000;                                          % # households per iteration
nN    = 10;                                            % # iterations on household loop


% Income process
if PROCESS == 'STY'
    rho    = 0.98;
    sigma  = sqrt(0.020);
elseif PROCESS == 'HSZ'
    rho    = 0.95;
    sigma  = sqrt(0.030);
else
    rho    = 0.60;
    sigma  = sqrt(0.013);
end

[E,PI] = tauchen(9,0,rho,sigma,3);
E      = exp(E)'; 
nE     = length(E);                                    % # income states
ergPI  = PI^1000;
ergPI  = ergPI(ceil(nE/2),:)';
E      = E / (ergPI'*E);

% Parameters
theta = 0.36;
beta  = 1/1.04;
delta = 0.08;

% Assume beta*(1+r) = 1
r  = 1/beta - 1;
R  = 1+r;
K  = (theta / (r+delta))^(1/(1-theta));
Y  = K^theta;
C  = Y - delta*K;
W  = (1-theta)*Y;

maxa   = W*(E(end)-1)/r;
fprintf(1,'Expected required capital stock = %10.4f\n',maxa);


A_T   = [];

for T = TLOOP
tic

saveA = [];
saveP = [];
saveY = [];

for bigI = 1:nN
    
% draw initial states
eps          = rand(1,N);
initialState = zeros(1,N);
for i = 1:N
    sum = ergPI(1);
    for j = 1:nE-1
        if eps(i) < sum
            break
        else
            sum = sum + ergPI(j+1);
        end
    end
    initialState(i) = j;
end
              
eps   = rand(T,N);
y     = W*E(markov(initialState,PI,eps));
[A,I,M] = life_cycle_fix_r(y,R);

% Check solution
finalA = zeros(1,N);
for i = 1:N
    if I(i) == 1
        c         = R*A(I(i),i) + y(I(i),i) - A(I(i)+1,i);
        finalA(i) = R*A(T,i) + y(T,i) - c;
    elseif I(i) == T
        c         = R*A(I(i),i) + y(I(i),i) - A(1,i);
        finalA(i) = R*A(I(i)-1,i) + y(I(i)-1,i) - c;
    else
        c         = R*A(I(i),i) + y(I(i),i) - A(I(i)+1,i);
        finalA(i) = R*A(I(i)-1,i) + y(I(i)-1,i) - c;
    end
end
        
saveA = [saveA mean(A(:))];
saveP = [saveP max(abs(finalA))];
saveY = [saveY mean(y(:)/W)];
fprintf(1,'iter = %4d\n',bigI)
end

fprintf(1,'Results for %6d periods and %1d*%1d households\n',T,nN,N)
fprintf(1,'...A = %10.4f, K = %10.4f, K/Y = %10.4f, Y = %10.4f\n',mean(saveA),K,K/Y,Y)
fprintf(1,'...max A error = %10.2e, mean E = %10.6f\n',max(saveP),mean(saveY))
fprintf(1,'...a in [%1.4f,%1.4f]\n',min(saveA),max(saveA))
fprintf(1,'...time elapsed for this T = %4.2f seconds\n\n',toc)
A_T    = [A_T mean(saveA)];

end


testC  = zeros(T,N);
for i = 1:T-1
    for j = 1:N
        testC(i,j) = R*A(i,j) + y(i,j) - A(i+1,j);
    end
end
testC(T,:) = R*A(T,:) + y(T,:) - A(1,:);

save results_070308 TLOOP A_T