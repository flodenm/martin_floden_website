% Script to extract data from BIS House Price file

clear all

% =======================================
% Countries with monthly data
% =======================================

r1 = 424;   % first row of data
r2 = 567;   % final row of data
N  = r2-r1+1;

R1 = num2str(r1);
R2 = num2str(r2);

% Iceland (capital city)
[x1,x2,x3]  = xlsread('BIS_HousePricesDec2013','Monthly Series',['ad' R1 ':ad' R2]);
tmp = NaN*ones(N,1); for i = 1:N; if isfloat(x3{i}); tmp(i)=x3{i}; else z(i)=NaN; end; end;
tmp2 = zeros(N/12,1); for i = 1:12; tmp2 = tmp2 + tmp(i:12:end)/12; end
ISL = tmp2;

% Israel
[x1,x2,x3]  = xlsread('BIS_HousePricesDec2013','Monthly Series',['ac' R1 ':ac' R2]);
tmp = NaN*ones(N,1); for i = 1:N; if isfloat(x3{i}); tmp(i)=x3{i}; else z(i)=NaN; end; end;
tmp2 = zeros(N/12,1); for i = 1:12; tmp2 = tmp2 + tmp(i:12:end)/12; end
ISR = tmp2;

% Portugal
[x1,x2,x3]  = xlsread('BIS_HousePricesDec2013','Monthly Series',['an' R1 ':an' R2]);
tmp = NaN*ones(N,1); for i = 1:N; if isfloat(x3{i}); tmp(i)=x3{i}; else z(i)=NaN; end; end;
tmp2 = zeros(N/12,1); for i = 1:12; tmp2 = tmp2 + tmp(i:12:end)/12; end
PRT = tmp2;


% =======================================
% Countries with quarterly data
% =======================================
r1 = 188;   % first row of data
r2 = 235;   % final row of data
N  = r2-r1+1;

R1 = num2str(r1);
R2 = num2str(r2);

% Austria
[x1,x2,x3]  = xlsread('BIS_HousePricesDec2013','Quarterly Series',['b' R1 ':b' R2]);
tmp = NaN*ones(N,1); for i = 1:N; if isfloat(x3{i}); tmp(i)=x3{i}; else z(i)=NaN; end; end;
tmp2 = zeros(N/4,1); for i = 1:4; tmp2 = tmp2 + tmp(i:4:end)/4; end
AUT = tmp2;

% Czech Rep (2008-)
[x1,x2,x3]  = xlsread('BIS_HousePricesDec2013','Quarterly Series',['ak' R1 ':ak' R2]);
tmp = NaN*ones(N,1); for i = 1:N; if isfloat(x3{i}); tmp(i)=x3{i}; else z(i)=NaN; end; end;
tmp2 = zeros(N/4,1); for i = 1:4; tmp2 = tmp2 + tmp(i:4:end)/4; end
CZE = tmp2;

% Czech Rep (-2011, existing houses)
[x1,x2,x3]  = xlsread('BIS_HousePricesDec2013','Quarterly Series',['an' R1 ':an' R2]);
tmp = NaN*ones(N,1); for i = 1:N; if isfloat(x3{i}); tmp(i)=x3{i}; else z(i)=NaN; end; end;
tmp2 = zeros(N/4,1); for i = 1:4; tmp2 = tmp2 + tmp(i:4:end)/4; end
CZEalt = tmp2;

% Estonia
[x1,x2,x3]  = xlsread('BIS_HousePricesDec2013','Quarterly Series',['bf' R1 ':bf' R2]);
tmp = NaN*ones(N,1); for i = 1:N; if isfloat(x3{i}); tmp(i)=x3{i}; else z(i)=NaN; end; end;
tmp2 = zeros(N/4,1); for i = 1:4; tmp2 = tmp2 + tmp(i:4:end)/4; end
EST = tmp2;

% Hungary
[x1,x2,x3]  = xlsread('BIS_HousePricesDec2013','Quarterly Series',['dh' R1 ':dh' R2]);
tmp = NaN*ones(N,1); for i = 1:N; if isfloat(x3{i}); tmp(i)=x3{i}; else z(i)=NaN; end; end;
tmp2 = zeros(N/4,1); for i = 1:4; tmp2 = tmp2 + tmp(i:4:end)/4; end
HUN = tmp2;

% Luxembourg (flats)
[x1,x2,x3]  = xlsread('BIS_HousePricesDec2013','Quarterly Series',['dz' R1 ':dz' R2]);
tmp = NaN*ones(N,1); for i = 1:N; if isfloat(x3{i}); tmp(i)=x3{i}; else z(i)=NaN; end; end;
tmp2 = zeros(N/4,1); for i = 1:4; tmp2 = tmp2 + tmp(i:4:end)/4; end
LUX = tmp2;

% Mexico
[x1,x2,x3]  = xlsread('BIS_HousePricesDec2013','Quarterly Series',['en' R1 ':en' R2]);
tmp = NaN*ones(N,1); for i = 1:N; if isfloat(x3{i}); tmp(i)=x3{i}; else z(i)=NaN; end; end;
tmp2 = zeros(N/4,1); for i = 1:4; tmp2 = tmp2 + tmp(i:4:end)/4; end
MEX = tmp2;

% Slovakia
[x1,x2,x3]  = xlsread('BIS_HousePricesDec2013','Quarterly Series',['gk' R1 ':gk' R2]);
tmp = NaN*ones(N,1); for i = 1:N; if isfloat(x3{i}); tmp(i)=x3{i}; else z(i)=NaN; end; end;
tmp2 = zeros(N/4,1); for i = 1:4; tmp2 = tmp2 + tmp(i:4:end)/4; end
SVK = tmp2;

% Slovenia
[x1,x2,x3]  = xlsread('BIS_HousePricesDec2013','Quarterly Series',['gb' R1 ':gb' R2]);
tmp = NaN*ones(N,1); for i = 1:N; if isfloat(x3{i}); tmp(i)=x3{i}; else z(i)=NaN; end; end;
tmp2 = zeros(N/4,1); for i = 1:4; tmp2 = tmp2 + tmp(i:4:end)/4; end
SVN = tmp2;

% =======================================
% Countries with annual data
% =======================================

r1 = 186;   % first row of data
r2 = 197;   % final row of data
N  = r2-r1+1;

R1 = num2str(r1);
R2 = num2str(r2);

% Poland (1-family houses)
[x1,x2,x3]  = xlsread('BIS_HousePricesDec2013','Annual Series',['ax' R1 ':ax' R2]);
tmp = NaN*ones(N,1); for i = 1:N; if isfloat(x3{i}); tmp(i)=x3{i}; else z(i)=NaN; end; end;
POL = tmp;

