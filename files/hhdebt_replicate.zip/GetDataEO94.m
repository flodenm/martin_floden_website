% Script to extract data from OECD EO 94
%
% Specify list of countries in variable *cty*
% Specify list of variables in cell *vars* 
%
% Output: Data will be output in matrices (countries*time) with names as in
% *vars*. For example, if cty = ['SWE'; 'USA'], vars={'GDP','GDPV'}, and FREQUENCY='Y',
% then matrices GDP and GDPV will be created (dimension 2*56), first row
% for SWE and second for USA.
% 

clear all
FREQUENCY = 'Y';            % Choose Y for yearly or Q for quarterly data

datafile = 'eo94.xlsx';
NROWS    = 6936;            % # of rows in excel sheet
NROWSSTR = num2str(NROWS);

cty    = ['AUS'; 'BEL'; 'CAN'; 'CHE'; 'DEU'; 'DNK'; ...
          'ESP'; 'FIN'; 'FRA'; 'GBR'; 'GRC'; 'IRL'; 'ITA'; ...
          'JPN'; 'KOR'; 'NLD'; 'NOR'; 'NZL'; 'SWE'; 'USA'; ...
          'AUT'; 'CZE'; 'EST'; 'HUN'; 'ISL'; 'ISR'; 'LUX'; ...
          'MEX'; 'POL'; 'PRT'; 'SVK'; 'SVN';];
ncty   = size(cty,1);

vars   = {'CBGDPR','GDPV','IHV','ITV','UNR','CPV','CGV','SRATIO','CPI','CPIH','POP1500','GGFLQ'};


if FREQUENCY == 'Y'
    year            = 1960:2015;
    [x1,ctyvar,x3]  = xlsread(datafile,['a1:a' NROWSSTR]);
    [x1,x2,alldata] = xlsread(datafile,['h1:dn' NROWSSTR]);
    [x1,x2,pow10]   = xlsread(datafile,['f1:f' NROWSSTR]);
end

if FREQUENCY == 'Q'
    year            = 1960:0.25:2015.75;
    [x1,ctyvar,x3]  = xlsread(datafile,['a1:a' NROWSSTR]);
    [x1,x2,alldata] = xlsread(datafile,['dp1:ut6936' NROWSSTR]);
    [x1,x2,pow10]   = xlsread(datafile,['f1:f6936' NROWSSTR]);
end

% Read variables from Excel file
for i = 1:length(vars)
    for j = 1:ncty
        k = 0;
        while 2 > 1
            k = k + 1;
            if k > NROWS
                MISSVAR = 1;
                break;
            else
                MISSVAR = 0;
            end
            if strcmp('OEC',cty(j,1:3))
                if strcmp(ctyvar{k},[cty(j,1:3) 'D.' vars{i}]) == 1
                    break
                end
            elseif strcmp('A15',cty(j,1:3))
                if strcmp(ctyvar{k},['E' cty(j,1:3) '.' vars{i}]) == 1
                    break
                end
            elseif strcmp(ctyvar{k},[cty(j,1:3) '.' vars{i}]) == 1
                break
            end
        end
        if MISSVAR == 1
            eval([vars{i} '(j,:) = NaN*ones(1,length(year));']);    
        else
            x    = cell2mat(alldata(k,:));
            xpow = cell2mat(pow10(k));
            eval([vars{i} '(j,:) = x(1:2:end)*(10^xpow);']);
        end
    end
end

clear FREQUENCY alldata ctyvar datafile i j k pow10 x*









