qui {
clear all

import excel "Data.xlsx", sheet("Blad1") firstrow case(lower)

label var dph        "House prices, incr 07-12"
label var du         "Unemp, incr 07-12"
label var ihpre      "Construction 03-07"
label var capre      "CA 03-07"
label var hhdebt     "Debt/dinc 2007"
label var hhwealth   "Wealth/dinc 2007"
label var dphpre     "House price growth 03-07"
label var ddebtpre   "Growth in debt 03-07"
label var dwealthpre "Growth in wealth 03-07"
label var dy         "GDP, incr 07-12"
label var dypre      "GDP Growth, 03-07"
label var dcp        "Private cons, incr 07-12"
label var dcppre     "Growth in priv cons, 03-07"
label var dg         "Government debt 2007"

note dph: Accumulated growh, percent, real
note du: U(2012)-U(2007), percentage points
note ihpre: Average construction, percent of GDP
note capre: Average current account balance, percent of GDP
note hhdebt: Household debt, percent of net disposable income
note hhwealth: Household financial wealth, percent of net disposable income
note dphpre: Average annual growth rate, percent
note ddebtpre: Average annual growth rate of hh debt ratio, percent
note dwealthpre: Average annual growth rate of hh wealth ratio, percent
note dg: General gvt gross financial liabilities, percent of GDP

gen phfall = dph < 0
gen irsp = 0
replace irsp = 1 if (country=="IRL") | (country=="ESP")
gen nois = (irsp==0)                // nois indicates dataset without IRL and ESP
drop irsp

label var phfall     "Indicating house price fall 07-12"
label var nois       "Indicating sample without Ireland and Spain"

drop if country == "POL"            // Values for house prices in Poland appear incorrect

save data, replace                  // Use this dataset (with Sweden after 2007) later

drop if ddebtpre >= .               // Only keep countries with complete data coverage
drop if du >= .                     // Only keep countries with complete data coverage


if 1>2 {
graph hbar (asis) dcp, over(country, sort(dcp) descending label(nolabel) axis(lc(white))) blabel(group, size(vsmall)) name(dCP) note("Accumulated growth, percent, real per capita") ytitle("Private consumption, increase 2007-2012")
graph hbar (asis) du, over(country, sort(du) descending label(nolabel) axis(lc(white))) blabel(group, size(vsmall)) name(dU) note("U(2012)-U(2007), percentage points") ytitle("Unemployment, increase 2007-2012")
graph hbar (asis) dph, over(country, sort(dph) descending label(nolabel) axis(lc(white))) blabel(group, size(vsmall)) name(dPH) note("Accumulated growh, percent, real") ytitle("Property prices, increase 2007-2012")
graph hbar (asis) capre, over(country, sort(capre) descending label(nolabel) axis(lc(white))) blabel(group, size(vsmall)) name(CApre) note("Annual average, percent of GDP") ytitle("Current account balance 2003-2007")
graph hbar (asis) ihpre, over(country, sort(ihpre) descending label(nolabel) axis(lc(white))) blabel(group, size(vsmall)) name(IHpre) note("Annual average, percent of GDP") ytitle("Construction 2003-2007")
graph hbar (asis) hhdebt, over(country, sort(hhdebt) descending label(nolabel) axis(lc(white))) blabel(group, size(vsmall)) name(hhDebt) note("Percent of net disposable income") ytitle("Household debt 2007")
graph hbar (asis) ddebtpre, over(country, sort(ddebtpre) descending label(nolabel) axis(lc(white))) blabel(group, size(vsmall)) name(dDebtpre) note("Average annual growth rate of hh debt ratio, percent") ytitle("Growth of debt ratio 2003-2007")
graph hbar (asis) hhwealth, over(country, sort(hhwealth) descending label(nolabel) axis(lc(white))) blabel(group, size(vsmall)) name(hhWealth) note("Household net fin wealth, percent of net disp inc") ytitle("Household wealth 2007")
graph hbar (asis) dwealthpre, over(country, sort(dwealthpre) descending label(nolabel) axis(lc(white))) blabel(group, size(vsmall)) name(dWealthpre) note("Avg annual growth rate of hh net fin wealth ratio, perc") ytitle("Growth of wealth ratio 2003-2007")
graph hbar (asis) dcppre, over(country, sort(dcppre) descending label(nolabel) axis(lc(white))) blabel(group, size(vsmall)) name(dCPpre) note("Avg annual growth rate, percent, real per capita") ytitle("Growth of private consumption 2003-2007")
graph combine dCP dU, cols(2) name(BARS1)
graph export eFIG1.wmf, replace
graph combine dPH dCPpre, cols(2) name(BARS2)
graph export eFIG2.wmf, replace
graph combine CApre IHpre, cols(2) name(BARS3)
graph export eFIG3.wmf, replace
graph combine hhDebt dDebtpre, cols(2) name(BARS4)
graph export eFIG4.wmf, replace
graph combine hhWealth dWealthpre, cols(2) name(BARS5)
graph export eFIG5.wmf, replace
graph drop _all
}


estimates clear

reg dcp hhdebt ddebtpre capre dcppre
matrix bcp = e(b)
estimates store r1, title(Konsumtion)
 
reg du hhdebt ddebtpre capre dcppre
matrix bu = e(b)
estimates store r2, title(Arbetsl�shet)

reg dph hhdebt ddebtpre capre dcppre
matrix bph = e(b)
estimates store r3, title(Huspriser)

noi esttab r* using eTABLE1sw, replace html star(* 0.05 ** 0.01) compress b(2) p(2) stats(r2_a N, fmt(%6.2f %6.0g) labels("R2 (justerad)" Observationer)) nonotes gaps nonumbers modelwidth(12) ///
               mtitles label wrap varlabels(_cons Konstant hhdebt "Skuldkvot 2007" ddebtpre "Skuldtillv�xt f�re 2007" capre "Bytesbalans f�re 2007" dcppre "Konsumtionstillv�xt f�re 2007") varwidth(30) ///
			   note("Anm: Tabellen visar regressionsresultat d�r den f�rklarade variabeln anges i kolumnrubriken. �Konsumtion� avser procentuell tillv�xt i privat konsumtion per capita 2007-2012. Skuldkvoten �r hush�llens skulder i procent av disponibel inkomst. Skuldtillv�xten �r genomsnittlig procentuell �kning i skuldkvot 2003-2007. p-v�rden i parentes. * och ** anger 5% respektive 1% signifikans.")

noi esttab r* using eTABLE1sw, replace rtf star(* 0.05 ** 0.01) compress b(2) p(2) stats(r2_a N, fmt(%6.2f %6.0g) labels("R2 (justerad)" Observationer)) nonotes gaps nonumbers modelwidth(12) ///
               mtitles label wrap varlabels(_cons Konstant hhdebt "Skuldkvot 2007" ddebtpre "Skuldtillv�xt f�re 2007" capre "Bytesbalans f�re 2007" dcppre "Konsumtionstillv�xt f�re 2007") varwidth(30) ///
			   note("Anm: Tabellen visar regressionsresultat d�r den f�rklarade variabeln anges i kolumnrubriken. �Konsumtion� avser procentuell tillv�xt i privat konsumtion per capita 2007-2012. Skuldkvoten �r hush�llens skulder i procent av disponibel inkomst. Skuldtillv�xten �r genomsnittlig procentuell �kning i skuldkvot 2003-2007. p-v�rden i parentes. * och ** anger 5% respektive 1% signifikans.")

estimates clear

reg dcp hhdebt ddebtpre capre dcppre
matrix bcp = e(b)
estimates store r1, title(Consumption)
 
reg du hhdebt ddebtpre capre dcppre
matrix bu = e(b)
estimates store r2, title(Unemployment)

reg dph hhdebt ddebtpre capre dcppre
matrix bph = e(b)
estimates store r3, title(House prices)

noi esttab r* using eTABLE1en, replace rtf star(* 0.05 ** 0.01) compress b(2) p(2) stats(r2_a N, fmt(%6.2f %6.0g) labels("R2 (adjusted)" Observations)) nonotes gaps nonumbers modelwidth(12) ///
               mtitles label wrap varlabels(_cons Constant hhdebt "Debt ratio 2007" ddebtpre "Growth in debt before 2007" capre "CA before 2007" dcppre "Consumption growth before 2007") varwidth(30) ///
			   note("Note: Regression results. Dependent variable specified in column head. �Consumption� is percent increase in private consumption per capita 2007-2012. The debt ratio is household debt in percent of disposable income. Debt growth is average percentage growth in the debt ratio 2003-2007. p-values in parenthesis. * and ** denote 5% and 1% significance.")			   
		   
estimates clear

reg dcp hhdebt ddebtpre capre dcppre
estimates store r1, title(dC)

reg du hhdebt ddebtpre capre dcppre
estimates store r2, title(dU)

reg dph hhdebt ddebtpre capre dcppre
estimates store r3, title(dPH)

reg dy hhdebt ddebtpre capre dcppre
matrix by = e(b)
estimates store r4, title(dY)
		
		
noi esttab r* using eTABLE1, replace rtf star(* 0.05 ** 0.01) compress b(2) p(2) stats(r2_a N, fmt(%6.2f %6.0g) labels("R2 (adjusted)" Observations)) ///
               mtitles label wrap varlabels(_cons Constant) varwidth(26) nolegend modelwidth(6) gaps ///
			   note("OLS regression as in (1) with dependent variable specified in column head; p-values in parentheses; * and ** indicate significance at 5% and 1% respectively.")
			   

estimates clear

rreg dcp hhdebt ddebtpre capre dcppre
estimates store r1, title(dC)

rreg du hhdebt ddebtpre capre dcppre
estimates store r2, title(dU)

rreg dph hhdebt ddebtpre capre dcppre
estimates store r3, title(dPH)

rreg dy hhdebt ddebtpre capre dcppre
matrix by = e(b)
estimates store r4, title(dY)
			   
noi esttab r* using eTABLE2, replace rtf star(* 0.05 ** 0.01) compress b(2) p(2) stats(r2_a N, fmt(%6.2f %6.0g) labels("R2 (adjusted)" Observations)) ///
               mtitles label wrap varlabels(_cons Constant) varwidth(26) nolegend modelwidth(6) gaps ///
			   note("Outlier robust regression as in (1) with dependent variable specified in column head; p-values in parentheses; * and ** indicate significance at 5% and 1% respectively.")

estimates clear

reg dcp hhdebt ddebtpre capre dcppre
estimates store r1, title(dC)

reg dcp hhdebt
estimates store r2, title(dC)

reg dcp ddebtpre capre dcppre
estimates store r3, title(dC)

reg dcp capre dcppre
estimates store r4, title(dC)

reg dcp hhdebt ddebtpre
estimates store r5, title(dC)

reg dcp hhdebt ddebtpre hhwealth dwealthpre capre dcppre
estimates store r6, title(dC)

reg dcp hhwealth dwealthpre capre dcppre
estimates store r7, title(dC)

reg dcp hhdebt ddebtpre capre dcppre ihpre
estimates store r8, title(dC)

noi esttab r* using eTABLE3, replace rtf star(* 0.05 ** 0.01) compress b(2) p(2) stats(r2_a N, fmt(%6.2f %6.0g) labels("R2 (adjusted)" Observations)) ///
               mtitles label wrap varlabels(_cons Constant) varwidth(26) nolegend modelwidth(6) gaps ///
			   note("Regression with dC as dependent variable; p-values in parentheses; * and ** indicate significance at 5% and 1% respectively.")


estimates clear

reg du hhdebt ddebtpre capre dcppre
estimates store r1, title(dU)

reg du hhdebt
estimates store r2, title(dU)

reg du ddebtpre capre dcppre
estimates store r3, title(dU)

reg du capre dcppre
estimates store r4, title(dU)

reg du hhdebt ddebtpre
estimates store r5, title(dU)

reg du capre ihpre
estimates store r6, title(dU)

rreg du capre ihpre
estimates store r7, title(dU)

reg du hhdebt ddebtpre hhwealth dwealthpre capre
estimates store r8, title(dU)

noi esttab r* using eTABLE4, replace rtf star(* 0.05 ** 0.01) compress b(2) p(2) stats(r2_a N, fmt(%6.2f %6.0g) labels("R2 (adjusted)" Observations)) ///
               mtitles label wrap varlabels(_cons Constant) varwidth(26) nolegend modelwidth(6) ///
			   note("Regression with dU as dependent variable, outlier robust regression in column 7; p-values in parentheses; * and ** indicate significance at 5% and 1% respectively.")


estimates clear

reg dph hhdebt ddebtpre capre dcppre
estimates store r1, title(dPH)

reg dph hhdebt
estimates store r2, title(dPH)

reg dph ddebtpre capre dcppre
estimates store r3, title(dPH)

reg dph capre dcppre
estimates store r4, title(dPH)

reg dph hhdebt ddebtpre hhwealth dwealthpre capre
estimates store r6, title(dPH)

reg dph hhwealth dwealthpre capre 
estimates store r7, title(dPH)

reg dph hhdebt ddebtpre capre ihpre
estimates store r8, title(dPH)

noi esttab r* using eTABLE5, replace rtf star(* 0.05 ** 0.01) compress b(2) p(2) stats(r2_a N, fmt(%6.2f %6.0g) labels("R2 (adjusted)" Observations)) ///
               mtitles legend label wrap varlabels(_cons Constant) varwidth(26) modelwidth(6) gaps

			   
estimates clear

reg dy hhdebt ddebtpre capre dcppre
estimates store r1, title(dY)

reg dy hhdebt ddebtpre capre dypre
estimates store r2, title(dY)

reg dy hhdebt
estimates store r3, title(dY)

reg dy ddebtpre capre dypre
estimates store r4, title(dY)

reg dy capre dypre
estimates store r5, title(dY)

reg dy hhdebt ddebtpre hhwealth dwealthpre capre dypre
estimates store r6, title(dY)

reg dy hhwealth dwealthpre capre dypre
estimates store r7, title(dY)

reg dy hhdebt ddebtpre capre dypre ihpre
estimates store r8, title(dY)

noi esttab r* using eTABLE6, replace rtf star(* 0.05 ** 0.01) compress b(2) p(2) stats(r2_a N, fmt(%6.2f %6.0g) labels("R2 (adjusted)" Observations)) ///
               mtitles legend label wrap varlabels(_cons Constant) varwidth(26) modelwidth(6) gaps


// Importance of house price falls
estimates clear

reg dcp hhdebt ddebtpre capre dcppre if phfall
estimates store r1, title(dC)

reg dcp hhdebt if phfall
estimates store r2, title(dC)

reg dcp hhdebt ddebtpre if phfall
estimates store r3, title(dC)

reg du hhdebt ddebtpre capre dcppre if phfall
estimates store r4, title(dU)

reg du hhdebt if phfall
estimates store r5, title(dU)

reg du hhdebt ddebtpre if phfall
estimates store r6, title(dU)

noi esttab r* using eTABLE7, replace rtf star(* 0.05 ** 0.01) compress b(2) p(2) stats(r2_a N, fmt(%6.2f %6.0g) labels("R2 (adjusted)" Observations)) ///
               mtitles label wrap varlabels(_cons Constant) varwidth(26) nolegend modelwidth(6) gaps ///
			   note("Only countries with falling house prices 2007-2012 included. OLS regression as in (1) with dependent variable specified in column head; p-values in parentheses; * and ** indicate significance at 5% and 1% respectively.")
	   
	
gen debtPHfall = 0
replace debtPHfall = hhdebt if phfall
label var debtPHfall "(Debt/dinc)*I(price fall)"
gen dDebtPHfall = 0
replace dDebtPHfall = ddebtpre if phfall
label var dDebtPHfall "(Growth in debt)*I(price fall)"

estimates clear

reg dcp hhdebt debtPHfall ddebtpre dDebtPHfall capre dcppre
estimates store r1, title(dC)

reg dcp hhdebt debtPHfall capre dcppre
estimates store r2, title(dC)

reg dcp ddebtpre dDebtPHfall capre dcppre
estimates store r3, title(dC)

reg du hhdebt debtPHfall ddebtpre dDebtPHfall capre
estimates store r4, title(dU)

reg du hhdebt debtPHfall capre
estimates store r5, title(dU)

reg du ddebtpre dDebtPHfall capre
estimates store r6, title(dU)

noi esttab r* using eTABLE8, replace rtf star(* 0.05 ** 0.01) compress b(2) p(2) stats(r2_a N, fmt(%6.2f %6.0g) labels("R2 (adjusted)" Observations)) ///
               mtitles label wrap varlabels(_cons Constant) varwidth(26) nolegend modelwidth(6) gaps ///
               note("OLS regression as in (1) with dependent variable specified in column head; indicator for falling house prices; p-values in parentheses; * and ** indicate significance at 5% and 1% respectively.")
			 
			 
// Government debt and house price growth prior to the crisis
estimates clear

reg dcp hhdebt ddebtpre capre dcppre dg dphpre
estimates store r1, title(dC)

reg dcp hhdebt ddebtpre capre dcppre dg
estimates store r2, title(dC)

reg dcp hhdebt ddebtpre capre dcppre dphpre
estimates store r3, title(dC)

reg dcp capre dcppre dphpre
estimates store r4, title(dC)

reg du hhdebt ddebtpre capre dcppre dg dphpre
estimates store r5, title(dU)

reg du hhdebt ddebtpre capre dcppre dg
estimates store r6, title(dU)

reg du hhdebt ddebtpre capre dcppre dphpre
estimates store r7, title(dU)

reg du capre dcppre dphpre
estimates store r8, title(dU)

noi esttab r* using eTABLE9, replace rtf star(* 0.05 ** 0.01) compress b(2) p(2) stats(r2_a N, fmt(%6.2f %6.0g) labels("R2 (adjusted)" Observations)) ///
               mtitles label wrap varlabels(_cons Constant) varwidth(26) nolegend modelwidth(6) gaps ///
			   note("OLS regression as in (1) with dependent variable specified in column head; p-values in parentheses; * and ** indicate significance at 5% and 1% respectively.")


// Scatter plots
twoway (scatter dcp hhdebt, mlabel(country)) (lfit dcp hhdebt), title("Consumption") xtitle("") ytitle("Percent") legend(off) name(D2) 
twoway (scatter du hhdebt, mlabel(country)) (lfit du hhdebt), title("Unemployemnt") xtitle("") legend(off) name(D3) 
twoway (scatter dph hhdebt, mlabel(country)) (lfit dph hhdebt), title("House prices") xtitle("Household debt ratio 2007, percent") ytitle("Percent") legend(off) name(D4)
twoway (scatter dy hhdebt, mlabel(country)) (lfit dy hhdebt), title("Output") xtitle("Household debt ratio 2007, percent") legend(off) name(D5) 
graph combine D2 D3 D4 D5, cols(2) name(SCATTER0a)
graph export eFIG6a.wmf, replace
graph drop _all

twoway (scatter dcp ddebtpre, mlabel(country)) (lfit dcp ddebtpre), title("Consumption") xtitle("") ytitle("Percent") legend(off) name(D2) 
twoway (scatter du ddebtpre, mlabel(country)) (lfit du ddebtpre), title("Unemployemnt") xtitle("") legend(off) name(D3) 
twoway (scatter dph ddebtpre, mlabel(country)) (lfit dph ddebtpre), title("House prices") xtitle("Growth in debt ratio 2003-2007, percent") ytitle("Percent") legend(off) name(D4)
twoway (scatter dy ddebtpre, mlabel(country)) (lfit dy ddebtpre), title("Output") xtitle("Growth in debt ratio 2003-2007, percent") legend(off) name(D5) 
graph combine D2 D3 D4 D5, cols(2) name(SCATTER0a)
graph export eFIG6b.wmf, replace
graph drop _all

			   
// Scatter plots controlling for other explanatory variables than hhdebt
gen dcp_hat = dcp - (bcp[1,2]*ddebtpre + bcp[1,3]*capre + bcp[1,4]*dcppre)
gen du_hat  = du - (bu[1,2]*ddebtpre + bu[1,3]*capre + bu[1,4]*dcppre)
gen dph_hat = dph - (bph[1,2]*ddebtpre + bph[1,3]*capre + bph[1,4]*dcppre)
gen dy_hat  = dy - (by[1,2]*ddebtpre + by[1,3]*capre + by[1,4]*dcppre)

twoway (scatter dcp_hat hhdebt, mlabel(country)) (lfit dcp_hat hhdebt), title("Justerad konsumtionstillv�xt 2007-2012") xtitle("Hush�llens skuldkvot 2007, procent") ytitle("Procent") legend(off) name(SCATTER1) ///
        note("Konsumtionstillv�xten �r justerad utifr�n regressionsresultatet. Se [6].")
graph export eFIG6sw.wmf, replace
twoway (scatter dcp_hat hhdebt, mlabel(country)) (lfit dcp_hat hhdebt), title("Adjusted consumption growth 2007-2012") xtitle("Household debt ratio 2007, percent") ytitle("Percent") legend(off) name(SCATTER1en) ///
        note("Consumption growth is adjusted from the regression results. See the text and note 7.")
graph export eFIG6en.wmf, replace
twoway (scatter dcp_hat hhdebt, mlabel(country)) (lfit dcp_hat hhdebt), xtitle("Hush�llens skuldkvot 2007, procent") ytitle("Procent") legend(off) name(SCATTER1ek)        
graph export Fig_C_Skuld_ekonomistas.png, width(300) height(300) replace
twoway (scatter dcp_hat hhdebt, mlabel(country)) (lfit dcp_hat hhdebt), title("Consumption") xtitle("") ytitle("Percent") legend(off) name(D2) 
twoway (scatter du_hat hhdebt, mlabel(country)) (lfit du_hat hhdebt), title("Unemployemnt") xtitle("") legend(off) name(D3) 
twoway (scatter dph_hat hhdebt, mlabel(country)) (lfit dph_hat hhdebt), title("House prices") xtitle("Household debt ratio 2007, percent") ytitle("Percent") legend(off) name(D4)
twoway (scatter dy_hat hhdebt, mlabel(country)) (lfit dy_hat hhdebt), title("Output") xtitle("Household debt ratio 2007, percent") legend(off) name(D5) 
graph combine D2 D3 D4 D5, cols(2) name(SCATTER2)
graph export eFIG6.wmf, replace

use data, clear

// Calculate "indicator of vulnerability 2007", based on regression for consumption
gen vuldebt  = -bcp[1,1]*hhdebt
gen vulddebt = -bcp[1,2]*ddebtpre
gen vulcapre = -bcp[1,3]*capre
gen vulner = vuldebt + vulddebt + vulcapre
graph hbar (asis) vulner if (vulner < . & dcp < .), over(country, sort(vulner) descending label(nolabel) axis(lc(white))) blabel(group, size(vsmall)) note("Vulnerability is calculated as in equation (2)")
graph export eFIG7.wmf, replace

// Development of Swedish "vulnerability" 2007-2012
gen year = 2007 if country=="SWE"
replace year = 2008 if country=="SWE2008"
replace year = 2009 if country=="SWE2009"
replace year = 2010 if country=="SWE2010"
replace year = 2011 if country=="SWE2011"
replace year = 2012 if country=="SWE2012"
line vulner vuldebt vulddebt vulcapre year if year < ., lwidth(1 0.7 0.7 0.7) lcolor(black gray gray gray) ///
     lpattern(solid longdash shortdash dot) ///
	 legend(lab(1 "Total") lab(2 "Debt ratio") lab(3 "Debt growth") lab(4 "CA")) name(LINE1) ///
	 note("Total vulnerability and contribution to vulnerability from debt ratio, debt growth, and current account balance")
graph export eFIG8.wmf, replace
graph drop _all	 

}			   
