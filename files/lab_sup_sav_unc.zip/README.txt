Matlab code for "Labor Supply and Saving under Uncertainty", Economic Journal 2006.
Martin Floden, Stockholm School of Economics
May 2005

table1.m replicates table 1
figure1.m replicates figure 1

The code uses Mario Miranda and Paul Fackler's compecon toolbox. See http://www4.ncsu.edu/unity/users/p/pfackler/www/compecon/