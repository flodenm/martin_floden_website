clear all

cepath = 'c:\0martin\matlab_libraries\compecon\compecon\'; path([cepath 'cetools;' cepath 'cedemos'],path);

sigma   = 1; 
w       = 10;
alpha   = 0.4;
gamma   = 0.01:0.01:5;

eta_fix   = alpha*(2-alpha*(1-1./gamma)) / w;
eta_flex  = gamma .* (1-alpha*(1-1./gamma)) .* (2-alpha*(1-1./gamma)) / w;

ra = (alpha^2 ./ gamma + alpha*(1-alpha)) / w;
i_fix = alpha^2/w./ra;
i_flex = gamma;

plot(gamma,ra,'k-',gamma,eta_fix,'k-',gamma,eta_flex,'k-');
axis([0 5 0 0.9]);
xlabel('\gamma');
gtext('\eta^f^l^e^x');
gtext('\eta^f^i^x');
gtext('risk aversion');