function f = foc_flex(s,gamma,alpha,w,w_nodes,w_weights)

V1s = -(alpha*w-s)^(alpha*(1-1/gamma)-1);
V2s = (alpha*w_nodes+s).^(alpha*(1-1/gamma)-1);

f = V1s + w_weights'*V2s;