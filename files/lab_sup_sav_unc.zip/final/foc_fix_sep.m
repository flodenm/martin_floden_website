function f = foc_fix_sep(s,gamma,alpha,w,w_nodes,w_weight)

V1s = -1./(alpha*w-s);
V2s = 1./(alpha*w_nodes+s);

f = V1s + w_weight'*V2s;