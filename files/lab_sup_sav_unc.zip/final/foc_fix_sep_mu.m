function f = foc_fix_sep(s,mu,gamma,alpha,w,w_nodes,w_weight)

V1s = -(alpha*w-s)^(-mu);
V2s = (alpha*w_nodes+s).^(-mu);

f = V1s + w_weight'*V2s;