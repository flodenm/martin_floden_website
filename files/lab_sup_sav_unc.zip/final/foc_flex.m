function f = foc_flex(s,gamma,alpha,w,w_nodes,w_weights)

C1 = alpha * (w - s);
L1 = (1-alpha) / alpha * C1 / w;

C2 = alpha * (w_nodes + s);
L2 = (1-alpha) / alpha * C2 ./ w_nodes;

V1s = -(w-s)^(-1/gamma) * w^(-(1-alpha)*(1-1/gamma));
V2s = (w_nodes+s).^(-1/gamma) .* w_nodes.^(-(1-alpha)*(1-1/gamma));

f = V1s + w_weights'*V2s;