function f = foc_flex_sep(x,gamma,alpha,B,w,w_nodes,w_weights)

C1 = x(1);
C2 = x(2:end);

L1 = (B*C1/w)^gamma;
L2 = (B*C2./w_nodes).^gamma;

UC1  = 1/C1;
UC2  = 1./C2;
EUC2 = w_weights'*UC2;

UL2  = B * L2.^(-1/gamma);

f    = [UC1-EUC2; C1+C2-(1-L1)*w-(1-L2).*w_nodes];