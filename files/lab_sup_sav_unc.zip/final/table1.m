clear all

cepath = 'c:\0martin\matlab_libraries\compecon\compecon\'; path([cepath 'cetools;' cepath 'cedemos'],path);

CDUTILITY  = 0;
SEPUTILLOG = 1;

mu      = 1.0;
sigma   = 1.0; 
w       = 10;
alpha   = 0.4;
gamma   = [0.1 0.25 0.5 1 2 10];
n_nodes = 8;

[w_nodes,w_weights]  = qnwnorm(n_nodes,w,sigma^2);

if CDUTILITY

eta_fix   = alpha*(2-alpha*(1-1./gamma)) / w;
eta_flex  = gamma .* (1-alpha*(1-1./gamma)) .* (2-alpha*(1-1./gamma)) / w;
eta_tilde = (2-alpha*(1-1./gamma)) / w;

sfix          = eta_fix * sigma^2 / 4;
sflex         = eta_flex * sigma^2 / 4; 
stilde        = eta_tilde * sigma^2 / 2; 

xfix  = eta_fix / alpha *sigma^2 / 2;

options   = optimset('Display','off');
n     = length(gamma);
Sfix  = zeros(1,n);
Sflex = zeros(1,n);
for i = 1:n
    Sfix(i)  = fzero(@foc_fix,w/100,options,gamma(i),alpha,w,w_nodes,w_weights);
    Sflex(i) = fzero(@foc_flex,w/100,options,gamma(i),alpha,w,w_nodes,w_weights);
end

fprintf(1,'\nCobb Douglas Utility, sigma = %4.2f\n\n',sigma)
fprintf(1,'        Fixed labor supply    Flexible labor supply\n')
fprintf(1,'        ==================   ========================\n')
fprintf(1,'Gamma       s     s(eta)       s      s(eta)   psi_hat\n')
fprintf(1,'%6.2f   %6.4f   %6.4f     %6.4f   %6.4f   %6.4f\n',[gamma' Sfix' sfix' Sflex' sflex' stilde']')



elseif SEPUTILLOG

% SEPARABLE UTILITY
% u(C,L) = ln(C) + B(L^(1-1/gamma) - 1) / (1-1/gamma)

Lbar = 1-alpha;
G    = 1 - 1./gamma;
B    = Lbar.^(1./gamma) / (1-Lbar);
C    = w*(1-Lbar);

eta_fix   = 2*(1-Lbar)^2 ./ C;

Ls        = gamma.*w./(C.^2) ./ (1/(Lbar*(1-Lbar)) + gamma.*((w./C).^2));
eta_flex  = eta_fix ./ (1 - Ls*w);
eta_tilde = (1-Lbar)./C;

sfix          = eta_fix * sigma^2 / 4;
sflex         = eta_flex * sigma^2 / 4; 
stilde        = eta_tilde * sigma^2; 

options   = optimset('Display','off','TolX',1e-12,'TolFun',1e-12);
n     = length(gamma);
Sfix  = zeros(1,n);
Sflex = zeros(1,n);
C1flex = zeros(1,n);
C2flex = zeros(1,n);
for i = 1:n
    Sfix(i)  = fzero(@foc_fix_sep,w/100,options,gamma(i),alpha,w,w_nodes,w_weights);
    Xflex    = fsolve(@foc_flex_sep,C*ones(n_nodes+1,1),options,gamma(i),alpha,B(i),w,w_nodes,w_weights);
    C1       = Xflex(1);
    L1       = (B(i)*C1/w)^gamma(i);
    Sflex(i) = (1-L1)*w - C1; 
    C1flex(i) = C1;
    C2flex(i) = w_weights'*Xflex(2:end);
end

fprintf(1,'\nSeparable Utility, sigma = %4.2f\n\n',sigma)
fprintf(1,'        Fixed labor supply    Flexible labor supply\n')
fprintf(1,'        ==================   ========================\n')
fprintf(1,'Gamma       s     s(eta)       s      s(eta)   psi_hat\n')
fprintf(1,'%6.2f   %6.4f   %6.4f     %6.4f   %6.4f   %6.4f\n',[gamma' Sfix' sfix*ones(n,1) Sflex' sflex' stilde*ones(n,1)]')


else

% SEPARABLE UTILITY
% u(C,L) = C^(1-mu)-1 / (1-mu) + B(L^(1-1/gamma) - 1) / (1-1/gamma)

Lbar = 1-alpha;
G    = 1 - 1./gamma;
C    = w*(1-Lbar);
B    = w*Lbar.^(1./gamma) * C.^(-mu);


options   = optimset('Display','off','TolX',1e-12,'TolFun',1e-12);
n     = length(gamma);
Sfix  = zeros(1,n);
Sflex = zeros(1,n);
C1flex = zeros(1,n);
C2flex = zeros(1,n);
for i = 1:n
    Sfix(i)  = fzero(@foc_fix_sep_mu,w/100,options,mu,gamma(i),alpha,w,w_nodes,w_weights);
    Xflex    = fsolve(@foc_flex_sep_mu,log(C*ones(n_nodes+1,1)),options,mu,gamma(i),alpha,B(i),w,w_nodes,w_weights);
    Xflex    = exp(Xflex);
    C1       = Xflex(1);
    L1       = (B(i)*(C1.^mu)/w)^gamma(i);
    Sflex(i) = (1-L1)*w - C1; 
    C1flex(i) = C1;
    C2flex(i) = w_weights'*Xflex(2:end);
end

[gamma' Sfix' Sflex' C2flex'./C1flex'-1]

end